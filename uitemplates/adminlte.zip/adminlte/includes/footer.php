<script src="js/jquery.js"></script>
<!-- Bootstrap 4 -->
<script src="js/bootstrap.bundle.min.js?v=ii"></script>
<!-- AdminLTE App -->
<script src="js/adminlte.js?v=ii"></script>
<!-- AdminLTE for demo purposes -->
<script src="js/demo.js"></script>