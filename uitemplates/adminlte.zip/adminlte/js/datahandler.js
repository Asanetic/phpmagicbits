 
//===============Start Mosy queries-============ 

    //Start get  account_profiles Data ===============
    
      function get_account_profiles(account_profiles_colstr, account_profiles_filter_col, account_profiles_cols, account_profiles_node_function_name, account_profiles_callback_function_string, account_profiles_ui_tag)
      {
        mosyflex_sel("account_profiles", account_profiles_colstr, account_profiles_filter_col , account_profiles_cols, account_profiles_node_function_name, account_profiles_callback_function_string, account_profiles_ui_tag);
        
      }
    //End get  account_profiles Data ===============

    //Start insert  account_profiles Data ===============

	function add_account_profiles(account_profiles_cols, account_profiles_vals, account_profiles_callback_function_string)
    {
		
        mosyajax_create_data("account_profiles", account_profiles_cols, account_profiles_vals, account_profiles_callback_function_string);
     }
     
    //End insert  account_profiles Data ===============

    
    //Start update  account_profiles Data ===============

    function update_account_profiles(account_profiles_update_str, account_profiles_where_str, account_profiles_callback_function_string){
    
		mosyajax_update("account_profiles", account_profiles_update_str, account_profiles_where_str, account_profiles_callback_function_string)
    
    }
    //end  update  account_profiles Data ===============

	//Start drop  account_profiles Data ===============
    function account_profiles_drop(account_profiles_where_str, account_profiles_callback_function_string)
    {
        mosyajax_drop("account_profiles", account_profiles_where_str, account_profiles_callback_function_string)

    }
	//End drop  account_profiles Data ===============
    
    function initialize_account_profiles(qstr="", account_profiles_callback_function_string="")
    {
    
    ///alert(qstr);
      var account_profiles_token_query =qstr;
      if(qstr=="")
      {
       var account_profiles_token_query_param="";
       var account_profiles_js_uptoken=mosy_get_param("account_profiles_uptoken");
       //alert(account_profiles_js_uptoken);
       if(account_profiles_js_uptoken!==undefined)
       {
       
        account_profiles_token_query_param = atob(account_profiles_js_uptoken);
       }
        account_profiles_token_query = " where primkey='"+(account_profiles_token_query_param)+"'";
        
           if (document.getElementById("account_profiles_uptoken") !==null) {
           	if(document.getElementById("account_profiles_uptoken").value!="")
            {
            
            var account_profiles_atob_tbl_key =atob(document.getElementById("account_profiles_uptoken").value);
            
                   
            account_profiles_token_query = " where primkey='"+(account_profiles_atob_tbl_key)+"'";

            }
           }
      }
      
      var account_profiles_push_ui_data_to =account_profiles_callback_function_string;
      if(account_profiles_callback_function_string=="")
      {
      account_profiles_push_ui_data_to = "add_account_profiles_ui_data";
      }
                
      console.log(account_profiles_token_query+" -- "+account_profiles_js_uptoken);

	  //alert(account_profiles_push_ui_data_to);

     get_account_profiles("*", account_profiles_token_query, "primkey", "blackhole", account_profiles_push_ui_data_to, "");
    }
    
    function add_account_profiles_ui_data(account_profiles_server_resp) 
    {
    
    ///alert(account_profiles_server_resp);
    
    var json_decoded_str=JSON.parse(account_profiles_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load account_profiles data on the fly ==============
    
	var gft_account_profiles_str="(account_id LIKE '%{{qaccount_profiles}}%' OR  organization_name LIKE '%{{qaccount_profiles}}%' OR  industry LIKE '%{{qaccount_profiles}}%' OR  number_of_employees LIKE '%{{qaccount_profiles}}%' OR  city LIKE '%{{qaccount_profiles}}%' OR  town LIKE '%{{qaccount_profiles}}%' OR  street LIKE '%{{qaccount_profiles}}%' OR  organization_logo LIKE '%{{qaccount_profiles}}%' OR  contact_header LIKE '%{{qaccount_profiles}}%' OR  owner LIKE '%{{qaccount_profiles}}%')";
    
    function  gft_account_profiles(qaccount_profiles_str)
    {
        	var clean_account_profiles_filter_str=gft_account_profiles_str.replace(/{{qaccount_profiles}}/g, magic_clean_str(qaccount_profiles_str));
            
            return  clean_account_profiles_filter_str;

    }
    
    function load_account_profiles(account_profiles_qstr, account_profiles_where_str, account_profiles_ret_cols, account_profiles_user_function, account_profiles_result_function, account_profiles_data_tray)
    {
    
    var faccount_profiles_result_function="push_result";
      
    if(account_profiles_result_function!="")
    {
          var faccount_profiles_result_function=account_profiles_result_function;

    }
    	var clean_account_profiles_filter_str=gft_account_profiles_str.replace(/{{qaccount_profiles}}/g, magic_clean_str(account_profiles_qstr));
        
        var faccount_profiles_where_str=" where "+clean_account_profiles_filter_str;

    if(account_profiles_where_str!="")
    {
          var faccount_profiles_where_str=" "+account_profiles_where_str;

    }
       
      get_account_profiles("*", faccount_profiles_where_str, account_profiles_ret_cols, account_profiles_user_function, faccount_profiles_result_function, account_profiles_data_tray);
      
    }
    ///=============== load account_profiles data on the fly ==============


 ///=quick load 
 
 function qkload_account_profiles(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var account_profiles_list_nodes_str=account_profiles_list_nodes;
  
   if(ui_card!="")
   {
      account_profiles_list_nodes_str=ui_card;
   }
   
   var account_profiles_qret_fun="push_grid_result:account_profiles_tbl_list";
   
   if(push_fun!="")
   {
    account_profiles_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_account_profiles("*", ajaxw+" ("+gft_account_profiles(qstr)+") "+combined_query+"  order by primkey desc ", account_profiles_list_cols+additional_cols_str, "",account_profiles_qret_fun, "c=>"+account_profiles_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_account_profiles(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_account_profiles("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qaccount_profiles_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_account_profiles("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_account_profiles("*", account_profiles_token_query, "primkey", "blackhole", account_profiles_push_ui_data_to, "");
    

}



//sum 

function sum_account_profiles(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_account_profiles("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function account_profiles_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "account_profiles_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function account_profiles_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "account_profiles_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function account_profiles_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteaccount_profiles&account_profiles_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  advance_payments Data ===============
    
      function get_advance_payments(advance_payments_colstr, advance_payments_filter_col, advance_payments_cols, advance_payments_node_function_name, advance_payments_callback_function_string, advance_payments_ui_tag)
      {
        mosyflex_sel("advance_payments", advance_payments_colstr, advance_payments_filter_col , advance_payments_cols, advance_payments_node_function_name, advance_payments_callback_function_string, advance_payments_ui_tag);
        
      }
    //End get  advance_payments Data ===============

    //Start insert  advance_payments Data ===============

	function add_advance_payments(advance_payments_cols, advance_payments_vals, advance_payments_callback_function_string)
    {
		
        mosyajax_create_data("advance_payments", advance_payments_cols, advance_payments_vals, advance_payments_callback_function_string);
     }
     
    //End insert  advance_payments Data ===============

    
    //Start update  advance_payments Data ===============

    function update_advance_payments(advance_payments_update_str, advance_payments_where_str, advance_payments_callback_function_string){
    
		mosyajax_update("advance_payments", advance_payments_update_str, advance_payments_where_str, advance_payments_callback_function_string)
    
    }
    //end  update  advance_payments Data ===============

	//Start drop  advance_payments Data ===============
    function advance_payments_drop(advance_payments_where_str, advance_payments_callback_function_string)
    {
        mosyajax_drop("advance_payments", advance_payments_where_str, advance_payments_callback_function_string)

    }
	//End drop  advance_payments Data ===============
    
    function initialize_advance_payments(qstr="", advance_payments_callback_function_string="")
    {
    
    ///alert(qstr);
      var advance_payments_token_query =qstr;
      if(qstr=="")
      {
       var advance_payments_token_query_param="";
       var advance_payments_js_uptoken=mosy_get_param("advance_payments_uptoken");
       //alert(advance_payments_js_uptoken);
       if(advance_payments_js_uptoken!==undefined)
       {
       
        advance_payments_token_query_param = atob(advance_payments_js_uptoken);
       }
        advance_payments_token_query = " where primkey='"+(advance_payments_token_query_param)+"'";
        
           if (document.getElementById("advance_payments_uptoken") !==null) {
           	if(document.getElementById("advance_payments_uptoken").value!="")
            {
            
            var advance_payments_atob_tbl_key =atob(document.getElementById("advance_payments_uptoken").value);
            
                   
            advance_payments_token_query = " where primkey='"+(advance_payments_atob_tbl_key)+"'";

            }
           }
      }
      
      var advance_payments_push_ui_data_to =advance_payments_callback_function_string;
      if(advance_payments_callback_function_string=="")
      {
      advance_payments_push_ui_data_to = "add_advance_payments_ui_data";
      }
                
      console.log(advance_payments_token_query+" -- "+advance_payments_js_uptoken);

	  //alert(advance_payments_push_ui_data_to);

     get_advance_payments("*", advance_payments_token_query, "primkey", "blackhole", advance_payments_push_ui_data_to, "");
    }
    
    function add_advance_payments_ui_data(advance_payments_server_resp) 
    {
    
    ///alert(advance_payments_server_resp);
    
    var json_decoded_str=JSON.parse(advance_payments_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load advance_payments data on the fly ==============
    
	var gft_advance_payments_str="(advance_key LIKE '%{{qadvance_payments}}%' OR  transaction_date LIKE '%{{qadvance_payments}}%' OR  amount LIKE '%{{qadvance_payments}}%' OR  amount_repaid LIKE '%{{qadvance_payments}}%' OR  balance_amt LIKE '%{{qadvance_payments}}%' OR  context LIKE '%{{qadvance_payments}}%' OR  ref_id LIKE '%{{qadvance_payments}}%' OR  staff_id LIKE '%{{qadvance_payments}}%' OR  remark LIKE '%{{qadvance_payments}}%' OR  installment_amount LIKE '%{{qadvance_payments}}%' OR  owner LIKE '%{{qadvance_payments}}%' OR  payment_key LIKE '%{{qadvance_payments}}%')";
    
    function  gft_advance_payments(qadvance_payments_str)
    {
        	var clean_advance_payments_filter_str=gft_advance_payments_str.replace(/{{qadvance_payments}}/g, magic_clean_str(qadvance_payments_str));
            
            return  clean_advance_payments_filter_str;

    }
    
    function load_advance_payments(advance_payments_qstr, advance_payments_where_str, advance_payments_ret_cols, advance_payments_user_function, advance_payments_result_function, advance_payments_data_tray)
    {
    
    var fadvance_payments_result_function="push_result";
      
    if(advance_payments_result_function!="")
    {
          var fadvance_payments_result_function=advance_payments_result_function;

    }
    	var clean_advance_payments_filter_str=gft_advance_payments_str.replace(/{{qadvance_payments}}/g, magic_clean_str(advance_payments_qstr));
        
        var fadvance_payments_where_str=" where "+clean_advance_payments_filter_str;

    if(advance_payments_where_str!="")
    {
          var fadvance_payments_where_str=" "+advance_payments_where_str;

    }
       
      get_advance_payments("*", fadvance_payments_where_str, advance_payments_ret_cols, advance_payments_user_function, fadvance_payments_result_function, advance_payments_data_tray);
      
    }
    ///=============== load advance_payments data on the fly ==============


 ///=quick load 
 
 function qkload_advance_payments(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var advance_payments_list_nodes_str=advance_payments_list_nodes;
  
   if(ui_card!="")
   {
      advance_payments_list_nodes_str=ui_card;
   }
   
   var advance_payments_qret_fun="push_grid_result:advance_payments_tbl_list";
   
   if(push_fun!="")
   {
    advance_payments_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_advance_payments("*", ajaxw+" ("+gft_advance_payments(qstr)+") "+combined_query+"  order by primkey desc ", advance_payments_list_cols+additional_cols_str, "",advance_payments_qret_fun, "c=>"+advance_payments_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_advance_payments(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_advance_payments("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qadvance_payments_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_advance_payments("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_advance_payments("*", advance_payments_token_query, "primkey", "blackhole", advance_payments_push_ui_data_to, "");
    

}



//sum 

function sum_advance_payments(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_advance_payments("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function advance_payments_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "advance_payments_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function advance_payments_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "advance_payments_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function advance_payments_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteadvance_payments&advance_payments_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  allowances Data ===============
    
      function get_allowances(allowances_colstr, allowances_filter_col, allowances_cols, allowances_node_function_name, allowances_callback_function_string, allowances_ui_tag)
      {
        mosyflex_sel("allowances", allowances_colstr, allowances_filter_col , allowances_cols, allowances_node_function_name, allowances_callback_function_string, allowances_ui_tag);
        
      }
    //End get  allowances Data ===============

    //Start insert  allowances Data ===============

	function add_allowances(allowances_cols, allowances_vals, allowances_callback_function_string)
    {
		
        mosyajax_create_data("allowances", allowances_cols, allowances_vals, allowances_callback_function_string);
     }
     
    //End insert  allowances Data ===============

    
    //Start update  allowances Data ===============

    function update_allowances(allowances_update_str, allowances_where_str, allowances_callback_function_string){
    
		mosyajax_update("allowances", allowances_update_str, allowances_where_str, allowances_callback_function_string)
    
    }
    //end  update  allowances Data ===============

	//Start drop  allowances Data ===============
    function allowances_drop(allowances_where_str, allowances_callback_function_string)
    {
        mosyajax_drop("allowances", allowances_where_str, allowances_callback_function_string)

    }
	//End drop  allowances Data ===============
    
    function initialize_allowances(qstr="", allowances_callback_function_string="")
    {
    
    ///alert(qstr);
      var allowances_token_query =qstr;
      if(qstr=="")
      {
       var allowances_token_query_param="";
       var allowances_js_uptoken=mosy_get_param("allowances_uptoken");
       //alert(allowances_js_uptoken);
       if(allowances_js_uptoken!==undefined)
       {
       
        allowances_token_query_param = atob(allowances_js_uptoken);
       }
        allowances_token_query = " where primkey='"+(allowances_token_query_param)+"'";
        
           if (document.getElementById("allowances_uptoken") !==null) {
           	if(document.getElementById("allowances_uptoken").value!="")
            {
            
            var allowances_atob_tbl_key =atob(document.getElementById("allowances_uptoken").value);
            
                   
            allowances_token_query = " where primkey='"+(allowances_atob_tbl_key)+"'";

            }
           }
      }
      
      var allowances_push_ui_data_to =allowances_callback_function_string;
      if(allowances_callback_function_string=="")
      {
      allowances_push_ui_data_to = "add_allowances_ui_data";
      }
                
      console.log(allowances_token_query+" -- "+allowances_js_uptoken);

	  //alert(allowances_push_ui_data_to);

     get_allowances("*", allowances_token_query, "primkey", "blackhole", allowances_push_ui_data_to, "");
    }
    
    function add_allowances_ui_data(allowances_server_resp) 
    {
    
    ///alert(allowances_server_resp);
    
    var json_decoded_str=JSON.parse(allowances_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load allowances data on the fly ==============
    
	var gft_allowances_str="(allowance_id LIKE '%{{qallowances}}%' OR  allowance_title LIKE '%{{qallowances}}%' OR  amount LIKE '%{{qallowances}}%' OR  staff_id LIKE '%{{qallowances}}%' OR  remark LIKE '%{{qallowances}}%' OR  owner LIKE '%{{qallowances}}%' OR  active_state LIKE '%{{qallowances}}%')";
    
    function  gft_allowances(qallowances_str)
    {
        	var clean_allowances_filter_str=gft_allowances_str.replace(/{{qallowances}}/g, magic_clean_str(qallowances_str));
            
            return  clean_allowances_filter_str;

    }
    
    function load_allowances(allowances_qstr, allowances_where_str, allowances_ret_cols, allowances_user_function, allowances_result_function, allowances_data_tray)
    {
    
    var fallowances_result_function="push_result";
      
    if(allowances_result_function!="")
    {
          var fallowances_result_function=allowances_result_function;

    }
    	var clean_allowances_filter_str=gft_allowances_str.replace(/{{qallowances}}/g, magic_clean_str(allowances_qstr));
        
        var fallowances_where_str=" where "+clean_allowances_filter_str;

    if(allowances_where_str!="")
    {
          var fallowances_where_str=" "+allowances_where_str;

    }
       
      get_allowances("*", fallowances_where_str, allowances_ret_cols, allowances_user_function, fallowances_result_function, allowances_data_tray);
      
    }
    ///=============== load allowances data on the fly ==============


 ///=quick load 
 
 function qkload_allowances(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var allowances_list_nodes_str=allowances_list_nodes;
  
   if(ui_card!="")
   {
      allowances_list_nodes_str=ui_card;
   }
   
   var allowances_qret_fun="push_grid_result:allowances_tbl_list";
   
   if(push_fun!="")
   {
    allowances_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_allowances("*", ajaxw+" ("+gft_allowances(qstr)+") "+combined_query+"  order by primkey desc ", allowances_list_cols+additional_cols_str, "",allowances_qret_fun, "c=>"+allowances_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_allowances(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_allowances("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qallowances_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_allowances("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_allowances("*", allowances_token_query, "primkey", "blackhole", allowances_push_ui_data_to, "");
    

}



//sum 

function sum_allowances(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_allowances("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function allowances_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "allowances_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function allowances_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "allowances_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function allowances_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteallowances&allowances_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  app_users Data ===============
    
      function get_app_users(app_users_colstr, app_users_filter_col, app_users_cols, app_users_node_function_name, app_users_callback_function_string, app_users_ui_tag)
      {
        mosyflex_sel("app_users", app_users_colstr, app_users_filter_col , app_users_cols, app_users_node_function_name, app_users_callback_function_string, app_users_ui_tag);
        
      }
    //End get  app_users Data ===============

    //Start insert  app_users Data ===============

	function add_app_users(app_users_cols, app_users_vals, app_users_callback_function_string)
    {
		
        mosyajax_create_data("app_users", app_users_cols, app_users_vals, app_users_callback_function_string);
     }
     
    //End insert  app_users Data ===============

    
    //Start update  app_users Data ===============

    function update_app_users(app_users_update_str, app_users_where_str, app_users_callback_function_string){
    
		mosyajax_update("app_users", app_users_update_str, app_users_where_str, app_users_callback_function_string)
    
    }
    //end  update  app_users Data ===============

	//Start drop  app_users Data ===============
    function app_users_drop(app_users_where_str, app_users_callback_function_string)
    {
        mosyajax_drop("app_users", app_users_where_str, app_users_callback_function_string)

    }
	//End drop  app_users Data ===============
    
    function initialize_app_users(qstr="", app_users_callback_function_string="")
    {
    
    ///alert(qstr);
      var app_users_token_query =qstr;
      if(qstr=="")
      {
       var app_users_token_query_param="";
       var app_users_js_uptoken=mosy_get_param("app_users_uptoken");
       //alert(app_users_js_uptoken);
       if(app_users_js_uptoken!==undefined)
       {
       
        app_users_token_query_param = atob(app_users_js_uptoken);
       }
        app_users_token_query = " where primkey='"+(app_users_token_query_param)+"'";
        
           if (document.getElementById("app_users_uptoken") !==null) {
           	if(document.getElementById("app_users_uptoken").value!="")
            {
            
            var app_users_atob_tbl_key =atob(document.getElementById("app_users_uptoken").value);
            
                   
            app_users_token_query = " where primkey='"+(app_users_atob_tbl_key)+"'";

            }
           }
      }
      
      var app_users_push_ui_data_to =app_users_callback_function_string;
      if(app_users_callback_function_string=="")
      {
      app_users_push_ui_data_to = "add_app_users_ui_data";
      }
                
      console.log(app_users_token_query+" -- "+app_users_js_uptoken);

	  //alert(app_users_push_ui_data_to);

     get_app_users("*", app_users_token_query, "primkey", "blackhole", app_users_push_ui_data_to, "");
    }
    
    function add_app_users_ui_data(app_users_server_resp) 
    {
    
    ///alert(app_users_server_resp);
    
    var json_decoded_str=JSON.parse(app_users_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load app_users data on the fly ==============
    
	var gft_app_users_str="(user_id LIKE '%{{qapp_users}}%' OR  name LIKE '%{{qapp_users}}%' OR  email LIKE '%{{qapp_users}}%' OR  tel LIKE '%{{qapp_users}}%' OR  login_password LIKE '%{{qapp_users}}%' OR  account_no LIKE '%{{qapp_users}}%' OR  date_signed_up LIKE '%{{qapp_users}}%' OR  user_no LIKE '%{{qapp_users}}%' OR  user_pic LIKE '%{{qapp_users}}%' OR  user_gender LIKE '%{{qapp_users}}%' OR  last_seen LIKE '%{{qapp_users}}%' OR  about LIKE '%{{qapp_users}}%')";
    
    function  gft_app_users(qapp_users_str)
    {
        	var clean_app_users_filter_str=gft_app_users_str.replace(/{{qapp_users}}/g, magic_clean_str(qapp_users_str));
            
            return  clean_app_users_filter_str;

    }
    
    function load_app_users(app_users_qstr, app_users_where_str, app_users_ret_cols, app_users_user_function, app_users_result_function, app_users_data_tray)
    {
    
    var fapp_users_result_function="push_result";
      
    if(app_users_result_function!="")
    {
          var fapp_users_result_function=app_users_result_function;

    }
    	var clean_app_users_filter_str=gft_app_users_str.replace(/{{qapp_users}}/g, magic_clean_str(app_users_qstr));
        
        var fapp_users_where_str=" where "+clean_app_users_filter_str;

    if(app_users_where_str!="")
    {
          var fapp_users_where_str=" "+app_users_where_str;

    }
       
      get_app_users("*", fapp_users_where_str, app_users_ret_cols, app_users_user_function, fapp_users_result_function, app_users_data_tray);
      
    }
    ///=============== load app_users data on the fly ==============


 ///=quick load 
 
 function qkload_app_users(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var app_users_list_nodes_str=app_users_list_nodes;
  
   if(ui_card!="")
   {
      app_users_list_nodes_str=ui_card;
   }
   
   var app_users_qret_fun="push_grid_result:app_users_tbl_list";
   
   if(push_fun!="")
   {
    app_users_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_app_users("*", ajaxw+" ("+gft_app_users(qstr)+") "+combined_query+"  order by primkey desc ", app_users_list_cols+additional_cols_str, "",app_users_qret_fun, "c=>"+app_users_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_app_users(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_app_users("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qapp_users_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_app_users("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_app_users("*", app_users_token_query, "primkey", "blackhole", app_users_push_ui_data_to, "");
    

}



//sum 

function sum_app_users(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_app_users("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function app_users_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "app_users_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function app_users_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "app_users_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function app_users_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteapp_users&app_users_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  casuals_payroll Data ===============
    
      function get_casuals_payroll(casuals_payroll_colstr, casuals_payroll_filter_col, casuals_payroll_cols, casuals_payroll_node_function_name, casuals_payroll_callback_function_string, casuals_payroll_ui_tag)
      {
        mosyflex_sel("casuals_payroll", casuals_payroll_colstr, casuals_payroll_filter_col , casuals_payroll_cols, casuals_payroll_node_function_name, casuals_payroll_callback_function_string, casuals_payroll_ui_tag);
        
      }
    //End get  casuals_payroll Data ===============

    //Start insert  casuals_payroll Data ===============

	function add_casuals_payroll(casuals_payroll_cols, casuals_payroll_vals, casuals_payroll_callback_function_string)
    {
		
        mosyajax_create_data("casuals_payroll", casuals_payroll_cols, casuals_payroll_vals, casuals_payroll_callback_function_string);
     }
     
    //End insert  casuals_payroll Data ===============

    
    //Start update  casuals_payroll Data ===============

    function update_casuals_payroll(casuals_payroll_update_str, casuals_payroll_where_str, casuals_payroll_callback_function_string){
    
		mosyajax_update("casuals_payroll", casuals_payroll_update_str, casuals_payroll_where_str, casuals_payroll_callback_function_string)
    
    }
    //end  update  casuals_payroll Data ===============

	//Start drop  casuals_payroll Data ===============
    function casuals_payroll_drop(casuals_payroll_where_str, casuals_payroll_callback_function_string)
    {
        mosyajax_drop("casuals_payroll", casuals_payroll_where_str, casuals_payroll_callback_function_string)

    }
	//End drop  casuals_payroll Data ===============
    
    function initialize_casuals_payroll(qstr="", casuals_payroll_callback_function_string="")
    {
    
    ///alert(qstr);
      var casuals_payroll_token_query =qstr;
      if(qstr=="")
      {
       var casuals_payroll_token_query_param="";
       var casuals_payroll_js_uptoken=mosy_get_param("casuals_payroll_uptoken");
       //alert(casuals_payroll_js_uptoken);
       if(casuals_payroll_js_uptoken!==undefined)
       {
       
        casuals_payroll_token_query_param = atob(casuals_payroll_js_uptoken);
       }
        casuals_payroll_token_query = " where primkey='"+(casuals_payroll_token_query_param)+"'";
        
           if (document.getElementById("casuals_payroll_uptoken") !==null) {
           	if(document.getElementById("casuals_payroll_uptoken").value!="")
            {
            
            var casuals_payroll_atob_tbl_key =atob(document.getElementById("casuals_payroll_uptoken").value);
            
                   
            casuals_payroll_token_query = " where primkey='"+(casuals_payroll_atob_tbl_key)+"'";

            }
           }
      }
      
      var casuals_payroll_push_ui_data_to =casuals_payroll_callback_function_string;
      if(casuals_payroll_callback_function_string=="")
      {
      casuals_payroll_push_ui_data_to = "add_casuals_payroll_ui_data";
      }
                
      console.log(casuals_payroll_token_query+" -- "+casuals_payroll_js_uptoken);

	  //alert(casuals_payroll_push_ui_data_to);

     get_casuals_payroll("*", casuals_payroll_token_query, "primkey", "blackhole", casuals_payroll_push_ui_data_to, "");
    }
    
    function add_casuals_payroll_ui_data(casuals_payroll_server_resp) 
    {
    
    ///alert(casuals_payroll_server_resp);
    
    var json_decoded_str=JSON.parse(casuals_payroll_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load casuals_payroll data on the fly ==============
    
	var gft_casuals_payroll_str="(payroll_id LIKE '%{{qcasuals_payroll}}%' OR  payroll_month_year LIKE '%{{qcasuals_payroll}}%' OR  payroll_date LIKE '%{{qcasuals_payroll}}%' OR  staff_id LIKE '%{{qcasuals_payroll}}%' OR  job_group LIKE '%{{qcasuals_payroll}}%' OR  basicsalary LIKE '%{{qcasuals_payroll}}%' OR  bonus_and_commissions LIKE '%{{qcasuals_payroll}}%' OR  deductions LIKE '%{{qcasuals_payroll}}%' OR  net_salary LIKE '%{{qcasuals_payroll}}%' OR  payroll_number LIKE '%{{qcasuals_payroll}}%' OR  payroll_notes LIKE '%{{qcasuals_payroll}}%' OR  days_worked LIKE '%{{qcasuals_payroll}}%' OR  owner LIKE '%{{qcasuals_payroll}}%')";
    
    function  gft_casuals_payroll(qcasuals_payroll_str)
    {
        	var clean_casuals_payroll_filter_str=gft_casuals_payroll_str.replace(/{{qcasuals_payroll}}/g, magic_clean_str(qcasuals_payroll_str));
            
            return  clean_casuals_payroll_filter_str;

    }
    
    function load_casuals_payroll(casuals_payroll_qstr, casuals_payroll_where_str, casuals_payroll_ret_cols, casuals_payroll_user_function, casuals_payroll_result_function, casuals_payroll_data_tray)
    {
    
    var fcasuals_payroll_result_function="push_result";
      
    if(casuals_payroll_result_function!="")
    {
          var fcasuals_payroll_result_function=casuals_payroll_result_function;

    }
    	var clean_casuals_payroll_filter_str=gft_casuals_payroll_str.replace(/{{qcasuals_payroll}}/g, magic_clean_str(casuals_payroll_qstr));
        
        var fcasuals_payroll_where_str=" where "+clean_casuals_payroll_filter_str;

    if(casuals_payroll_where_str!="")
    {
          var fcasuals_payroll_where_str=" "+casuals_payroll_where_str;

    }
       
      get_casuals_payroll("*", fcasuals_payroll_where_str, casuals_payroll_ret_cols, casuals_payroll_user_function, fcasuals_payroll_result_function, casuals_payroll_data_tray);
      
    }
    ///=============== load casuals_payroll data on the fly ==============


 ///=quick load 
 
 function qkload_casuals_payroll(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var casuals_payroll_list_nodes_str=casuals_payroll_list_nodes;
  
   if(ui_card!="")
   {
      casuals_payroll_list_nodes_str=ui_card;
   }
   
   var casuals_payroll_qret_fun="push_grid_result:casuals_payroll_tbl_list";
   
   if(push_fun!="")
   {
    casuals_payroll_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_casuals_payroll("*", ajaxw+" ("+gft_casuals_payroll(qstr)+") "+combined_query+"  order by primkey desc ", casuals_payroll_list_cols+additional_cols_str, "",casuals_payroll_qret_fun, "c=>"+casuals_payroll_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_casuals_payroll(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_casuals_payroll("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qcasuals_payroll_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_casuals_payroll("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_casuals_payroll("*", casuals_payroll_token_query, "primkey", "blackhole", casuals_payroll_push_ui_data_to, "");
    

}



//sum 

function sum_casuals_payroll(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_casuals_payroll("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function casuals_payroll_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "casuals_payroll_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function casuals_payroll_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "casuals_payroll_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function casuals_payroll_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletecasuals_payroll&casuals_payroll_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  commissions Data ===============
    
      function get_commissions(commissions_colstr, commissions_filter_col, commissions_cols, commissions_node_function_name, commissions_callback_function_string, commissions_ui_tag)
      {
        mosyflex_sel("commissions", commissions_colstr, commissions_filter_col , commissions_cols, commissions_node_function_name, commissions_callback_function_string, commissions_ui_tag);
        
      }
    //End get  commissions Data ===============

    //Start insert  commissions Data ===============

	function add_commissions(commissions_cols, commissions_vals, commissions_callback_function_string)
    {
		
        mosyajax_create_data("commissions", commissions_cols, commissions_vals, commissions_callback_function_string);
     }
     
    //End insert  commissions Data ===============

    
    //Start update  commissions Data ===============

    function update_commissions(commissions_update_str, commissions_where_str, commissions_callback_function_string){
    
		mosyajax_update("commissions", commissions_update_str, commissions_where_str, commissions_callback_function_string)
    
    }
    //end  update  commissions Data ===============

	//Start drop  commissions Data ===============
    function commissions_drop(commissions_where_str, commissions_callback_function_string)
    {
        mosyajax_drop("commissions", commissions_where_str, commissions_callback_function_string)

    }
	//End drop  commissions Data ===============
    
    function initialize_commissions(qstr="", commissions_callback_function_string="")
    {
    
    ///alert(qstr);
      var commissions_token_query =qstr;
      if(qstr=="")
      {
       var commissions_token_query_param="";
       var commissions_js_uptoken=mosy_get_param("commissions_uptoken");
       //alert(commissions_js_uptoken);
       if(commissions_js_uptoken!==undefined)
       {
       
        commissions_token_query_param = atob(commissions_js_uptoken);
       }
        commissions_token_query = " where primkey='"+(commissions_token_query_param)+"'";
        
           if (document.getElementById("commissions_uptoken") !==null) {
           	if(document.getElementById("commissions_uptoken").value!="")
            {
            
            var commissions_atob_tbl_key =atob(document.getElementById("commissions_uptoken").value);
            
                   
            commissions_token_query = " where primkey='"+(commissions_atob_tbl_key)+"'";

            }
           }
      }
      
      var commissions_push_ui_data_to =commissions_callback_function_string;
      if(commissions_callback_function_string=="")
      {
      commissions_push_ui_data_to = "add_commissions_ui_data";
      }
                
      console.log(commissions_token_query+" -- "+commissions_js_uptoken);

	  //alert(commissions_push_ui_data_to);

     get_commissions("*", commissions_token_query, "primkey", "blackhole", commissions_push_ui_data_to, "");
    }
    
    function add_commissions_ui_data(commissions_server_resp) 
    {
    
    ///alert(commissions_server_resp);
    
    var json_decoded_str=JSON.parse(commissions_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load commissions data on the fly ==============
    
	var gft_commissions_str="(commission_id LIKE '%{{qcommissions}}%' OR  commission_name LIKE '%{{qcommissions}}%' OR  amount LIKE '%{{qcommissions}}%' OR  staff_id LIKE '%{{qcommissions}}%' OR  remark LIKE '%{{qcommissions}}%' OR  active_state LIKE '%{{qcommissions}}%' OR  owner LIKE '%{{qcommissions}}%')";
    
    function  gft_commissions(qcommissions_str)
    {
        	var clean_commissions_filter_str=gft_commissions_str.replace(/{{qcommissions}}/g, magic_clean_str(qcommissions_str));
            
            return  clean_commissions_filter_str;

    }
    
    function load_commissions(commissions_qstr, commissions_where_str, commissions_ret_cols, commissions_user_function, commissions_result_function, commissions_data_tray)
    {
    
    var fcommissions_result_function="push_result";
      
    if(commissions_result_function!="")
    {
          var fcommissions_result_function=commissions_result_function;

    }
    	var clean_commissions_filter_str=gft_commissions_str.replace(/{{qcommissions}}/g, magic_clean_str(commissions_qstr));
        
        var fcommissions_where_str=" where "+clean_commissions_filter_str;

    if(commissions_where_str!="")
    {
          var fcommissions_where_str=" "+commissions_where_str;

    }
       
      get_commissions("*", fcommissions_where_str, commissions_ret_cols, commissions_user_function, fcommissions_result_function, commissions_data_tray);
      
    }
    ///=============== load commissions data on the fly ==============


 ///=quick load 
 
 function qkload_commissions(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var commissions_list_nodes_str=commissions_list_nodes;
  
   if(ui_card!="")
   {
      commissions_list_nodes_str=ui_card;
   }
   
   var commissions_qret_fun="push_grid_result:commissions_tbl_list";
   
   if(push_fun!="")
   {
    commissions_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_commissions("*", ajaxw+" ("+gft_commissions(qstr)+") "+combined_query+"  order by primkey desc ", commissions_list_cols+additional_cols_str, "",commissions_qret_fun, "c=>"+commissions_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_commissions(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_commissions("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qcommissions_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_commissions("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_commissions("*", commissions_token_query, "primkey", "blackhole", commissions_push_ui_data_to, "");
    

}



//sum 

function sum_commissions(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_commissions("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function commissions_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "commissions_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function commissions_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "commissions_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function commissions_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletecommissions&commissions_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  deductions Data ===============
    
      function get_deductions(deductions_colstr, deductions_filter_col, deductions_cols, deductions_node_function_name, deductions_callback_function_string, deductions_ui_tag)
      {
        mosyflex_sel("deductions", deductions_colstr, deductions_filter_col , deductions_cols, deductions_node_function_name, deductions_callback_function_string, deductions_ui_tag);
        
      }
    //End get  deductions Data ===============

    //Start insert  deductions Data ===============

	function add_deductions(deductions_cols, deductions_vals, deductions_callback_function_string)
    {
		
        mosyajax_create_data("deductions", deductions_cols, deductions_vals, deductions_callback_function_string);
     }
     
    //End insert  deductions Data ===============

    
    //Start update  deductions Data ===============

    function update_deductions(deductions_update_str, deductions_where_str, deductions_callback_function_string){
    
		mosyajax_update("deductions", deductions_update_str, deductions_where_str, deductions_callback_function_string)
    
    }
    //end  update  deductions Data ===============

	//Start drop  deductions Data ===============
    function deductions_drop(deductions_where_str, deductions_callback_function_string)
    {
        mosyajax_drop("deductions", deductions_where_str, deductions_callback_function_string)

    }
	//End drop  deductions Data ===============
    
    function initialize_deductions(qstr="", deductions_callback_function_string="")
    {
    
    ///alert(qstr);
      var deductions_token_query =qstr;
      if(qstr=="")
      {
       var deductions_token_query_param="";
       var deductions_js_uptoken=mosy_get_param("deductions_uptoken");
       //alert(deductions_js_uptoken);
       if(deductions_js_uptoken!==undefined)
       {
       
        deductions_token_query_param = atob(deductions_js_uptoken);
       }
        deductions_token_query = " where primkey='"+(deductions_token_query_param)+"'";
        
           if (document.getElementById("deductions_uptoken") !==null) {
           	if(document.getElementById("deductions_uptoken").value!="")
            {
            
            var deductions_atob_tbl_key =atob(document.getElementById("deductions_uptoken").value);
            
                   
            deductions_token_query = " where primkey='"+(deductions_atob_tbl_key)+"'";

            }
           }
      }
      
      var deductions_push_ui_data_to =deductions_callback_function_string;
      if(deductions_callback_function_string=="")
      {
      deductions_push_ui_data_to = "add_deductions_ui_data";
      }
                
      console.log(deductions_token_query+" -- "+deductions_js_uptoken);

	  //alert(deductions_push_ui_data_to);

     get_deductions("*", deductions_token_query, "primkey", "blackhole", deductions_push_ui_data_to, "");
    }
    
    function add_deductions_ui_data(deductions_server_resp) 
    {
    
    ///alert(deductions_server_resp);
    
    var json_decoded_str=JSON.parse(deductions_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load deductions data on the fly ==============
    
	var gft_deductions_str="(deduction_id LIKE '%{{qdeductions}}%' OR  deduction_title LIKE '%{{qdeductions}}%' OR  amount LIKE '%{{qdeductions}}%' OR  staff_id LIKE '%{{qdeductions}}%' OR  remark LIKE '%{{qdeductions}}%' OR  owner LIKE '%{{qdeductions}}%' OR  active_state LIKE '%{{qdeductions}}%')";
    
    function  gft_deductions(qdeductions_str)
    {
        	var clean_deductions_filter_str=gft_deductions_str.replace(/{{qdeductions}}/g, magic_clean_str(qdeductions_str));
            
            return  clean_deductions_filter_str;

    }
    
    function load_deductions(deductions_qstr, deductions_where_str, deductions_ret_cols, deductions_user_function, deductions_result_function, deductions_data_tray)
    {
    
    var fdeductions_result_function="push_result";
      
    if(deductions_result_function!="")
    {
          var fdeductions_result_function=deductions_result_function;

    }
    	var clean_deductions_filter_str=gft_deductions_str.replace(/{{qdeductions}}/g, magic_clean_str(deductions_qstr));
        
        var fdeductions_where_str=" where "+clean_deductions_filter_str;

    if(deductions_where_str!="")
    {
          var fdeductions_where_str=" "+deductions_where_str;

    }
       
      get_deductions("*", fdeductions_where_str, deductions_ret_cols, deductions_user_function, fdeductions_result_function, deductions_data_tray);
      
    }
    ///=============== load deductions data on the fly ==============


 ///=quick load 
 
 function qkload_deductions(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var deductions_list_nodes_str=deductions_list_nodes;
  
   if(ui_card!="")
   {
      deductions_list_nodes_str=ui_card;
   }
   
   var deductions_qret_fun="push_grid_result:deductions_tbl_list";
   
   if(push_fun!="")
   {
    deductions_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_deductions("*", ajaxw+" ("+gft_deductions(qstr)+") "+combined_query+"  order by primkey desc ", deductions_list_cols+additional_cols_str, "",deductions_qret_fun, "c=>"+deductions_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_deductions(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_deductions("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qdeductions_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_deductions("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_deductions("*", deductions_token_query, "primkey", "blackhole", deductions_push_ui_data_to, "");
    

}



//sum 

function sum_deductions(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_deductions("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function deductions_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "deductions_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function deductions_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "deductions_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function deductions_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletedeductions&deductions_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  employee_loans Data ===============
    
      function get_employee_loans(employee_loans_colstr, employee_loans_filter_col, employee_loans_cols, employee_loans_node_function_name, employee_loans_callback_function_string, employee_loans_ui_tag)
      {
        mosyflex_sel("employee_loans", employee_loans_colstr, employee_loans_filter_col , employee_loans_cols, employee_loans_node_function_name, employee_loans_callback_function_string, employee_loans_ui_tag);
        
      }
    //End get  employee_loans Data ===============

    //Start insert  employee_loans Data ===============

	function add_employee_loans(employee_loans_cols, employee_loans_vals, employee_loans_callback_function_string)
    {
		
        mosyajax_create_data("employee_loans", employee_loans_cols, employee_loans_vals, employee_loans_callback_function_string);
     }
     
    //End insert  employee_loans Data ===============

    
    //Start update  employee_loans Data ===============

    function update_employee_loans(employee_loans_update_str, employee_loans_where_str, employee_loans_callback_function_string){
    
		mosyajax_update("employee_loans", employee_loans_update_str, employee_loans_where_str, employee_loans_callback_function_string)
    
    }
    //end  update  employee_loans Data ===============

	//Start drop  employee_loans Data ===============
    function employee_loans_drop(employee_loans_where_str, employee_loans_callback_function_string)
    {
        mosyajax_drop("employee_loans", employee_loans_where_str, employee_loans_callback_function_string)

    }
	//End drop  employee_loans Data ===============
    
    function initialize_employee_loans(qstr="", employee_loans_callback_function_string="")
    {
    
    ///alert(qstr);
      var employee_loans_token_query =qstr;
      if(qstr=="")
      {
       var employee_loans_token_query_param="";
       var employee_loans_js_uptoken=mosy_get_param("employee_loans_uptoken");
       //alert(employee_loans_js_uptoken);
       if(employee_loans_js_uptoken!==undefined)
       {
       
        employee_loans_token_query_param = atob(employee_loans_js_uptoken);
       }
        employee_loans_token_query = " where primkey='"+(employee_loans_token_query_param)+"'";
        
           if (document.getElementById("employee_loans_uptoken") !==null) {
           	if(document.getElementById("employee_loans_uptoken").value!="")
            {
            
            var employee_loans_atob_tbl_key =atob(document.getElementById("employee_loans_uptoken").value);
            
                   
            employee_loans_token_query = " where primkey='"+(employee_loans_atob_tbl_key)+"'";

            }
           }
      }
      
      var employee_loans_push_ui_data_to =employee_loans_callback_function_string;
      if(employee_loans_callback_function_string=="")
      {
      employee_loans_push_ui_data_to = "add_employee_loans_ui_data";
      }
                
      console.log(employee_loans_token_query+" -- "+employee_loans_js_uptoken);

	  //alert(employee_loans_push_ui_data_to);

     get_employee_loans("*", employee_loans_token_query, "primkey", "blackhole", employee_loans_push_ui_data_to, "");
    }
    
    function add_employee_loans_ui_data(employee_loans_server_resp) 
    {
    
    ///alert(employee_loans_server_resp);
    
    var json_decoded_str=JSON.parse(employee_loans_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load employee_loans data on the fly ==============
    
	var gft_employee_loans_str="(loan_id LIKE '%{{qemployee_loans}}%' OR  loan_name LIKE '%{{qemployee_loans}}%' OR  loan_number LIKE '%{{qemployee_loans}}%' OR  date_applied LIKE '%{{qemployee_loans}}%' OR  date_issued LIKE '%{{qemployee_loans}}%' OR  principal_amount LIKE '%{{qemployee_loans}}%' OR  interest_amount LIKE '%{{qemployee_loans}}%' OR  princ_plus_int LIKE '%{{qemployee_loans}}%' OR  monthly_installment LIKE '%{{qemployee_loans}}%' OR  interest_formulae LIKE '%{{qemployee_loans}}%' OR  active_status LIKE '%{{qemployee_loans}}%' OR  staff_id LIKE '%{{qemployee_loans}}%' OR  owner LIKE '%{{qemployee_loans}}%' OR  remark LIKE '%{{qemployee_loans}}%')";
    
    function  gft_employee_loans(qemployee_loans_str)
    {
        	var clean_employee_loans_filter_str=gft_employee_loans_str.replace(/{{qemployee_loans}}/g, magic_clean_str(qemployee_loans_str));
            
            return  clean_employee_loans_filter_str;

    }
    
    function load_employee_loans(employee_loans_qstr, employee_loans_where_str, employee_loans_ret_cols, employee_loans_user_function, employee_loans_result_function, employee_loans_data_tray)
    {
    
    var femployee_loans_result_function="push_result";
      
    if(employee_loans_result_function!="")
    {
          var femployee_loans_result_function=employee_loans_result_function;

    }
    	var clean_employee_loans_filter_str=gft_employee_loans_str.replace(/{{qemployee_loans}}/g, magic_clean_str(employee_loans_qstr));
        
        var femployee_loans_where_str=" where "+clean_employee_loans_filter_str;

    if(employee_loans_where_str!="")
    {
          var femployee_loans_where_str=" "+employee_loans_where_str;

    }
       
      get_employee_loans("*", femployee_loans_where_str, employee_loans_ret_cols, employee_loans_user_function, femployee_loans_result_function, employee_loans_data_tray);
      
    }
    ///=============== load employee_loans data on the fly ==============


 ///=quick load 
 
 function qkload_employee_loans(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var employee_loans_list_nodes_str=employee_loans_list_nodes;
  
   if(ui_card!="")
   {
      employee_loans_list_nodes_str=ui_card;
   }
   
   var employee_loans_qret_fun="push_grid_result:employee_loans_tbl_list";
   
   if(push_fun!="")
   {
    employee_loans_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_employee_loans("*", ajaxw+" ("+gft_employee_loans(qstr)+") "+combined_query+"  order by primkey desc ", employee_loans_list_cols+additional_cols_str, "",employee_loans_qret_fun, "c=>"+employee_loans_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_employee_loans(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_employee_loans("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qemployee_loans_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_employee_loans("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_employee_loans("*", employee_loans_token_query, "primkey", "blackhole", employee_loans_push_ui_data_to, "");
    

}



//sum 

function sum_employee_loans(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_employee_loans("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function employee_loans_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "employee_loans_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function employee_loans_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "employee_loans_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function employee_loans_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteemployee_loans&employee_loans_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  employees Data ===============
    
      function get_employees(employees_colstr, employees_filter_col, employees_cols, employees_node_function_name, employees_callback_function_string, employees_ui_tag)
      {
        mosyflex_sel("employees", employees_colstr, employees_filter_col , employees_cols, employees_node_function_name, employees_callback_function_string, employees_ui_tag);
        
      }
    //End get  employees Data ===============

    //Start insert  employees Data ===============

	function add_employees(employees_cols, employees_vals, employees_callback_function_string)
    {
		
        mosyajax_create_data("employees", employees_cols, employees_vals, employees_callback_function_string);
     }
     
    //End insert  employees Data ===============

    
    //Start update  employees Data ===============

    function update_employees(employees_update_str, employees_where_str, employees_callback_function_string){
    
		mosyajax_update("employees", employees_update_str, employees_where_str, employees_callback_function_string)
    
    }
    //end  update  employees Data ===============

	//Start drop  employees Data ===============
    function employees_drop(employees_where_str, employees_callback_function_string)
    {
        mosyajax_drop("employees", employees_where_str, employees_callback_function_string)

    }
	//End drop  employees Data ===============
    
    function initialize_employees(qstr="", employees_callback_function_string="")
    {
    
    ///alert(qstr);
      var employees_token_query =qstr;
      if(qstr=="")
      {
       var employees_token_query_param="";
       var employees_js_uptoken=mosy_get_param("employees_uptoken");
       //alert(employees_js_uptoken);
       if(employees_js_uptoken!==undefined)
       {
       
        employees_token_query_param = atob(employees_js_uptoken);
       }
        employees_token_query = " where primkey='"+(employees_token_query_param)+"'";
        
           if (document.getElementById("employees_uptoken") !==null) {
           	if(document.getElementById("employees_uptoken").value!="")
            {
            
            var employees_atob_tbl_key =atob(document.getElementById("employees_uptoken").value);
            
                   
            employees_token_query = " where primkey='"+(employees_atob_tbl_key)+"'";

            }
           }
      }
      
      var employees_push_ui_data_to =employees_callback_function_string;
      if(employees_callback_function_string=="")
      {
      employees_push_ui_data_to = "add_employees_ui_data";
      }
                
      console.log(employees_token_query+" -- "+employees_js_uptoken);

	  //alert(employees_push_ui_data_to);

     get_employees("*", employees_token_query, "primkey", "blackhole", employees_push_ui_data_to, "");
    }
    
    function add_employees_ui_data(employees_server_resp) 
    {
    
    ///alert(employees_server_resp);
    
    var json_decoded_str=JSON.parse(employees_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load employees data on the fly ==============
    
	var gft_employees_str="(user_id LIKE '%{{qemployees}}%' OR  name LIKE '%{{qemployees}}%' OR  email LIKE '%{{qemployees}}%' OR  tel LIKE '%{{qemployees}}%' OR  job_group LIKE '%{{qemployees}}%' OR  nssf_no LIKE '%{{qemployees}}%' OR  nhif_no LIKE '%{{qemployees}}%' OR  pin_no LIKE '%{{qemployees}}%' OR  national_id LIKE '%{{qemployees}}%' OR  contract_start_date LIKE '%{{qemployees}}%' OR  contract_end_date LIKE '%{{qemployees}}%' OR  staff_number LIKE '%{{qemployees}}%' OR  passport_photo LIKE '%{{qemployees}}%' OR  gender LIKE '%{{qemployees}}%' OR  job_title LIKE '%{{qemployees}}%' OR  departments LIKE '%{{qemployees}}%' OR  head_of LIKE '%{{qemployees}}%' OR  reports_to LIKE '%{{qemployees}}%' OR  about LIKE '%{{qemployees}}%' OR  owner LIKE '%{{qemployees}}%' OR  employement_date LIKE '%{{qemployees}}%' OR  country LIKE '%{{qemployees}}%' OR  city LIKE '%{{qemployees}}%' OR  town LIKE '%{{qemployees}}%' OR  date_of_birth LIKE '%{{qemployees}}%' OR  job_group_letter LIKE '%{{qemployees}}%' OR  job_group_salary LIKE '%{{qemployees}}%' OR  job_group_type LIKE '%{{qemployees}}%')";
    
    function  gft_employees(qemployees_str)
    {
        	var clean_employees_filter_str=gft_employees_str.replace(/{{qemployees}}/g, magic_clean_str(qemployees_str));
            
            return  clean_employees_filter_str;

    }
    
    function load_employees(employees_qstr, employees_where_str, employees_ret_cols, employees_user_function, employees_result_function, employees_data_tray)
    {
    
    var femployees_result_function="push_result";
      
    if(employees_result_function!="")
    {
          var femployees_result_function=employees_result_function;

    }
    	var clean_employees_filter_str=gft_employees_str.replace(/{{qemployees}}/g, magic_clean_str(employees_qstr));
        
        var femployees_where_str=" where "+clean_employees_filter_str;

    if(employees_where_str!="")
    {
          var femployees_where_str=" "+employees_where_str;

    }
       
      get_employees("*", femployees_where_str, employees_ret_cols, employees_user_function, femployees_result_function, employees_data_tray);
      
    }
    ///=============== load employees data on the fly ==============


 ///=quick load 
 
 function qkload_employees(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var employees_list_nodes_str=employees_list_nodes;
  
   if(ui_card!="")
   {
      employees_list_nodes_str=ui_card;
   }
   
   var employees_qret_fun="push_grid_result:employees_tbl_list";
   
   if(push_fun!="")
   {
    employees_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_employees("*", ajaxw+" ("+gft_employees(qstr)+") "+combined_query+"  order by primkey desc ", employees_list_cols+additional_cols_str, "",employees_qret_fun, "c=>"+employees_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_employees(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_employees("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qemployees_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_employees("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_employees("*", employees_token_query, "primkey", "blackhole", employees_push_ui_data_to, "");
    

}



//sum 

function sum_employees(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_employees("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function employees_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "employees_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function employees_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "employees_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function employees_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteemployees&employees_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  employees_next_of_kin Data ===============
    
      function get_employees_next_of_kin(employees_next_of_kin_colstr, employees_next_of_kin_filter_col, employees_next_of_kin_cols, employees_next_of_kin_node_function_name, employees_next_of_kin_callback_function_string, employees_next_of_kin_ui_tag)
      {
        mosyflex_sel("employees_next_of_kin", employees_next_of_kin_colstr, employees_next_of_kin_filter_col , employees_next_of_kin_cols, employees_next_of_kin_node_function_name, employees_next_of_kin_callback_function_string, employees_next_of_kin_ui_tag);
        
      }
    //End get  employees_next_of_kin Data ===============

    //Start insert  employees_next_of_kin Data ===============

	function add_employees_next_of_kin(employees_next_of_kin_cols, employees_next_of_kin_vals, employees_next_of_kin_callback_function_string)
    {
		
        mosyajax_create_data("employees_next_of_kin", employees_next_of_kin_cols, employees_next_of_kin_vals, employees_next_of_kin_callback_function_string);
     }
     
    //End insert  employees_next_of_kin Data ===============

    
    //Start update  employees_next_of_kin Data ===============

    function update_employees_next_of_kin(employees_next_of_kin_update_str, employees_next_of_kin_where_str, employees_next_of_kin_callback_function_string){
    
		mosyajax_update("employees_next_of_kin", employees_next_of_kin_update_str, employees_next_of_kin_where_str, employees_next_of_kin_callback_function_string)
    
    }
    //end  update  employees_next_of_kin Data ===============

	//Start drop  employees_next_of_kin Data ===============
    function employees_next_of_kin_drop(employees_next_of_kin_where_str, employees_next_of_kin_callback_function_string)
    {
        mosyajax_drop("employees_next_of_kin", employees_next_of_kin_where_str, employees_next_of_kin_callback_function_string)

    }
	//End drop  employees_next_of_kin Data ===============
    
    function initialize_employees_next_of_kin(qstr="", employees_next_of_kin_callback_function_string="")
    {
    
    ///alert(qstr);
      var employees_next_of_kin_token_query =qstr;
      if(qstr=="")
      {
       var employees_next_of_kin_token_query_param="";
       var employees_next_of_kin_js_uptoken=mosy_get_param("employees_next_of_kin_uptoken");
       //alert(employees_next_of_kin_js_uptoken);
       if(employees_next_of_kin_js_uptoken!==undefined)
       {
       
        employees_next_of_kin_token_query_param = atob(employees_next_of_kin_js_uptoken);
       }
        employees_next_of_kin_token_query = " where primkey='"+(employees_next_of_kin_token_query_param)+"'";
        
           if (document.getElementById("employees_next_of_kin_uptoken") !==null) {
           	if(document.getElementById("employees_next_of_kin_uptoken").value!="")
            {
            
            var employees_next_of_kin_atob_tbl_key =atob(document.getElementById("employees_next_of_kin_uptoken").value);
            
                   
            employees_next_of_kin_token_query = " where primkey='"+(employees_next_of_kin_atob_tbl_key)+"'";

            }
           }
      }
      
      var employees_next_of_kin_push_ui_data_to =employees_next_of_kin_callback_function_string;
      if(employees_next_of_kin_callback_function_string=="")
      {
      employees_next_of_kin_push_ui_data_to = "add_employees_next_of_kin_ui_data";
      }
                
      console.log(employees_next_of_kin_token_query+" -- "+employees_next_of_kin_js_uptoken);

	  //alert(employees_next_of_kin_push_ui_data_to);

     get_employees_next_of_kin("*", employees_next_of_kin_token_query, "primkey", "blackhole", employees_next_of_kin_push_ui_data_to, "");
    }
    
    function add_employees_next_of_kin_ui_data(employees_next_of_kin_server_resp) 
    {
    
    ///alert(employees_next_of_kin_server_resp);
    
    var json_decoded_str=JSON.parse(employees_next_of_kin_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load employees_next_of_kin data on the fly ==============
    
	var gft_employees_next_of_kin_str="(kin_id LIKE '%{{qemployees_next_of_kin}}%' OR  owner LIKE '%{{qemployees_next_of_kin}}%' OR  employee_id LIKE '%{{qemployees_next_of_kin}}%' OR  next_of_kin_name LIKE '%{{qemployees_next_of_kin}}%' OR  next_of_kin_telephone LIKE '%{{qemployees_next_of_kin}}%' OR  next_of_kin_email LIKE '%{{qemployees_next_of_kin}}%' OR  relation LIKE '%{{qemployees_next_of_kin}}%' OR  assigned_on LIKE '%{{qemployees_next_of_kin}}%')";
    
    function  gft_employees_next_of_kin(qemployees_next_of_kin_str)
    {
        	var clean_employees_next_of_kin_filter_str=gft_employees_next_of_kin_str.replace(/{{qemployees_next_of_kin}}/g, magic_clean_str(qemployees_next_of_kin_str));
            
            return  clean_employees_next_of_kin_filter_str;

    }
    
    function load_employees_next_of_kin(employees_next_of_kin_qstr, employees_next_of_kin_where_str, employees_next_of_kin_ret_cols, employees_next_of_kin_user_function, employees_next_of_kin_result_function, employees_next_of_kin_data_tray)
    {
    
    var femployees_next_of_kin_result_function="push_result";
      
    if(employees_next_of_kin_result_function!="")
    {
          var femployees_next_of_kin_result_function=employees_next_of_kin_result_function;

    }
    	var clean_employees_next_of_kin_filter_str=gft_employees_next_of_kin_str.replace(/{{qemployees_next_of_kin}}/g, magic_clean_str(employees_next_of_kin_qstr));
        
        var femployees_next_of_kin_where_str=" where "+clean_employees_next_of_kin_filter_str;

    if(employees_next_of_kin_where_str!="")
    {
          var femployees_next_of_kin_where_str=" "+employees_next_of_kin_where_str;

    }
       
      get_employees_next_of_kin("*", femployees_next_of_kin_where_str, employees_next_of_kin_ret_cols, employees_next_of_kin_user_function, femployees_next_of_kin_result_function, employees_next_of_kin_data_tray);
      
    }
    ///=============== load employees_next_of_kin data on the fly ==============


 ///=quick load 
 
 function qkload_employees_next_of_kin(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var employees_next_of_kin_list_nodes_str=employees_next_of_kin_list_nodes;
  
   if(ui_card!="")
   {
      employees_next_of_kin_list_nodes_str=ui_card;
   }
   
   var employees_next_of_kin_qret_fun="push_grid_result:employees_next_of_kin_tbl_list";
   
   if(push_fun!="")
   {
    employees_next_of_kin_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_employees_next_of_kin("*", ajaxw+" ("+gft_employees_next_of_kin(qstr)+") "+combined_query+"  order by primkey desc ", employees_next_of_kin_list_cols+additional_cols_str, "",employees_next_of_kin_qret_fun, "c=>"+employees_next_of_kin_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_employees_next_of_kin(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_employees_next_of_kin("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qemployees_next_of_kin_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_employees_next_of_kin("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_employees_next_of_kin("*", employees_next_of_kin_token_query, "primkey", "blackhole", employees_next_of_kin_push_ui_data_to, "");
    

}



//sum 

function sum_employees_next_of_kin(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_employees_next_of_kin("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function employees_next_of_kin_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "employees_next_of_kin_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function employees_next_of_kin_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "employees_next_of_kin_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function employees_next_of_kin_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteemployees_next_of_kin&employees_next_of_kin_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  expense_claims Data ===============
    
      function get_expense_claims(expense_claims_colstr, expense_claims_filter_col, expense_claims_cols, expense_claims_node_function_name, expense_claims_callback_function_string, expense_claims_ui_tag)
      {
        mosyflex_sel("expense_claims", expense_claims_colstr, expense_claims_filter_col , expense_claims_cols, expense_claims_node_function_name, expense_claims_callback_function_string, expense_claims_ui_tag);
        
      }
    //End get  expense_claims Data ===============

    //Start insert  expense_claims Data ===============

	function add_expense_claims(expense_claims_cols, expense_claims_vals, expense_claims_callback_function_string)
    {
		
        mosyajax_create_data("expense_claims", expense_claims_cols, expense_claims_vals, expense_claims_callback_function_string);
     }
     
    //End insert  expense_claims Data ===============

    
    //Start update  expense_claims Data ===============

    function update_expense_claims(expense_claims_update_str, expense_claims_where_str, expense_claims_callback_function_string){
    
		mosyajax_update("expense_claims", expense_claims_update_str, expense_claims_where_str, expense_claims_callback_function_string)
    
    }
    //end  update  expense_claims Data ===============

	//Start drop  expense_claims Data ===============
    function expense_claims_drop(expense_claims_where_str, expense_claims_callback_function_string)
    {
        mosyajax_drop("expense_claims", expense_claims_where_str, expense_claims_callback_function_string)

    }
	//End drop  expense_claims Data ===============
    
    function initialize_expense_claims(qstr="", expense_claims_callback_function_string="")
    {
    
    ///alert(qstr);
      var expense_claims_token_query =qstr;
      if(qstr=="")
      {
       var expense_claims_token_query_param="";
       var expense_claims_js_uptoken=mosy_get_param("expense_claims_uptoken");
       //alert(expense_claims_js_uptoken);
       if(expense_claims_js_uptoken!==undefined)
       {
       
        expense_claims_token_query_param = atob(expense_claims_js_uptoken);
       }
        expense_claims_token_query = " where primkey='"+(expense_claims_token_query_param)+"'";
        
           if (document.getElementById("expense_claims_uptoken") !==null) {
           	if(document.getElementById("expense_claims_uptoken").value!="")
            {
            
            var expense_claims_atob_tbl_key =atob(document.getElementById("expense_claims_uptoken").value);
            
                   
            expense_claims_token_query = " where primkey='"+(expense_claims_atob_tbl_key)+"'";

            }
           }
      }
      
      var expense_claims_push_ui_data_to =expense_claims_callback_function_string;
      if(expense_claims_callback_function_string=="")
      {
      expense_claims_push_ui_data_to = "add_expense_claims_ui_data";
      }
                
      console.log(expense_claims_token_query+" -- "+expense_claims_js_uptoken);

	  //alert(expense_claims_push_ui_data_to);

     get_expense_claims("*", expense_claims_token_query, "primkey", "blackhole", expense_claims_push_ui_data_to, "");
    }
    
    function add_expense_claims_ui_data(expense_claims_server_resp) 
    {
    
    ///alert(expense_claims_server_resp);
    
    var json_decoded_str=JSON.parse(expense_claims_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load expense_claims data on the fly ==============
    
	var gft_expense_claims_str="(claim_key LIKE '%{{qexpense_claims}}%' OR  transaction_date LIKE '%{{qexpense_claims}}%' OR  amount_paid LIKE '%{{qexpense_claims}}%' OR  ref_id LIKE '%{{qexpense_claims}}%' OR  staff_id LIKE '%{{qexpense_claims}}%' OR  remark LIKE '%{{qexpense_claims}}%')";
    
    function  gft_expense_claims(qexpense_claims_str)
    {
        	var clean_expense_claims_filter_str=gft_expense_claims_str.replace(/{{qexpense_claims}}/g, magic_clean_str(qexpense_claims_str));
            
            return  clean_expense_claims_filter_str;

    }
    
    function load_expense_claims(expense_claims_qstr, expense_claims_where_str, expense_claims_ret_cols, expense_claims_user_function, expense_claims_result_function, expense_claims_data_tray)
    {
    
    var fexpense_claims_result_function="push_result";
      
    if(expense_claims_result_function!="")
    {
          var fexpense_claims_result_function=expense_claims_result_function;

    }
    	var clean_expense_claims_filter_str=gft_expense_claims_str.replace(/{{qexpense_claims}}/g, magic_clean_str(expense_claims_qstr));
        
        var fexpense_claims_where_str=" where "+clean_expense_claims_filter_str;

    if(expense_claims_where_str!="")
    {
          var fexpense_claims_where_str=" "+expense_claims_where_str;

    }
       
      get_expense_claims("*", fexpense_claims_where_str, expense_claims_ret_cols, expense_claims_user_function, fexpense_claims_result_function, expense_claims_data_tray);
      
    }
    ///=============== load expense_claims data on the fly ==============


 ///=quick load 
 
 function qkload_expense_claims(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var expense_claims_list_nodes_str=expense_claims_list_nodes;
  
   if(ui_card!="")
   {
      expense_claims_list_nodes_str=ui_card;
   }
   
   var expense_claims_qret_fun="push_grid_result:expense_claims_tbl_list";
   
   if(push_fun!="")
   {
    expense_claims_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_expense_claims("*", ajaxw+" ("+gft_expense_claims(qstr)+") "+combined_query+"  order by primkey desc ", expense_claims_list_cols+additional_cols_str, "",expense_claims_qret_fun, "c=>"+expense_claims_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_expense_claims(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_expense_claims("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qexpense_claims_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_expense_claims("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_expense_claims("*", expense_claims_token_query, "primkey", "blackhole", expense_claims_push_ui_data_to, "");
    

}



//sum 

function sum_expense_claims(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_expense_claims("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function expense_claims_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "expense_claims_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function expense_claims_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "expense_claims_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function expense_claims_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteexpense_claims&expense_claims_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  job_groups Data ===============
    
      function get_job_groups(job_groups_colstr, job_groups_filter_col, job_groups_cols, job_groups_node_function_name, job_groups_callback_function_string, job_groups_ui_tag)
      {
        mosyflex_sel("job_groups", job_groups_colstr, job_groups_filter_col , job_groups_cols, job_groups_node_function_name, job_groups_callback_function_string, job_groups_ui_tag);
        
      }
    //End get  job_groups Data ===============

    //Start insert  job_groups Data ===============

	function add_job_groups(job_groups_cols, job_groups_vals, job_groups_callback_function_string)
    {
		
        mosyajax_create_data("job_groups", job_groups_cols, job_groups_vals, job_groups_callback_function_string);
     }
     
    //End insert  job_groups Data ===============

    
    //Start update  job_groups Data ===============

    function update_job_groups(job_groups_update_str, job_groups_where_str, job_groups_callback_function_string){
    
		mosyajax_update("job_groups", job_groups_update_str, job_groups_where_str, job_groups_callback_function_string)
    
    }
    //end  update  job_groups Data ===============

	//Start drop  job_groups Data ===============
    function job_groups_drop(job_groups_where_str, job_groups_callback_function_string)
    {
        mosyajax_drop("job_groups", job_groups_where_str, job_groups_callback_function_string)

    }
	//End drop  job_groups Data ===============
    
    function initialize_job_groups(qstr="", job_groups_callback_function_string="")
    {
    
    ///alert(qstr);
      var job_groups_token_query =qstr;
      if(qstr=="")
      {
       var job_groups_token_query_param="";
       var job_groups_js_uptoken=mosy_get_param("job_groups_uptoken");
       //alert(job_groups_js_uptoken);
       if(job_groups_js_uptoken!==undefined)
       {
       
        job_groups_token_query_param = atob(job_groups_js_uptoken);
       }
        job_groups_token_query = " where primkey='"+(job_groups_token_query_param)+"'";
        
           if (document.getElementById("job_groups_uptoken") !==null) {
           	if(document.getElementById("job_groups_uptoken").value!="")
            {
            
            var job_groups_atob_tbl_key =atob(document.getElementById("job_groups_uptoken").value);
            
                   
            job_groups_token_query = " where primkey='"+(job_groups_atob_tbl_key)+"'";

            }
           }
      }
      
      var job_groups_push_ui_data_to =job_groups_callback_function_string;
      if(job_groups_callback_function_string=="")
      {
      job_groups_push_ui_data_to = "add_job_groups_ui_data";
      }
                
      console.log(job_groups_token_query+" -- "+job_groups_js_uptoken);

	  //alert(job_groups_push_ui_data_to);

     get_job_groups("*", job_groups_token_query, "primkey", "blackhole", job_groups_push_ui_data_to, "");
    }
    
    function add_job_groups_ui_data(job_groups_server_resp) 
    {
    
    ///alert(job_groups_server_resp);
    
    var json_decoded_str=JSON.parse(job_groups_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load job_groups data on the fly ==============
    
	var gft_job_groups_str="(job_group_id LIKE '%{{qjob_groups}}%' OR  Job_group_name LIKE '%{{qjob_groups}}%' OR  basic_salary LIKE '%{{qjob_groups}}%' OR  employment_type LIKE '%{{qjob_groups}}%' OR  remark LIKE '%{{qjob_groups}}%' OR  owner LIKE '%{{qjob_groups}}%')";
    
    function  gft_job_groups(qjob_groups_str)
    {
        	var clean_job_groups_filter_str=gft_job_groups_str.replace(/{{qjob_groups}}/g, magic_clean_str(qjob_groups_str));
            
            return  clean_job_groups_filter_str;

    }
    
    function load_job_groups(job_groups_qstr, job_groups_where_str, job_groups_ret_cols, job_groups_user_function, job_groups_result_function, job_groups_data_tray)
    {
    
    var fjob_groups_result_function="push_result";
      
    if(job_groups_result_function!="")
    {
          var fjob_groups_result_function=job_groups_result_function;

    }
    	var clean_job_groups_filter_str=gft_job_groups_str.replace(/{{qjob_groups}}/g, magic_clean_str(job_groups_qstr));
        
        var fjob_groups_where_str=" where "+clean_job_groups_filter_str;

    if(job_groups_where_str!="")
    {
          var fjob_groups_where_str=" "+job_groups_where_str;

    }
       
      get_job_groups("*", fjob_groups_where_str, job_groups_ret_cols, job_groups_user_function, fjob_groups_result_function, job_groups_data_tray);
      
    }
    ///=============== load job_groups data on the fly ==============


 ///=quick load 
 
 function qkload_job_groups(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var job_groups_list_nodes_str=job_groups_list_nodes;
  
   if(ui_card!="")
   {
      job_groups_list_nodes_str=ui_card;
   }
   
   var job_groups_qret_fun="push_grid_result:job_groups_tbl_list";
   
   if(push_fun!="")
   {
    job_groups_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_job_groups("*", ajaxw+" ("+gft_job_groups(qstr)+") "+combined_query+"  order by primkey desc ", job_groups_list_cols+additional_cols_str, "",job_groups_qret_fun, "c=>"+job_groups_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_job_groups(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_job_groups("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qjob_groups_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_job_groups("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_job_groups("*", job_groups_token_query, "primkey", "blackhole", job_groups_push_ui_data_to, "");
    

}



//sum 

function sum_job_groups(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_job_groups("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function job_groups_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "job_groups_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function job_groups_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "job_groups_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function job_groups_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletejob_groups&job_groups_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  leave_entitlement Data ===============
    
      function get_leave_entitlement(leave_entitlement_colstr, leave_entitlement_filter_col, leave_entitlement_cols, leave_entitlement_node_function_name, leave_entitlement_callback_function_string, leave_entitlement_ui_tag)
      {
        mosyflex_sel("leave_entitlement", leave_entitlement_colstr, leave_entitlement_filter_col , leave_entitlement_cols, leave_entitlement_node_function_name, leave_entitlement_callback_function_string, leave_entitlement_ui_tag);
        
      }
    //End get  leave_entitlement Data ===============

    //Start insert  leave_entitlement Data ===============

	function add_leave_entitlement(leave_entitlement_cols, leave_entitlement_vals, leave_entitlement_callback_function_string)
    {
		
        mosyajax_create_data("leave_entitlement", leave_entitlement_cols, leave_entitlement_vals, leave_entitlement_callback_function_string);
     }
     
    //End insert  leave_entitlement Data ===============

    
    //Start update  leave_entitlement Data ===============

    function update_leave_entitlement(leave_entitlement_update_str, leave_entitlement_where_str, leave_entitlement_callback_function_string){
    
		mosyajax_update("leave_entitlement", leave_entitlement_update_str, leave_entitlement_where_str, leave_entitlement_callback_function_string)
    
    }
    //end  update  leave_entitlement Data ===============

	//Start drop  leave_entitlement Data ===============
    function leave_entitlement_drop(leave_entitlement_where_str, leave_entitlement_callback_function_string)
    {
        mosyajax_drop("leave_entitlement", leave_entitlement_where_str, leave_entitlement_callback_function_string)

    }
	//End drop  leave_entitlement Data ===============
    
    function initialize_leave_entitlement(qstr="", leave_entitlement_callback_function_string="")
    {
    
    ///alert(qstr);
      var leave_entitlement_token_query =qstr;
      if(qstr=="")
      {
       var leave_entitlement_token_query_param="";
       var leave_entitlement_js_uptoken=mosy_get_param("leave_entitlement_uptoken");
       //alert(leave_entitlement_js_uptoken);
       if(leave_entitlement_js_uptoken!==undefined)
       {
       
        leave_entitlement_token_query_param = atob(leave_entitlement_js_uptoken);
       }
        leave_entitlement_token_query = " where primkey='"+(leave_entitlement_token_query_param)+"'";
        
           if (document.getElementById("leave_entitlement_uptoken") !==null) {
           	if(document.getElementById("leave_entitlement_uptoken").value!="")
            {
            
            var leave_entitlement_atob_tbl_key =atob(document.getElementById("leave_entitlement_uptoken").value);
            
                   
            leave_entitlement_token_query = " where primkey='"+(leave_entitlement_atob_tbl_key)+"'";

            }
           }
      }
      
      var leave_entitlement_push_ui_data_to =leave_entitlement_callback_function_string;
      if(leave_entitlement_callback_function_string=="")
      {
      leave_entitlement_push_ui_data_to = "add_leave_entitlement_ui_data";
      }
                
      console.log(leave_entitlement_token_query+" -- "+leave_entitlement_js_uptoken);

	  //alert(leave_entitlement_push_ui_data_to);

     get_leave_entitlement("*", leave_entitlement_token_query, "primkey", "blackhole", leave_entitlement_push_ui_data_to, "");
    }
    
    function add_leave_entitlement_ui_data(leave_entitlement_server_resp) 
    {
    
    ///alert(leave_entitlement_server_resp);
    
    var json_decoded_str=JSON.parse(leave_entitlement_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load leave_entitlement data on the fly ==============
    
	var gft_leave_entitlement_str="(leave_cart_id LIKE '%{{qleave_entitlement}}%' OR  leave_code LIKE '%{{qleave_entitlement}}%' OR  leave_title LIKE '%{{qleave_entitlement}}%' OR  gender LIKE '%{{qleave_entitlement}}%' OR  max_days_in_year LIKE '%{{qleave_entitlement}}%' OR  leave_day LIKE '%{{qleave_entitlement}}%' OR  leave_year_starts LIKE '%{{qleave_entitlement}}%' OR  max_days_carried_fwd LIKE '%{{qleave_entitlement}}%' OR  max_negative_bal LIKE '%{{qleave_entitlement}}%' OR  eligible_employement_type LIKE '%{{qleave_entitlement}}%' OR  mandatory_attatchment LIKE '%{{qleave_entitlement}}%' OR  leave_pay LIKE '%{{qleave_entitlement}}%' OR  remark LIKE '%{{qleave_entitlement}}%' OR  owner LIKE '%{{qleave_entitlement}}%')";
    
    function  gft_leave_entitlement(qleave_entitlement_str)
    {
        	var clean_leave_entitlement_filter_str=gft_leave_entitlement_str.replace(/{{qleave_entitlement}}/g, magic_clean_str(qleave_entitlement_str));
            
            return  clean_leave_entitlement_filter_str;

    }
    
    function load_leave_entitlement(leave_entitlement_qstr, leave_entitlement_where_str, leave_entitlement_ret_cols, leave_entitlement_user_function, leave_entitlement_result_function, leave_entitlement_data_tray)
    {
    
    var fleave_entitlement_result_function="push_result";
      
    if(leave_entitlement_result_function!="")
    {
          var fleave_entitlement_result_function=leave_entitlement_result_function;

    }
    	var clean_leave_entitlement_filter_str=gft_leave_entitlement_str.replace(/{{qleave_entitlement}}/g, magic_clean_str(leave_entitlement_qstr));
        
        var fleave_entitlement_where_str=" where "+clean_leave_entitlement_filter_str;

    if(leave_entitlement_where_str!="")
    {
          var fleave_entitlement_where_str=" "+leave_entitlement_where_str;

    }
       
      get_leave_entitlement("*", fleave_entitlement_where_str, leave_entitlement_ret_cols, leave_entitlement_user_function, fleave_entitlement_result_function, leave_entitlement_data_tray);
      
    }
    ///=============== load leave_entitlement data on the fly ==============


 ///=quick load 
 
 function qkload_leave_entitlement(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var leave_entitlement_list_nodes_str=leave_entitlement_list_nodes;
  
   if(ui_card!="")
   {
      leave_entitlement_list_nodes_str=ui_card;
   }
   
   var leave_entitlement_qret_fun="push_grid_result:leave_entitlement_tbl_list";
   
   if(push_fun!="")
   {
    leave_entitlement_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_leave_entitlement("*", ajaxw+" ("+gft_leave_entitlement(qstr)+") "+combined_query+"  order by primkey desc ", leave_entitlement_list_cols+additional_cols_str, "",leave_entitlement_qret_fun, "c=>"+leave_entitlement_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_leave_entitlement(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_leave_entitlement("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qleave_entitlement_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_leave_entitlement("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_leave_entitlement("*", leave_entitlement_token_query, "primkey", "blackhole", leave_entitlement_push_ui_data_to, "");
    

}



//sum 

function sum_leave_entitlement(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_leave_entitlement("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function leave_entitlement_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "leave_entitlement_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function leave_entitlement_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "leave_entitlement_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function leave_entitlement_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteleave_entitlement&leave_entitlement_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  loan_repayment Data ===============
    
      function get_loan_repayment(loan_repayment_colstr, loan_repayment_filter_col, loan_repayment_cols, loan_repayment_node_function_name, loan_repayment_callback_function_string, loan_repayment_ui_tag)
      {
        mosyflex_sel("loan_repayment", loan_repayment_colstr, loan_repayment_filter_col , loan_repayment_cols, loan_repayment_node_function_name, loan_repayment_callback_function_string, loan_repayment_ui_tag);
        
      }
    //End get  loan_repayment Data ===============

    //Start insert  loan_repayment Data ===============

	function add_loan_repayment(loan_repayment_cols, loan_repayment_vals, loan_repayment_callback_function_string)
    {
		
        mosyajax_create_data("loan_repayment", loan_repayment_cols, loan_repayment_vals, loan_repayment_callback_function_string);
     }
     
    //End insert  loan_repayment Data ===============

    
    //Start update  loan_repayment Data ===============

    function update_loan_repayment(loan_repayment_update_str, loan_repayment_where_str, loan_repayment_callback_function_string){
    
		mosyajax_update("loan_repayment", loan_repayment_update_str, loan_repayment_where_str, loan_repayment_callback_function_string)
    
    }
    //end  update  loan_repayment Data ===============

	//Start drop  loan_repayment Data ===============
    function loan_repayment_drop(loan_repayment_where_str, loan_repayment_callback_function_string)
    {
        mosyajax_drop("loan_repayment", loan_repayment_where_str, loan_repayment_callback_function_string)

    }
	//End drop  loan_repayment Data ===============
    
    function initialize_loan_repayment(qstr="", loan_repayment_callback_function_string="")
    {
    
    ///alert(qstr);
      var loan_repayment_token_query =qstr;
      if(qstr=="")
      {
       var loan_repayment_token_query_param="";
       var loan_repayment_js_uptoken=mosy_get_param("loan_repayment_uptoken");
       //alert(loan_repayment_js_uptoken);
       if(loan_repayment_js_uptoken!==undefined)
       {
       
        loan_repayment_token_query_param = atob(loan_repayment_js_uptoken);
       }
        loan_repayment_token_query = " where primkey='"+(loan_repayment_token_query_param)+"'";
        
           if (document.getElementById("loan_repayment_uptoken") !==null) {
           	if(document.getElementById("loan_repayment_uptoken").value!="")
            {
            
            var loan_repayment_atob_tbl_key =atob(document.getElementById("loan_repayment_uptoken").value);
            
                   
            loan_repayment_token_query = " where primkey='"+(loan_repayment_atob_tbl_key)+"'";

            }
           }
      }
      
      var loan_repayment_push_ui_data_to =loan_repayment_callback_function_string;
      if(loan_repayment_callback_function_string=="")
      {
      loan_repayment_push_ui_data_to = "add_loan_repayment_ui_data";
      }
                
      console.log(loan_repayment_token_query+" -- "+loan_repayment_js_uptoken);

	  //alert(loan_repayment_push_ui_data_to);

     get_loan_repayment("*", loan_repayment_token_query, "primkey", "blackhole", loan_repayment_push_ui_data_to, "");
    }
    
    function add_loan_repayment_ui_data(loan_repayment_server_resp) 
    {
    
    ///alert(loan_repayment_server_resp);
    
    var json_decoded_str=JSON.parse(loan_repayment_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load loan_repayment data on the fly ==============
    
	var gft_loan_repayment_str="(payment_id LIKE '%{{qloan_repayment}}%' OR  loan_id LIKE '%{{qloan_repayment}}%' OR  loan_number LIKE '%{{qloan_repayment}}%' OR  date_paid LIKE '%{{qloan_repayment}}%' OR  princ_plus_int LIKE '%{{qloan_repayment}}%' OR  amount_repaid LIKE '%{{qloan_repayment}}%' OR  loan_balance LIKE '%{{qloan_repayment}}%' OR  staff_id LIKE '%{{qloan_repayment}}%' OR  owner LIKE '%{{qloan_repayment}}%' OR  remark LIKE '%{{qloan_repayment}}%')";
    
    function  gft_loan_repayment(qloan_repayment_str)
    {
        	var clean_loan_repayment_filter_str=gft_loan_repayment_str.replace(/{{qloan_repayment}}/g, magic_clean_str(qloan_repayment_str));
            
            return  clean_loan_repayment_filter_str;

    }
    
    function load_loan_repayment(loan_repayment_qstr, loan_repayment_where_str, loan_repayment_ret_cols, loan_repayment_user_function, loan_repayment_result_function, loan_repayment_data_tray)
    {
    
    var floan_repayment_result_function="push_result";
      
    if(loan_repayment_result_function!="")
    {
          var floan_repayment_result_function=loan_repayment_result_function;

    }
    	var clean_loan_repayment_filter_str=gft_loan_repayment_str.replace(/{{qloan_repayment}}/g, magic_clean_str(loan_repayment_qstr));
        
        var floan_repayment_where_str=" where "+clean_loan_repayment_filter_str;

    if(loan_repayment_where_str!="")
    {
          var floan_repayment_where_str=" "+loan_repayment_where_str;

    }
       
      get_loan_repayment("*", floan_repayment_where_str, loan_repayment_ret_cols, loan_repayment_user_function, floan_repayment_result_function, loan_repayment_data_tray);
      
    }
    ///=============== load loan_repayment data on the fly ==============


 ///=quick load 
 
 function qkload_loan_repayment(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var loan_repayment_list_nodes_str=loan_repayment_list_nodes;
  
   if(ui_card!="")
   {
      loan_repayment_list_nodes_str=ui_card;
   }
   
   var loan_repayment_qret_fun="push_grid_result:loan_repayment_tbl_list";
   
   if(push_fun!="")
   {
    loan_repayment_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_loan_repayment("*", ajaxw+" ("+gft_loan_repayment(qstr)+") "+combined_query+"  order by primkey desc ", loan_repayment_list_cols+additional_cols_str, "",loan_repayment_qret_fun, "c=>"+loan_repayment_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_loan_repayment(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_loan_repayment("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qloan_repayment_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_loan_repayment("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_loan_repayment("*", loan_repayment_token_query, "primkey", "blackhole", loan_repayment_push_ui_data_to, "");
    

}



//sum 

function sum_loan_repayment(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_loan_repayment("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function loan_repayment_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "loan_repayment_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function loan_repayment_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "loan_repayment_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function loan_repayment_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteloan_repayment&loan_repayment_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  mosy_sql_roll_back Data ===============
    
      function get_mosy_sql_roll_back(mosy_sql_roll_back_colstr, mosy_sql_roll_back_filter_col, mosy_sql_roll_back_cols, mosy_sql_roll_back_node_function_name, mosy_sql_roll_back_callback_function_string, mosy_sql_roll_back_ui_tag)
      {
        mosyflex_sel("mosy_sql_roll_back", mosy_sql_roll_back_colstr, mosy_sql_roll_back_filter_col , mosy_sql_roll_back_cols, mosy_sql_roll_back_node_function_name, mosy_sql_roll_back_callback_function_string, mosy_sql_roll_back_ui_tag);
        
      }
    //End get  mosy_sql_roll_back Data ===============

    //Start insert  mosy_sql_roll_back Data ===============

	function add_mosy_sql_roll_back(mosy_sql_roll_back_cols, mosy_sql_roll_back_vals, mosy_sql_roll_back_callback_function_string)
    {
		
        mosyajax_create_data("mosy_sql_roll_back", mosy_sql_roll_back_cols, mosy_sql_roll_back_vals, mosy_sql_roll_back_callback_function_string);
     }
     
    //End insert  mosy_sql_roll_back Data ===============

    
    //Start update  mosy_sql_roll_back Data ===============

    function update_mosy_sql_roll_back(mosy_sql_roll_back_update_str, mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string){
    
		mosyajax_update("mosy_sql_roll_back", mosy_sql_roll_back_update_str, mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string)
    
    }
    //end  update  mosy_sql_roll_back Data ===============

	//Start drop  mosy_sql_roll_back Data ===============
    function mosy_sql_roll_back_drop(mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string)
    {
        mosyajax_drop("mosy_sql_roll_back", mosy_sql_roll_back_where_str, mosy_sql_roll_back_callback_function_string)

    }
	//End drop  mosy_sql_roll_back Data ===============
    
    function initialize_mosy_sql_roll_back(qstr="", mosy_sql_roll_back_callback_function_string="")
    {
    
    ///alert(qstr);
      var mosy_sql_roll_back_token_query =qstr;
      if(qstr=="")
      {
       var mosy_sql_roll_back_token_query_param="";
       var mosy_sql_roll_back_js_uptoken=mosy_get_param("mosy_sql_roll_back_uptoken");
       //alert(mosy_sql_roll_back_js_uptoken);
       if(mosy_sql_roll_back_js_uptoken!==undefined)
       {
       
        mosy_sql_roll_back_token_query_param = atob(mosy_sql_roll_back_js_uptoken);
       }
        mosy_sql_roll_back_token_query = " where primkey='"+(mosy_sql_roll_back_token_query_param)+"'";
        
           if (document.getElementById("mosy_sql_roll_back_uptoken") !==null) {
           	if(document.getElementById("mosy_sql_roll_back_uptoken").value!="")
            {
            
            var mosy_sql_roll_back_atob_tbl_key =atob(document.getElementById("mosy_sql_roll_back_uptoken").value);
            
                   
            mosy_sql_roll_back_token_query = " where primkey='"+(mosy_sql_roll_back_atob_tbl_key)+"'";

            }
           }
      }
      
      var mosy_sql_roll_back_push_ui_data_to =mosy_sql_roll_back_callback_function_string;
      if(mosy_sql_roll_back_callback_function_string=="")
      {
      mosy_sql_roll_back_push_ui_data_to = "add_mosy_sql_roll_back_ui_data";
      }
                
      console.log(mosy_sql_roll_back_token_query+" -- "+mosy_sql_roll_back_js_uptoken);

	  //alert(mosy_sql_roll_back_push_ui_data_to);

     get_mosy_sql_roll_back("*", mosy_sql_roll_back_token_query, "primkey", "blackhole", mosy_sql_roll_back_push_ui_data_to, "");
    }
    
    function add_mosy_sql_roll_back_ui_data(mosy_sql_roll_back_server_resp) 
    {
    
    ///alert(mosy_sql_roll_back_server_resp);
    
    var json_decoded_str=JSON.parse(mosy_sql_roll_back_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load mosy_sql_roll_back data on the fly ==============
    
	var gft_mosy_sql_roll_back_str="(roll_bk_key LIKE '%{{qmosy_sql_roll_back}}%' OR  table_name LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_type LIKE '%{{qmosy_sql_roll_back}}%' OR  where_str LIKE '%{{qmosy_sql_roll_back}}%' OR  roll_timestamp LIKE '%{{qmosy_sql_roll_back}}%' OR  value_entries LIKE '%{{qmosy_sql_roll_back}}%')";
    
    function  gft_mosy_sql_roll_back(qmosy_sql_roll_back_str)
    {
        	var clean_mosy_sql_roll_back_filter_str=gft_mosy_sql_roll_back_str.replace(/{{qmosy_sql_roll_back}}/g, magic_clean_str(qmosy_sql_roll_back_str));
            
            return  clean_mosy_sql_roll_back_filter_str;

    }
    
    function load_mosy_sql_roll_back(mosy_sql_roll_back_qstr, mosy_sql_roll_back_where_str, mosy_sql_roll_back_ret_cols, mosy_sql_roll_back_user_function, mosy_sql_roll_back_result_function, mosy_sql_roll_back_data_tray)
    {
    
    var fmosy_sql_roll_back_result_function="push_result";
      
    if(mosy_sql_roll_back_result_function!="")
    {
          var fmosy_sql_roll_back_result_function=mosy_sql_roll_back_result_function;

    }
    	var clean_mosy_sql_roll_back_filter_str=gft_mosy_sql_roll_back_str.replace(/{{qmosy_sql_roll_back}}/g, magic_clean_str(mosy_sql_roll_back_qstr));
        
        var fmosy_sql_roll_back_where_str=" where "+clean_mosy_sql_roll_back_filter_str;

    if(mosy_sql_roll_back_where_str!="")
    {
          var fmosy_sql_roll_back_where_str=" "+mosy_sql_roll_back_where_str;

    }
       
      get_mosy_sql_roll_back("*", fmosy_sql_roll_back_where_str, mosy_sql_roll_back_ret_cols, mosy_sql_roll_back_user_function, fmosy_sql_roll_back_result_function, mosy_sql_roll_back_data_tray);
      
    }
    ///=============== load mosy_sql_roll_back data on the fly ==============


 ///=quick load 
 
 function qkload_mosy_sql_roll_back(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var mosy_sql_roll_back_list_nodes_str=mosy_sql_roll_back_list_nodes;
  
   if(ui_card!="")
   {
      mosy_sql_roll_back_list_nodes_str=ui_card;
   }
   
   var mosy_sql_roll_back_qret_fun="push_grid_result:mosy_sql_roll_back_tbl_list";
   
   if(push_fun!="")
   {
    mosy_sql_roll_back_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_mosy_sql_roll_back("*", ajaxw+" ("+gft_mosy_sql_roll_back(qstr)+") "+combined_query+"  order by primkey desc ", mosy_sql_roll_back_list_cols+additional_cols_str, "",mosy_sql_roll_back_qret_fun, "c=>"+mosy_sql_roll_back_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_mosy_sql_roll_back(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_mosy_sql_roll_back("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qmosy_sql_roll_back_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_mosy_sql_roll_back("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_mosy_sql_roll_back("*", mosy_sql_roll_back_token_query, "primkey", "blackhole", mosy_sql_roll_back_push_ui_data_to, "");
    

}



//sum 

function sum_mosy_sql_roll_back(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_mosy_sql_roll_back("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function mosy_sql_roll_back_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "mosy_sql_roll_back_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function mosy_sql_roll_back_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "mosy_sql_roll_back_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function mosy_sql_roll_back_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletemosy_sql_roll_back&mosy_sql_roll_back_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  payroll_list Data ===============
    
      function get_payroll_list(payroll_list_colstr, payroll_list_filter_col, payroll_list_cols, payroll_list_node_function_name, payroll_list_callback_function_string, payroll_list_ui_tag)
      {
        mosyflex_sel("payroll_list", payroll_list_colstr, payroll_list_filter_col , payroll_list_cols, payroll_list_node_function_name, payroll_list_callback_function_string, payroll_list_ui_tag);
        
      }
    //End get  payroll_list Data ===============

    //Start insert  payroll_list Data ===============

	function add_payroll_list(payroll_list_cols, payroll_list_vals, payroll_list_callback_function_string)
    {
		
        mosyajax_create_data("payroll_list", payroll_list_cols, payroll_list_vals, payroll_list_callback_function_string);
     }
     
    //End insert  payroll_list Data ===============

    
    //Start update  payroll_list Data ===============

    function update_payroll_list(payroll_list_update_str, payroll_list_where_str, payroll_list_callback_function_string){
    
		mosyajax_update("payroll_list", payroll_list_update_str, payroll_list_where_str, payroll_list_callback_function_string)
    
    }
    //end  update  payroll_list Data ===============

	//Start drop  payroll_list Data ===============
    function payroll_list_drop(payroll_list_where_str, payroll_list_callback_function_string)
    {
        mosyajax_drop("payroll_list", payroll_list_where_str, payroll_list_callback_function_string)

    }
	//End drop  payroll_list Data ===============
    
    function initialize_payroll_list(qstr="", payroll_list_callback_function_string="")
    {
    
    ///alert(qstr);
      var payroll_list_token_query =qstr;
      if(qstr=="")
      {
       var payroll_list_token_query_param="";
       var payroll_list_js_uptoken=mosy_get_param("payroll_list_uptoken");
       //alert(payroll_list_js_uptoken);
       if(payroll_list_js_uptoken!==undefined)
       {
       
        payroll_list_token_query_param = atob(payroll_list_js_uptoken);
       }
        payroll_list_token_query = " where primkey='"+(payroll_list_token_query_param)+"'";
        
           if (document.getElementById("payroll_list_uptoken") !==null) {
           	if(document.getElementById("payroll_list_uptoken").value!="")
            {
            
            var payroll_list_atob_tbl_key =atob(document.getElementById("payroll_list_uptoken").value);
            
                   
            payroll_list_token_query = " where primkey='"+(payroll_list_atob_tbl_key)+"'";

            }
           }
      }
      
      var payroll_list_push_ui_data_to =payroll_list_callback_function_string;
      if(payroll_list_callback_function_string=="")
      {
      payroll_list_push_ui_data_to = "add_payroll_list_ui_data";
      }
                
      console.log(payroll_list_token_query+" -- "+payroll_list_js_uptoken);

	  //alert(payroll_list_push_ui_data_to);

     get_payroll_list("*", payroll_list_token_query, "primkey", "blackhole", payroll_list_push_ui_data_to, "");
    }
    
    function add_payroll_list_ui_data(payroll_list_server_resp) 
    {
    
    ///alert(payroll_list_server_resp);
    
    var json_decoded_str=JSON.parse(payroll_list_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load payroll_list data on the fly ==============
    
	var gft_payroll_list_str="(payroll_id LIKE '%{{qpayroll_list}}%' OR  payroll_month_year LIKE '%{{qpayroll_list}}%' OR  payroll_date LIKE '%{{qpayroll_list}}%' OR  staff_id LIKE '%{{qpayroll_list}}%' OR  job_group LIKE '%{{qpayroll_list}}%' OR  basicsalary LIKE '%{{qpayroll_list}}%' OR  bonus_and_commissions LIKE '%{{qpayroll_list}}%' OR  deductions LIKE '%{{qpayroll_list}}%' OR  payroll_number LIKE '%{{qpayroll_list}}%' OR  nhif LIKE '%{{qpayroll_list}}%' OR  nssf LIKE '%{{qpayroll_list}}%' OR  tax LIKE '%{{qpayroll_list}}%' OR  net_salary LIKE '%{{qpayroll_list}}%' OR  payroll_notes LIKE '%{{qpayroll_list}}%' OR  owner LIKE '%{{qpayroll_list}}%' OR  allowances LIKE '%{{qpayroll_list}}%' OR  gross_sal LIKE '%{{qpayroll_list}}%' OR  loan LIKE '%{{qpayroll_list}}%')";
    
    function  gft_payroll_list(qpayroll_list_str)
    {
        	var clean_payroll_list_filter_str=gft_payroll_list_str.replace(/{{qpayroll_list}}/g, magic_clean_str(qpayroll_list_str));
            
            return  clean_payroll_list_filter_str;

    }
    
    function load_payroll_list(payroll_list_qstr, payroll_list_where_str, payroll_list_ret_cols, payroll_list_user_function, payroll_list_result_function, payroll_list_data_tray)
    {
    
    var fpayroll_list_result_function="push_result";
      
    if(payroll_list_result_function!="")
    {
          var fpayroll_list_result_function=payroll_list_result_function;

    }
    	var clean_payroll_list_filter_str=gft_payroll_list_str.replace(/{{qpayroll_list}}/g, magic_clean_str(payroll_list_qstr));
        
        var fpayroll_list_where_str=" where "+clean_payroll_list_filter_str;

    if(payroll_list_where_str!="")
    {
          var fpayroll_list_where_str=" "+payroll_list_where_str;

    }
       
      get_payroll_list("*", fpayroll_list_where_str, payroll_list_ret_cols, payroll_list_user_function, fpayroll_list_result_function, payroll_list_data_tray);
      
    }
    ///=============== load payroll_list data on the fly ==============


 ///=quick load 
 
 function qkload_payroll_list(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var payroll_list_list_nodes_str=payroll_list_list_nodes;
  
   if(ui_card!="")
   {
      payroll_list_list_nodes_str=ui_card;
   }
   
   var payroll_list_qret_fun="push_grid_result:payroll_list_tbl_list";
   
   if(push_fun!="")
   {
    payroll_list_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_payroll_list("*", ajaxw+" ("+gft_payroll_list(qstr)+") "+combined_query+"  order by primkey desc ", payroll_list_list_cols+additional_cols_str, "",payroll_list_qret_fun, "c=>"+payroll_list_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_payroll_list(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_payroll_list("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qpayroll_list_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_payroll_list("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_payroll_list("*", payroll_list_token_query, "primkey", "blackhole", payroll_list_push_ui_data_to, "");
    

}



//sum 

function sum_payroll_list(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_payroll_list("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function payroll_list_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "payroll_list_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function payroll_list_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "payroll_list_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function payroll_list_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletepayroll_list&payroll_list_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  prl_allowances Data ===============
    
      function get_prl_allowances(prl_allowances_colstr, prl_allowances_filter_col, prl_allowances_cols, prl_allowances_node_function_name, prl_allowances_callback_function_string, prl_allowances_ui_tag)
      {
        mosyflex_sel("prl_allowances", prl_allowances_colstr, prl_allowances_filter_col , prl_allowances_cols, prl_allowances_node_function_name, prl_allowances_callback_function_string, prl_allowances_ui_tag);
        
      }
    //End get  prl_allowances Data ===============

    //Start insert  prl_allowances Data ===============

	function add_prl_allowances(prl_allowances_cols, prl_allowances_vals, prl_allowances_callback_function_string)
    {
		
        mosyajax_create_data("prl_allowances", prl_allowances_cols, prl_allowances_vals, prl_allowances_callback_function_string);
     }
     
    //End insert  prl_allowances Data ===============

    
    //Start update  prl_allowances Data ===============

    function update_prl_allowances(prl_allowances_update_str, prl_allowances_where_str, prl_allowances_callback_function_string){
    
		mosyajax_update("prl_allowances", prl_allowances_update_str, prl_allowances_where_str, prl_allowances_callback_function_string)
    
    }
    //end  update  prl_allowances Data ===============

	//Start drop  prl_allowances Data ===============
    function prl_allowances_drop(prl_allowances_where_str, prl_allowances_callback_function_string)
    {
        mosyajax_drop("prl_allowances", prl_allowances_where_str, prl_allowances_callback_function_string)

    }
	//End drop  prl_allowances Data ===============
    
    function initialize_prl_allowances(qstr="", prl_allowances_callback_function_string="")
    {
    
    ///alert(qstr);
      var prl_allowances_token_query =qstr;
      if(qstr=="")
      {
       var prl_allowances_token_query_param="";
       var prl_allowances_js_uptoken=mosy_get_param("prl_allowances_uptoken");
       //alert(prl_allowances_js_uptoken);
       if(prl_allowances_js_uptoken!==undefined)
       {
       
        prl_allowances_token_query_param = atob(prl_allowances_js_uptoken);
       }
        prl_allowances_token_query = " where primkey='"+(prl_allowances_token_query_param)+"'";
        
           if (document.getElementById("prl_allowances_uptoken") !==null) {
           	if(document.getElementById("prl_allowances_uptoken").value!="")
            {
            
            var prl_allowances_atob_tbl_key =atob(document.getElementById("prl_allowances_uptoken").value);
            
                   
            prl_allowances_token_query = " where primkey='"+(prl_allowances_atob_tbl_key)+"'";

            }
           }
      }
      
      var prl_allowances_push_ui_data_to =prl_allowances_callback_function_string;
      if(prl_allowances_callback_function_string=="")
      {
      prl_allowances_push_ui_data_to = "add_prl_allowances_ui_data";
      }
                
      console.log(prl_allowances_token_query+" -- "+prl_allowances_js_uptoken);

	  //alert(prl_allowances_push_ui_data_to);

     get_prl_allowances("*", prl_allowances_token_query, "primkey", "blackhole", prl_allowances_push_ui_data_to, "");
    }
    
    function add_prl_allowances_ui_data(prl_allowances_server_resp) 
    {
    
    ///alert(prl_allowances_server_resp);
    
    var json_decoded_str=JSON.parse(prl_allowances_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load prl_allowances data on the fly ==============
    
	var gft_prl_allowances_str="(allowance_id LIKE '%{{qprl_allowances}}%' OR  allowance_title LIKE '%{{qprl_allowances}}%' OR  amount LIKE '%{{qprl_allowances}}%' OR  staff_id LIKE '%{{qprl_allowances}}%' OR  remark LIKE '%{{qprl_allowances}}%' OR  owner LIKE '%{{qprl_allowances}}%' OR  active_state LIKE '%{{qprl_allowances}}%')";
    
    function  gft_prl_allowances(qprl_allowances_str)
    {
        	var clean_prl_allowances_filter_str=gft_prl_allowances_str.replace(/{{qprl_allowances}}/g, magic_clean_str(qprl_allowances_str));
            
            return  clean_prl_allowances_filter_str;

    }
    
    function load_prl_allowances(prl_allowances_qstr, prl_allowances_where_str, prl_allowances_ret_cols, prl_allowances_user_function, prl_allowances_result_function, prl_allowances_data_tray)
    {
    
    var fprl_allowances_result_function="push_result";
      
    if(prl_allowances_result_function!="")
    {
          var fprl_allowances_result_function=prl_allowances_result_function;

    }
    	var clean_prl_allowances_filter_str=gft_prl_allowances_str.replace(/{{qprl_allowances}}/g, magic_clean_str(prl_allowances_qstr));
        
        var fprl_allowances_where_str=" where "+clean_prl_allowances_filter_str;

    if(prl_allowances_where_str!="")
    {
          var fprl_allowances_where_str=" "+prl_allowances_where_str;

    }
       
      get_prl_allowances("*", fprl_allowances_where_str, prl_allowances_ret_cols, prl_allowances_user_function, fprl_allowances_result_function, prl_allowances_data_tray);
      
    }
    ///=============== load prl_allowances data on the fly ==============


 ///=quick load 
 
 function qkload_prl_allowances(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var prl_allowances_list_nodes_str=prl_allowances_list_nodes;
  
   if(ui_card!="")
   {
      prl_allowances_list_nodes_str=ui_card;
   }
   
   var prl_allowances_qret_fun="push_grid_result:prl_allowances_tbl_list";
   
   if(push_fun!="")
   {
    prl_allowances_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_prl_allowances("*", ajaxw+" ("+gft_prl_allowances(qstr)+") "+combined_query+"  order by primkey desc ", prl_allowances_list_cols+additional_cols_str, "",prl_allowances_qret_fun, "c=>"+prl_allowances_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_prl_allowances(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_prl_allowances("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qprl_allowances_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_prl_allowances("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_prl_allowances("*", prl_allowances_token_query, "primkey", "blackhole", prl_allowances_push_ui_data_to, "");
    

}



//sum 

function sum_prl_allowances(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_prl_allowances("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function prl_allowances_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "prl_allowances_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function prl_allowances_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "prl_allowances_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function prl_allowances_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteprl_allowances&prl_allowances_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  subcriptions Data ===============
    
      function get_subcriptions(subcriptions_colstr, subcriptions_filter_col, subcriptions_cols, subcriptions_node_function_name, subcriptions_callback_function_string, subcriptions_ui_tag)
      {
        mosyflex_sel("subcriptions", subcriptions_colstr, subcriptions_filter_col , subcriptions_cols, subcriptions_node_function_name, subcriptions_callback_function_string, subcriptions_ui_tag);
        
      }
    //End get  subcriptions Data ===============

    //Start insert  subcriptions Data ===============

	function add_subcriptions(subcriptions_cols, subcriptions_vals, subcriptions_callback_function_string)
    {
		
        mosyajax_create_data("subcriptions", subcriptions_cols, subcriptions_vals, subcriptions_callback_function_string);
     }
     
    //End insert  subcriptions Data ===============

    
    //Start update  subcriptions Data ===============

    function update_subcriptions(subcriptions_update_str, subcriptions_where_str, subcriptions_callback_function_string){
    
		mosyajax_update("subcriptions", subcriptions_update_str, subcriptions_where_str, subcriptions_callback_function_string)
    
    }
    //end  update  subcriptions Data ===============

	//Start drop  subcriptions Data ===============
    function subcriptions_drop(subcriptions_where_str, subcriptions_callback_function_string)
    {
        mosyajax_drop("subcriptions", subcriptions_where_str, subcriptions_callback_function_string)

    }
	//End drop  subcriptions Data ===============
    
    function initialize_subcriptions(qstr="", subcriptions_callback_function_string="")
    {
    
    ///alert(qstr);
      var subcriptions_token_query =qstr;
      if(qstr=="")
      {
       var subcriptions_token_query_param="";
       var subcriptions_js_uptoken=mosy_get_param("subcriptions_uptoken");
       //alert(subcriptions_js_uptoken);
       if(subcriptions_js_uptoken!==undefined)
       {
       
        subcriptions_token_query_param = atob(subcriptions_js_uptoken);
       }
        subcriptions_token_query = " where primkey='"+(subcriptions_token_query_param)+"'";
        
           if (document.getElementById("subcriptions_uptoken") !==null) {
           	if(document.getElementById("subcriptions_uptoken").value!="")
            {
            
            var subcriptions_atob_tbl_key =atob(document.getElementById("subcriptions_uptoken").value);
            
                   
            subcriptions_token_query = " where primkey='"+(subcriptions_atob_tbl_key)+"'";

            }
           }
      }
      
      var subcriptions_push_ui_data_to =subcriptions_callback_function_string;
      if(subcriptions_callback_function_string=="")
      {
      subcriptions_push_ui_data_to = "add_subcriptions_ui_data";
      }
                
      console.log(subcriptions_token_query+" -- "+subcriptions_js_uptoken);

	  //alert(subcriptions_push_ui_data_to);

     get_subcriptions("*", subcriptions_token_query, "primkey", "blackhole", subcriptions_push_ui_data_to, "");
    }
    
    function add_subcriptions_ui_data(subcriptions_server_resp) 
    {
    
    ///alert(subcriptions_server_resp);
    
    var json_decoded_str=JSON.parse(subcriptions_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load subcriptions data on the fly ==============
    
	var gft_subcriptions_str="(subcription_id LIKE '%{{qsubcriptions}}%' OR  user_id LIKE '%{{qsubcriptions}}%' OR  account_id LIKE '%{{qsubcriptions}}%' OR  ref_no LIKE '%{{qsubcriptions}}%' OR  trx_date LIKE '%{{qsubcriptions}}%' OR  amount_paid LIKE '%{{qsubcriptions}}%' OR  payment_mode LIKE '%{{qsubcriptions}}%' OR  expiry_date LIKE '%{{qsubcriptions}}%' OR  remark LIKE '%{{qsubcriptions}}%')";
    
    function  gft_subcriptions(qsubcriptions_str)
    {
        	var clean_subcriptions_filter_str=gft_subcriptions_str.replace(/{{qsubcriptions}}/g, magic_clean_str(qsubcriptions_str));
            
            return  clean_subcriptions_filter_str;

    }
    
    function load_subcriptions(subcriptions_qstr, subcriptions_where_str, subcriptions_ret_cols, subcriptions_user_function, subcriptions_result_function, subcriptions_data_tray)
    {
    
    var fsubcriptions_result_function="push_result";
      
    if(subcriptions_result_function!="")
    {
          var fsubcriptions_result_function=subcriptions_result_function;

    }
    	var clean_subcriptions_filter_str=gft_subcriptions_str.replace(/{{qsubcriptions}}/g, magic_clean_str(subcriptions_qstr));
        
        var fsubcriptions_where_str=" where "+clean_subcriptions_filter_str;

    if(subcriptions_where_str!="")
    {
          var fsubcriptions_where_str=" "+subcriptions_where_str;

    }
       
      get_subcriptions("*", fsubcriptions_where_str, subcriptions_ret_cols, subcriptions_user_function, fsubcriptions_result_function, subcriptions_data_tray);
      
    }
    ///=============== load subcriptions data on the fly ==============


 ///=quick load 
 
 function qkload_subcriptions(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var subcriptions_list_nodes_str=subcriptions_list_nodes;
  
   if(ui_card!="")
   {
      subcriptions_list_nodes_str=ui_card;
   }
   
   var subcriptions_qret_fun="push_grid_result:subcriptions_tbl_list";
   
   if(push_fun!="")
   {
    subcriptions_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_subcriptions("*", ajaxw+" ("+gft_subcriptions(qstr)+") "+combined_query+"  order by primkey desc ", subcriptions_list_cols+additional_cols_str, "",subcriptions_qret_fun, "c=>"+subcriptions_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_subcriptions(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_subcriptions("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qsubcriptions_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_subcriptions("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_subcriptions("*", subcriptions_token_query, "primkey", "blackhole", subcriptions_push_ui_data_to, "");
    

}



//sum 

function sum_subcriptions(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_subcriptions("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function subcriptions_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "subcriptions_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function subcriptions_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "subcriptions_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function subcriptions_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletesubcriptions&subcriptions_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  system_admins Data ===============
    
      function get_system_admins(system_admins_colstr, system_admins_filter_col, system_admins_cols, system_admins_node_function_name, system_admins_callback_function_string, system_admins_ui_tag)
      {
        mosyflex_sel("system_admins", system_admins_colstr, system_admins_filter_col , system_admins_cols, system_admins_node_function_name, system_admins_callback_function_string, system_admins_ui_tag);
        
      }
    //End get  system_admins Data ===============

    //Start insert  system_admins Data ===============

	function add_system_admins(system_admins_cols, system_admins_vals, system_admins_callback_function_string)
    {
		
        mosyajax_create_data("system_admins", system_admins_cols, system_admins_vals, system_admins_callback_function_string);
     }
     
    //End insert  system_admins Data ===============

    
    //Start update  system_admins Data ===============

    function update_system_admins(system_admins_update_str, system_admins_where_str, system_admins_callback_function_string){
    
		mosyajax_update("system_admins", system_admins_update_str, system_admins_where_str, system_admins_callback_function_string)
    
    }
    //end  update  system_admins Data ===============

	//Start drop  system_admins Data ===============
    function system_admins_drop(system_admins_where_str, system_admins_callback_function_string)
    {
        mosyajax_drop("system_admins", system_admins_where_str, system_admins_callback_function_string)

    }
	//End drop  system_admins Data ===============
    
    function initialize_system_admins(qstr="", system_admins_callback_function_string="")
    {
    
    ///alert(qstr);
      var system_admins_token_query =qstr;
      if(qstr=="")
      {
       var system_admins_token_query_param="";
       var system_admins_js_uptoken=mosy_get_param("system_admins_uptoken");
       //alert(system_admins_js_uptoken);
       if(system_admins_js_uptoken!==undefined)
       {
       
        system_admins_token_query_param = atob(system_admins_js_uptoken);
       }
        system_admins_token_query = " where primkey='"+(system_admins_token_query_param)+"'";
        
           if (document.getElementById("system_admins_uptoken") !==null) {
           	if(document.getElementById("system_admins_uptoken").value!="")
            {
            
            var system_admins_atob_tbl_key =atob(document.getElementById("system_admins_uptoken").value);
            
                   
            system_admins_token_query = " where primkey='"+(system_admins_atob_tbl_key)+"'";

            }
           }
      }
      
      var system_admins_push_ui_data_to =system_admins_callback_function_string;
      if(system_admins_callback_function_string=="")
      {
      system_admins_push_ui_data_to = "add_system_admins_ui_data";
      }
                
      console.log(system_admins_token_query+" -- "+system_admins_js_uptoken);

	  //alert(system_admins_push_ui_data_to);

     get_system_admins("*", system_admins_token_query, "primkey", "blackhole", system_admins_push_ui_data_to, "");
    }
    
    function add_system_admins_ui_data(system_admins_server_resp) 
    {
    
    ///alert(system_admins_server_resp);
    
    var json_decoded_str=JSON.parse(system_admins_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load system_admins data on the fly ==============
    
	var gft_system_admins_str="(user_id LIKE '%{{qsystem_admins}}%' OR  name LIKE '%{{qsystem_admins}}%' OR  email LIKE '%{{qsystem_admins}}%' OR  tel LIKE '%{{qsystem_admins}}%' OR  login_password LIKE '%{{qsystem_admins}}%' OR  ref_id LIKE '%{{qsystem_admins}}%' OR  regdate LIKE '%{{qsystem_admins}}%' OR  user_no LIKE '%{{qsystem_admins}}%' OR  user_pic LIKE '%{{qsystem_admins}}%' OR  user_gender LIKE '%{{qsystem_admins}}%' OR  last_seen LIKE '%{{qsystem_admins}}%' OR  about LIKE '%{{qsystem_admins}}%')";
    
    function  gft_system_admins(qsystem_admins_str)
    {
        	var clean_system_admins_filter_str=gft_system_admins_str.replace(/{{qsystem_admins}}/g, magic_clean_str(qsystem_admins_str));
            
            return  clean_system_admins_filter_str;

    }
    
    function load_system_admins(system_admins_qstr, system_admins_where_str, system_admins_ret_cols, system_admins_user_function, system_admins_result_function, system_admins_data_tray)
    {
    
    var fsystem_admins_result_function="push_result";
      
    if(system_admins_result_function!="")
    {
          var fsystem_admins_result_function=system_admins_result_function;

    }
    	var clean_system_admins_filter_str=gft_system_admins_str.replace(/{{qsystem_admins}}/g, magic_clean_str(system_admins_qstr));
        
        var fsystem_admins_where_str=" where "+clean_system_admins_filter_str;

    if(system_admins_where_str!="")
    {
          var fsystem_admins_where_str=" "+system_admins_where_str;

    }
       
      get_system_admins("*", fsystem_admins_where_str, system_admins_ret_cols, system_admins_user_function, fsystem_admins_result_function, system_admins_data_tray);
      
    }
    ///=============== load system_admins data on the fly ==============


 ///=quick load 
 
 function qkload_system_admins(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var system_admins_list_nodes_str=system_admins_list_nodes;
  
   if(ui_card!="")
   {
      system_admins_list_nodes_str=ui_card;
   }
   
   var system_admins_qret_fun="push_grid_result:system_admins_tbl_list";
   
   if(push_fun!="")
   {
    system_admins_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_system_admins("*", ajaxw+" ("+gft_system_admins(qstr)+") "+combined_query+"  order by primkey desc ", system_admins_list_cols+additional_cols_str, "",system_admins_qret_fun, "c=>"+system_admins_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_system_admins(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_system_admins("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qsystem_admins_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_system_admins("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_system_admins("*", system_admins_token_query, "primkey", "blackhole", system_admins_push_ui_data_to, "");
    

}



//sum 

function sum_system_admins(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_system_admins("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function system_admins_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "system_admins_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function system_admins_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "system_admins_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function system_admins_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletesystem_admins&system_admins_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  system_files Data ===============
    
      function get_system_files(system_files_colstr, system_files_filter_col, system_files_cols, system_files_node_function_name, system_files_callback_function_string, system_files_ui_tag)
      {
        mosyflex_sel("system_files", system_files_colstr, system_files_filter_col , system_files_cols, system_files_node_function_name, system_files_callback_function_string, system_files_ui_tag);
        
      }
    //End get  system_files Data ===============

    //Start insert  system_files Data ===============

	function add_system_files(system_files_cols, system_files_vals, system_files_callback_function_string)
    {
		
        mosyajax_create_data("system_files", system_files_cols, system_files_vals, system_files_callback_function_string);
     }
     
    //End insert  system_files Data ===============

    
    //Start update  system_files Data ===============

    function update_system_files(system_files_update_str, system_files_where_str, system_files_callback_function_string){
    
		mosyajax_update("system_files", system_files_update_str, system_files_where_str, system_files_callback_function_string)
    
    }
    //end  update  system_files Data ===============

	//Start drop  system_files Data ===============
    function system_files_drop(system_files_where_str, system_files_callback_function_string)
    {
        mosyajax_drop("system_files", system_files_where_str, system_files_callback_function_string)

    }
	//End drop  system_files Data ===============
    
    function initialize_system_files(qstr="", system_files_callback_function_string="")
    {
    
    ///alert(qstr);
      var system_files_token_query =qstr;
      if(qstr=="")
      {
       var system_files_token_query_param="";
       var system_files_js_uptoken=mosy_get_param("system_files_uptoken");
       //alert(system_files_js_uptoken);
       if(system_files_js_uptoken!==undefined)
       {
       
        system_files_token_query_param = atob(system_files_js_uptoken);
       }
        system_files_token_query = " where primkey='"+(system_files_token_query_param)+"'";
        
           if (document.getElementById("system_files_uptoken") !==null) {
           	if(document.getElementById("system_files_uptoken").value!="")
            {
            
            var system_files_atob_tbl_key =atob(document.getElementById("system_files_uptoken").value);
            
                   
            system_files_token_query = " where primkey='"+(system_files_atob_tbl_key)+"'";

            }
           }
      }
      
      var system_files_push_ui_data_to =system_files_callback_function_string;
      if(system_files_callback_function_string=="")
      {
      system_files_push_ui_data_to = "add_system_files_ui_data";
      }
                
      console.log(system_files_token_query+" -- "+system_files_js_uptoken);

	  //alert(system_files_push_ui_data_to);

     get_system_files("*", system_files_token_query, "primkey", "blackhole", system_files_push_ui_data_to, "");
    }
    
    function add_system_files_ui_data(system_files_server_resp) 
    {
    
    ///alert(system_files_server_resp);
    
    var json_decoded_str=JSON.parse(system_files_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load system_files data on the fly ==============
    
	var gft_system_files_str="(file_id LIKE '%{{qsystem_files}}%' OR  file_title LIKE '%{{qsystem_files}}%' OR  file_type LIKE '%{{qsystem_files}}%' OR  file_url LIKE '%{{qsystem_files}}%' OR  item_id LIKE '%{{qsystem_files}}%' OR  owner LIKE '%{{qsystem_files}}%')";
    
    function  gft_system_files(qsystem_files_str)
    {
        	var clean_system_files_filter_str=gft_system_files_str.replace(/{{qsystem_files}}/g, magic_clean_str(qsystem_files_str));
            
            return  clean_system_files_filter_str;

    }
    
    function load_system_files(system_files_qstr, system_files_where_str, system_files_ret_cols, system_files_user_function, system_files_result_function, system_files_data_tray)
    {
    
    var fsystem_files_result_function="push_result";
      
    if(system_files_result_function!="")
    {
          var fsystem_files_result_function=system_files_result_function;

    }
    	var clean_system_files_filter_str=gft_system_files_str.replace(/{{qsystem_files}}/g, magic_clean_str(system_files_qstr));
        
        var fsystem_files_where_str=" where "+clean_system_files_filter_str;

    if(system_files_where_str!="")
    {
          var fsystem_files_where_str=" "+system_files_where_str;

    }
       
      get_system_files("*", fsystem_files_where_str, system_files_ret_cols, system_files_user_function, fsystem_files_result_function, system_files_data_tray);
      
    }
    ///=============== load system_files data on the fly ==============


 ///=quick load 
 
 function qkload_system_files(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var system_files_list_nodes_str=system_files_list_nodes;
  
   if(ui_card!="")
   {
      system_files_list_nodes_str=ui_card;
   }
   
   var system_files_qret_fun="push_grid_result:system_files_tbl_list";
   
   if(push_fun!="")
   {
    system_files_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_system_files("*", ajaxw+" ("+gft_system_files(qstr)+") "+combined_query+"  order by primkey desc ", system_files_list_cols+additional_cols_str, "",system_files_qret_fun, "c=>"+system_files_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_system_files(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_system_files("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qsystem_files_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_system_files("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_system_files("*", system_files_token_query, "primkey", "blackhole", system_files_push_ui_data_to, "");
    

}



//sum 

function sum_system_files(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_system_files("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function system_files_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "system_files_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function system_files_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "system_files_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function system_files_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deletesystem_files&system_files_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


   

    //Start get  ux_table Data ===============
    
      function get_ux_table(ux_table_colstr, ux_table_filter_col, ux_table_cols, ux_table_node_function_name, ux_table_callback_function_string, ux_table_ui_tag)
      {
        mosyflex_sel("ux_table", ux_table_colstr, ux_table_filter_col , ux_table_cols, ux_table_node_function_name, ux_table_callback_function_string, ux_table_ui_tag);
        
      }
    //End get  ux_table Data ===============

    //Start insert  ux_table Data ===============

	function add_ux_table(ux_table_cols, ux_table_vals, ux_table_callback_function_string)
    {
		
        mosyajax_create_data("ux_table", ux_table_cols, ux_table_vals, ux_table_callback_function_string);
     }
     
    //End insert  ux_table Data ===============

    
    //Start update  ux_table Data ===============

    function update_ux_table(ux_table_update_str, ux_table_where_str, ux_table_callback_function_string){
    
		mosyajax_update("ux_table", ux_table_update_str, ux_table_where_str, ux_table_callback_function_string)
    
    }
    //end  update  ux_table Data ===============

	//Start drop  ux_table Data ===============
    function ux_table_drop(ux_table_where_str, ux_table_callback_function_string)
    {
        mosyajax_drop("ux_table", ux_table_where_str, ux_table_callback_function_string)

    }
	//End drop  ux_table Data ===============
    
    function initialize_ux_table(qstr="", ux_table_callback_function_string="")
    {
    
    ///alert(qstr);
      var ux_table_token_query =qstr;
      if(qstr=="")
      {
       var ux_table_token_query_param="";
       var ux_table_js_uptoken=mosy_get_param("ux_table_uptoken");
       //alert(ux_table_js_uptoken);
       if(ux_table_js_uptoken!==undefined)
       {
       
        ux_table_token_query_param = atob(ux_table_js_uptoken);
       }
        ux_table_token_query = " where primkey='"+(ux_table_token_query_param)+"'";
        
           if (document.getElementById("ux_table_uptoken") !==null) {
           	if(document.getElementById("ux_table_uptoken").value!="")
            {
            
            var ux_table_atob_tbl_key =atob(document.getElementById("ux_table_uptoken").value);
            
                   
            ux_table_token_query = " where primkey='"+(ux_table_atob_tbl_key)+"'";

            }
           }
      }
      
      var ux_table_push_ui_data_to =ux_table_callback_function_string;
      if(ux_table_callback_function_string=="")
      {
      ux_table_push_ui_data_to = "add_ux_table_ui_data";
      }
                
      console.log(ux_table_token_query+" -- "+ux_table_js_uptoken);

	  //alert(ux_table_push_ui_data_to);

     get_ux_table("*", ux_table_token_query, "primkey", "blackhole", ux_table_push_ui_data_to, "");
    }
    
    function add_ux_table_ui_data(ux_table_server_resp) 
    {
    
    ///alert(ux_table_server_resp);
    
    var json_decoded_str=JSON.parse(ux_table_server_resp)[0];
    
      var keys = Object.keys(json_decoded_str);

      for (var i = 0; i < keys.length; i++) {
          var val = json_decoded_str[keys[i]];
          ///console.log(" Key -- "+keys[i]+" val -- "+val);
          
          mosy_push_data("txt_"+keys[i], val);
          mosy_push_data("txt_"+keys[i]+"_disp", val);
          mosy_push_data("div_txt_"+keys[i], val);
          mosy_push_data("src_"+keys[i], val);
          mosy_push_data("href_"+keys[i], val);
          mosy_push_data("sel_"+keys[i], val);
          // use val
      }
        
    }
    

    ///=============== load ux_table data on the fly ==============
    
	var gft_ux_table_str="(ux_id LIKE '%{{qux_table}}%' OR  ux_key LIKE '%{{qux_table}}%' OR  ux_value LIKE '%{{qux_table}}%' OR  ux_type LIKE '%{{qux_table}}%' OR  ux_state LIKE '%{{qux_table}}%' OR  remark LIKE '%{{qux_table}}%')";
    
    function  gft_ux_table(qux_table_str)
    {
        	var clean_ux_table_filter_str=gft_ux_table_str.replace(/{{qux_table}}/g, magic_clean_str(qux_table_str));
            
            return  clean_ux_table_filter_str;

    }
    
    function load_ux_table(ux_table_qstr, ux_table_where_str, ux_table_ret_cols, ux_table_user_function, ux_table_result_function, ux_table_data_tray)
    {
    
    var fux_table_result_function="push_result";
      
    if(ux_table_result_function!="")
    {
          var fux_table_result_function=ux_table_result_function;

    }
    	var clean_ux_table_filter_str=gft_ux_table_str.replace(/{{qux_table}}/g, magic_clean_str(ux_table_qstr));
        
        var fux_table_where_str=" where "+clean_ux_table_filter_str;

    if(ux_table_where_str!="")
    {
          var fux_table_where_str=" "+ux_table_where_str;

    }
       
      get_ux_table("*", fux_table_where_str, ux_table_ret_cols, ux_table_user_function, fux_table_result_function, ux_table_data_tray);
      
    }
    ///=============== load ux_table data on the fly ==============


 ///=quick load 
 
 function qkload_ux_table(qstr, push_fun="", ui_card="", and_query="", additional_cols="")
{

	var ux_table_list_nodes_str=ux_table_list_nodes;
  
   if(ui_card!="")
   {
      ux_table_list_nodes_str=ui_card;
   }
   
   var ux_table_qret_fun="push_grid_result:ux_table_tbl_list";
   
   if(push_fun!="")
   {
    ux_table_qret_fun=push_fun;
   }
   
   var combined_query ="";
   
   if(and_query!="")
   {
   combined_query=" and "+and_query;
   }
   
   var additional_cols_str=","+additional_cols;
   
   if(additional_cols=="")
   {
   	 additional_cols_str="";
   }
   
   get_ux_table("*", ajaxw+" ("+gft_ux_table(qstr)+") "+combined_query+"  order by primkey desc ", ux_table_list_cols+additional_cols_str, "",ux_table_qret_fun, "c=>"+ux_table_list_nodes_str);
                  
}


////////////// arithmetic function 


//count 

function count_ux_table(where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_ux_table("count(*) as tot_item_count", qwhere_str, "tot_item_count", "",""+callback_function_string_str+":"+push_to+"|tot_item_count", "");
    

}


//qddata
function qux_table_ddata(where_str, disp_col , push_to, callback_function_string="")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_ddata";

      
      }
      
   get_ux_table("*", qwhere_str, disp_col, "", ""+callback_function_string_str+":"+push_to+"|"+disp_col+"", "");
   ///get_ux_table("*", ux_table_token_query, "primkey", "blackhole", ux_table_push_ui_data_to, "");
    

}



//sum 

function sum_ux_table(sum_col, where_str, push_to, callback_function_string="", num_form="yes")
{
      var qwhere_str=" where "+where_str+" ";
      var callback_function_string_str=callback_function_string;
      
      if(where_str=="")
      {     
      qwhere_str="";
      }
      
      if(callback_function_string=="")      
      {
      
      	callback_function_string_str="mosy_push_num_ddata";
        if(num_form!="yes")
        {             	
          callback_function_string_str="mosy_push_num_data";

        }
      
      }
      
   get_ux_table("sum("+sum_col+") as tot_item_sum", qwhere_str, "tot_item_sum", "",""+callback_function_string_str+":"+push_to+"|tot_item_sum", "");
    

}


///request handlers 

function ux_table_ins_(formid, required_inp=null, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "ux_table_insert_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
}

function ux_table_updt_(formid, required_inp, callback_function_string="")
{

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }

	var validate_req="True";
    
  for(curr_input of required_inp)
    {
     validate_req +=magic_validate_required('', curr_input);
    }
    
    //alert(validate_req);
    
    if(mosy_qstr(validate_req, 'False')=='False')
      {
 
 		mosy_form_data(formid, "ux_table_update_btn", callback_function_string_str);
        
  	  }else{
        magic_message('Fill out the required fields', 'dialog_box');
      }
      

}


function ux_table_rem_(req_token, callback_function_string="")
{


	///alert(req_token+" --"+callback_function_string);

 var callback_function_string_str=callback_function_string;
 
 if(callback_function_string=="")
 
 {
 	callback_function_string_str="blackhole";
 }
 
 mosyajax_get('conf_deleteux_table&ux_table_uptoken='+magic_clean_str(req_token)+'', callback_function_string_str);

}


  //===============End Mosy queries-============

const mosy_msdn_elem = document.querySelectorAll('.mosy_msdn');

mosy_msdn_elem.forEach(el => el.addEventListener('click', event => {

var arguments = event.target.getAttribute("data-mosy_msdn");
  
eval(arguments);

}));

const mosy_tup_elem = document.querySelectorAll('.mosy_tup');

mosy_tup_elem.forEach(el => el.addEventListener('keyup', event => {

var arguments = event.target.getAttribute("data-mosy_tup");
  
eval(arguments);

}));
  
var ajax_url ="./ajaxreqhandler.php";
var mosyajax_sql_url=ajax_url;
   //Ajax Manager
function mosyflex_sel(tbl, colstr, filter_col , cols, node_function_name, callback_function_string, ui_tag)
{
//alert(filter_col);

    var clean_ui1=ui_tag.replace(/</g, "{{<}}");
    var clean_ui2=clean_ui1.replace(/>/g, "{{>}}");
    var clean_ui3=clean_ui2.replace(/onclick/g, "{{on click}}");
    var clean_ui4=clean_ui3.replace(/onkeyup/g, "{{on keyup}}");
    var clean_ui=clean_ui4.replace(/onchange/g, "{{on change}}");
    
    var json_params_str={"mosyajax_sql_data":filter_col, "colstr":colstr, "cols":cols, "node_function_name":node_function_name, "tbl":tbl, "ui_tag":clean_ui};
   
  	//alert(clean_ui);
  
	mosy_ajax_post(ajax_url, json_params_str, callback_function_string, "");
}

function push_result(server_resp, additional_callbacks)
{
  //alert(server_resp);
  
  var str_to_display=server_resp+'<div class="col-md-12 p-0 text-right"><span class="badge cpointer" style="font-size:10px;"><i class="fa fa-times-circle"></i> Close</span></div>';
  
  if(server_resp.toString().trim()=='')
  {
  	var str_to_display='<div class="row justify-content-center p-2 mb-3 text-center col-md-12 no_data_tray"> <div class=" text-wrap col-md-12"><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class="col-md-6 text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div> </div>';
  }
  
  
  if (document.getElementById(additional_callbacks) !==null) {
        
  document.getElementById(additional_callbacks).style.display="block";
  document.getElementById(additional_callbacks).innerHTML=str_to_display;
        
    }else{
          
    document.getElementById("result").innerHTML=server_resp;

    };
}


function push_grid_result(server_resp, additional_callbacks)
{
  //alert(server_resp);
  
  var str_to_display=server_resp;
  
  var tbl_col_str="";
  var tbl_colspan ="";
  var elem_id=additional_callbacks;

  if(additional_callbacks.indexOf(":") >= 0)
  {
     tbl_col_str=additional_callbacks.split(":");
     
     tbl_colspan=tbl_col_str[1];
     
     elem_id=tbl_col_str[0];

  }
///alert(additional_callbacks);
  if(server_resp.toString().trim()=='')
  {
  	if(tbl_colspan!="")
    {
      	var str_to_display='<tr class=" no_data_tray_grid" > <td colspan="'+tbl_colspan+'" style="text-align:center;"><div class=" text-wrap col-md-12"><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class="col-md-12 text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div></td> </tr>';

    }else{
        
  	var str_to_display='<div class="row justify-content-center p-2 mb-3 text-center col-md-12 no_data_tray_grid" > <div class=" text-wrap col-md-12"><i class="fa fa-search"></i> Sorry. We didn`t find results matching this request.<hr></div> <div class="col-md-6 text-dark text-center cpointer  p-1 rounded mb-3"><i class="fa fa-star"></i> Lets try a new search</div> </div>';
    
    }
  }
  
  
  if (document.getElementById(elem_id) !==null) {
        
  ///document.getElementById(elem_id).style.display="block";
  document.getElementById(elem_id).innerHTML=str_to_display;
        
    }else{
          
    document.getElementById("result").innerHTML=server_resp;

    };
}


function push_val(arrkeys, arrvalues)
{
    var r = {},i;
    
    for (let i = 0; i < arrkeys.length; i++) {
        r[arrkeys[i]] = arrvalues[i];
      document.getElementById(arrvalues[i]).value=[arrkeys[i]];
    }

}

    function qddata(server_resp,callbacks)
    {
    //alert(server_resp);
    var retjson = JSON.parse(server_resp)[0];
    
        ///alert(retjson.name);


    return retjson;
    
    
    }
function mosy_ajax_post(post_url, json_params, callback_function_string, additional_callbacks)
{

 
	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = additional_callbacks;
    
    if(callback_function_string.indexOf(":") >= 0)
    {
         split_fun_str=callback_function_string.split(/:(.*)/s);
         
		 fcall_back_function =  split_fun_str[0];
        
         fadditional_callbacks =  split_fun_str[1] ;
    
    }
    
    //alert(fcall_back_function);
    
    if (document.getElementById(fadditional_callbacks) !==null) {
      ////  document.getElementById(fadditional_callbacks).style.display="block";
    	///document.getElementById(fadditional_callbacks).innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... '+document.getElementById(fadditional_callbacks).innerHTML;
        
    }
    
       if (document.getElementById("ajax_spinner") !==null) 
       {
            
          document.getElementById("ajax_spinner").style.display="block";
          document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... ';

       } 
       
  	var formData = ((json_params)); //Array 
  
      $.ajax({ 
      url: post_url,
      type: "POST",
      data:formData,

      success: function (data) 
      {
        //alert(data);
       if (document.getElementById("ajax_spinner") !==null) 
       {
       
         var result_response_='<i class="fa fa-info-circle"></i> Request Processed Succesfully.';
		
        	if(data=='')
            {
            
        		var result_response_='<i class="fa fa-info-circle"></i> No data .';
            
            }
            
          document.getElementById("ajax_spinner").style.display="block";
          document.getElementById("ajax_spinner").innerHTML=result_response_;

       } 
        window[fcall_back_function](data, fadditional_callbacks);

      }

  })
  
}  


   //Ajax Manager

function mosyajax_create_data(tbl, tbl_cols, tbl_vals, callback_function_string)
{
  ///alert(tbl_cols+" - "+tbl_vals);
  
    var json_params_str={"mosyajax_create":"ok", "tbl_cols":tbl_cols, "tbl_vals":tbl_vals, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}

   //Ajax Exe
function mosyajax_update(tbl, update_str, where_str, callback_function_string)
{
  //alert(update_str);
  
    var json_params_str={"mosyajax_update":"ok", "update_str":update_str, "where_str":where_str, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}

function mosyajax_drop(tbl, where_str, callback_function_string)
{
  //alert(where_str);
  
    var json_params_str={"mosyajax_drop":"ok", "where_str":where_str, "tbl":tbl};
    
  	mosy_ajax_post(mosyajax_sql_url, json_params_str, callback_function_string, '');

}


function mosyajax_get(getstr, callback_function_string)
{

	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = "";
    
    if(callback_function_string.indexOf(":") >= 0)
    {
		var split_call_back = callback_function_string.split(":");
        
		var fcall_back_function = split_call_back[0];
        
        var fadditional_callbacks = split_call_back[1];
    
    }
    
    
    if (document.getElementById("ajax_spinner") !==null) 
    {
        
      document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

  	}

    $.ajax({
      url: ajax_url+"?"+getstr,
      type: 'GET',
      success: function(res) {
       if (document.getElementById("ajax_spinner") !==null) {

          document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

       }              
            //alert(res);
        window[fcall_back_function](res, fadditional_callbacks);

          }
      });
}


function mosy_form_data(form_id,  save_action, callback_function_string, additional_callbacks)
{

	var fcall_back_function = callback_function_string;
    
	var fadditional_callbacks = additional_callbacks;
    
    if(callback_function_string.indexOf(":") >= 0)
    {
		var split_call_back = callback_function_string.split(":");
        
		var fcall_back_function = split_call_back[0];
        
        var fadditional_callbacks = split_call_back[1];
    
    }
    
    
	var formData = new FormData(document.getElementById(form_id));
  
    if (document.getElementById("ajax_spinner") !==null) {
        
    	document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-spinner fa-spin"></i> Processing request... ';
        
    }
	formData.append(save_action, "ok");
	formData.append('mosyrequest_type', "ajax");
        $.ajax({
            type: "POST",
            url: ajax_url,
            data: formData,
            contentType: false,
            cache: false,
            processData:false,
            success: function(data){
                  if (document.getElementById("ajax_spinner") !==null) {
        
                      document.getElementById("ajax_spinner").innerHTML='<i class="fa fa-check-circle"></i> Request Processed Succesfully. <span class="badge badge-primary btn_neo"><i class="fa fa-thumbs-up"></i> OK </span>';

                  }
              ///alert(data);
        		window[fcall_back_function](data, fadditional_callbacks);
            },
	    complete: function(){
			//alert("Data uploaded successfully.");
	    },
	    error: function (jqXHR, textStatus, errorThrown) {
			alert(errorThrown);
	    } 
        });
      // Display the key/value pairs
      for (var pair of formData.entries()) {
          console.log(pair[0]+ ", " + pair[1]); 
      }
}

function blackhole(data)
{

}

function mosy_reload()
{
   document.location.reload()

} 

function show_password(input_name) 
{
  var x = document.getElementById(input_name);
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}


function get_newval(elemid)
{
    if (document.getElementById(elemid) !==null) {

	  return document.getElementById(elemid).value;
    }else{
  
  return "";
  }
}

function get_html(elemid)
{
    if (document.getElementById(elemid) !==null) {

  return document.getElementById(elemid).innerHTML;
  }else{
  
  return "";
  }
}

function get_src(elemid)
{
  if (document.getElementById(elemid) !==null) {

  return document.getElementById(elemid).src;
  }else{
  
  return "";
  }
}

function get_href(elemid)
{
  if (document.getElementById(elemid) !==null) {

  return document.getElementById(elemid).href;
  }else{
  
  return "";
  }
}


function push_ddown(server_items, selelem)
{

	$('#'+selelem+' option:not(:first)').remove();

	document.getElementById(selelem).innerHTML=document.getElementById(selelem).innerHTML+server_items;

}
//========= formart to num =================

function tonum(req_number, decplc=0)
{

///alert(req_number);

n = parseFloat(req_number).toFixed(decplc)
var withCommas = Number(n).toLocaleString('en');


return withCommas;
}

//========= formart to num =================

function mosy_qstr(string, query_str)
{
    
   if(string.indexOf(query_str)==-1)
    {
      
      var q_str_state="False";
      
    }else{
    
	  var q_str_state="True";
     
	}
    
  return q_str_state;
    
}
function mosy_refresh(new_location)
{

var new_location_str=window.location.href;

  window.location=new_location_str.replace("table_alert", "tbl_alert_old");

}


////////////////// ===================  js action listener ================  

  var _js_msdn=document.querySelectorAll('js_msdn');
  
  _js_msdn.forEach(el => el.addEventListener('click', event => {
  
  var _mosy_jsmsdn_event_trgt= event.currentTarget;

  
	 _mosy_jsmsdn_jsaction="";
	 _mosy_jsmsdn_arg="";
     
  if (!_mosy_jsmsdn_event_trgt.hasAttribute("data-mosy_js")) 
  {
    // data attribute doesnt exist
  }else{
  
	 _mosy_jsmsdn_jsaction=_mosy_jsmsdn_event_trgt.getAttribute("data-mosy_js");
	 _mosy_jsmsdn_arg=_mosy_jsmsdn_event_trgt.getAttribute("data-_mosy_jsmsdn_arg");
     
  }

     window[_mosy_jsmsdn_jsaction](_mosy_jsmsdn_arg);

  
}));
  
  
  
////////////////// ==================  js action listener ================  



function pop_filter_tray (data_src, card_title, where_str_req,cols,returnfun)
{
  magic_screen(pop_data_filter_card, "alert_box");
        
  var where_str =" and "+(where_str_req);
  var where_str_inp =" and "+magic_clean_str(where_str_req);
  
  if(where_str_req=="")
  {
    var where_str="";
    var where_str_inp ="";
  }
  
  var load_data_set ="load_"+data_src;
  var gft_data_str="gft_"+data_src;
  ///alert(where_str);
  window[load_data_set]("", ajaxw+" "+window[gft_data_str]("")+where_str, cols, returnfun, "push_result:result","card");
  
  //alert(cols);
  var textbox ='<input type="text" class="form-control" onkeyup="'+load_data_set+'(this.value, \''+ajaxw+' \'+'+gft_data_str+'(this.value)+\''+where_str_inp+'\', \''+magic_clean_str(cols)+'\', \''+returnfun+'\', \'push_result:result\',\'card\')" placeholder="Type your search here"/>';
        
  document.getElementById('card_title').innerHTML=card_title;
  document.getElementById('dope_text').innerHTML=textbox;

        
}

function tray_uptoken(datakey,callbacks)
{
  
  window.location=callbacks[0]+'?'+callbacks[1]+'_uptoken='+btoa(datakey[0]);
}

var pop_data_filter_card=`
    <h5><i class="fa fa-search mr-2"></i><span id="card_title"></span></h5>
	<hr>
  <div class="row justify-content-center m-0 p-0 col-md-12">
  	<div id="dope_text" class="col-md-12"></div>
	<div id="result" class="col-md-12" style="max-height:300px; overflow-y:auto;" onclick="this.style.display='none'"></div>
    
  	<div id="r" class="col-md-12 row justify-content-center m-0 p-0 mt-3">
    	<a href="" class="badge border border_set p-2 rounded text-primary col-md-5 mr-lg-3" id="pop_tray_location"> 
        	View All <i class="fa fa-arrow-right"></i> 
        </a>
    	<a href="" class="badge border border_set p-2 rounded text-primary col-md-5" id="new_pop_tray_location"> 
        	<i class="fa fa-plus" id="newclass"></i> 
        	<span id="new_record_label"> Add new </span> 
        </a>
    </div>
  </div>`;
  
function push_link(new_link,anchor_el)
{

	//alert(new_link);
	document.getElementById(anchor_el).href=new_link;

}


function push_html(elemid, new_val)
{
    if (document.getElementById(elemid) !==null) {

	  document.getElementById(elemid).innerHTML=new_val;
      
      }
}

function push_newval(elemid, new_val)
{
    if (document.getElementById(elemid) !==null) {

  		document.getElementById(elemid).value=new_val;
  
  }
}

function push_src(elemid, new_val)
{
	    if (document.getElementById(elemid) !==null) {

	  		document.getElementById(elemid).src=new_val;
      
      }
}

function mosytoggle_class(elemid, new_class)
{
  if(document.getElementById(elemid).classList.contains(new_class))
  {
    document.getElementById(elemid).classList.remove(new_class);
  }else{
    document.getElementById(elemid).classList.add(new_class);
  }
  
}


function mosyhide_elem(elemid, new_class="")
{
    var curr_class="none";
    if(new_class!="")
    {
    curr_class=new_class;
    }
   document.getElementById(elemid).style.display=curr_class;

}

function mosyshow_elem(elemid, new_class="")
{
    var curr_class="block";
    if(new_class!="")
    {
    curr_class=new_class;
    }
   document.getElementById(elemid).style.display=curr_class;

}

function mosy_get_param(name){
   if(name=(new RegExp('[?&]'+encodeURIComponent(name)+'=([^&]*)')).exec(location.search))
      return decodeURIComponent(name[1]);
}


function mosy_push_data(elemid,data)
{
	var elem_state ="false";
    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
      
      push_newval(elemid, data);
      push_html(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, "<option>"+data+"</option>"+get_html(elemid));
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  
}

function check_elem(elemid)
{
    if (document.getElementById(elemid) ===null) 
    {
    alert("element_"+elemid+" Not available");
    }
}

function push_shtml(server_res, callback)
{
  
  magic_message(callback, "dialog_box");
  
}
function mosy_push_num_ddata(_server_resp, elemid_str)
{
	//alert(_server_resp);
    
	var elem_state ="false";
    var elemid=",,";    
    var json_decoded_str=JSON.parse(_server_resp)[0];
        
    var data_str=elemid_str;
    
    var data = json_decoded_str[data_str];

    if(elemid_str.indexOf("|") >= 0)
    {
		var elemid_arr = elemid_str.split("|");
        
		 elemid = (elemid_arr[0]);
        
          data_str = elemid_arr[1];
          
          console.log(elemid+" state "+ data_str+" serep "+_server_resp);

         data = tonum(json_decoded_str[data_str]);
        
    }
    
    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
            
      push_html(elemid, data);
      push_newval(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, data);
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  return json_decoded_str;
}

function mosy_push_ddata(_server_resp, elemid_str)
{

///alert(_server_resp);

	var elem_state ="false";
    var elemid=",,";    
    var json_decoded_str=JSON.parse(_server_resp)[0];
        
    var data_str=elemid_str;
    
    var data = json_decoded_str[data_str];

    if(elemid_str.indexOf("|") >= 0)
    {
		var elemid_arr = elemid_str.split("|");
        
		 elemid = elemid_arr[0];
        
          data_str = elemid_arr[1];
          

         data = json_decoded_str[data_str];
        
    }
              
    console.log(elemid+" state "+ data_str+" serep "+_server_resp);

    if (document.getElementById(elemid) !==null) 
    {
      elem_state="true";
      push_html(elemid, data);      
      push_newval(elemid, data);
      var elem_type=(document.getElementById(elemid).nodeName).toLowerCase();

      if(elem_type=='span')
      {
        push_html(elemid, data);
      }
       if(elem_type=='select')
      {
        push_html(elemid, data);
      }

      if(elem_type=='img')
      {
        push_src(elemid, data);
      }
      if(elem_type=='a')
      {
        push_link(elemid, data);
      }
  
  }
  
  ///console.log(elemid+" state "+ elem_state);
  return json_decoded_str;
}


///////////////  slide show 
function mosy_slide_wgt(image_arr_n_captions, img_style, img_class, extra_attr, slide_indicators_yes_no)
{
  
const rem_array = image_arr_n_captions.slice(0, 0).concat(image_arr_n_captions.slice(0+1, image_arr_n_captions.length));
  
var curr_slide_id =magic_random_str(10);
    
var img_string =  image_arr_n_captions[0];
var caption_str = ""
var caption_str_div="";
var datakey = "";
  
if(image_arr_n_captions[0].includes(":"))
{
 img_string =  image_arr_n_captions[0].substring(0, image_arr_n_captions[0].indexOf(':')); 
 datakey_1 = image_arr_n_captions[0].substring(image_arr_n_captions[0].indexOf(':')+1); 
 datakey = datakey_1.substring(0, datakey_1.indexOf(':'));
 datakey_2 = datakey_1.substring(datakey_1.indexOf(':')+1);
 caption_str = datakey_2.substring(datakey_2.indexOf(':'));
 caption_str_div=`<div class="col-md-12 text-center  pb-4"> ${caption_str} </div>`;
}
  ///alert("dkey1 -- "+datakey_2);
 var slide_node="";
 var slidecounter="";
 var i=0;
  
 if(slide_indicators_yes_no=='yes')
 {
   slidecounter=`<li data-target="#slide_s${curr_slide_id}" data-slide-to="0" class="active"></li>`;
 }
 for(img_arr of rem_array)
 {
   i++;
   
	if(slide_indicators_yes_no=='yes'){
 slidecounter+=`
        <li data-target="#slide_s${curr_slide_id}" data-slide-to="${i}" class="active"></li>
   `;  
    }
   
   var loop_img_string =  img_arr;
   var loop_caption_str = "";
   var loop_caption_str_div="";
   var loop_datakey="";
   
   if(img_arr.includes(":")){
 	loop_img_string =  img_arr.substring(0, img_arr.indexOf(':')); 
 	loop_datakey_1 = img_arr.substring(img_arr.indexOf(':')+1); 
 	loop_datakey = loop_datakey_1.substring(0, loop_datakey_1.indexOf(':'));
 	loop_datakey_2 = loop_datakey_1.substring(loop_datakey_1.indexOf(':')+1);
 	loop_caption_str = loop_datakey_2.substring(loop_datakey_2.indexOf(':'));
 	loop_caption_str_div=`<div class="col-md-12 text-center  pb-4"> ${loop_caption_str} </div>`;
   }
   
   slide_node+=`   
            <!-- carousel item -->
            <div class="carousel-item">
             <div class="row pt-3 justify-content-center">
     			${loop_caption_str_div}
               <div  class="col-md-12 pr-0 w-100">
               <img src="${loop_img_string}" style="${img_style}" class="${img_class}" ${extra_attr} data-idkey="${loop_datakey}"/>
               </div>
             </div>
           </div>
           <!-- carousel item -->`;
   
 }
  
var slide_tray=`
      <!--------------- Start carousel ---------->
      <div id="slide_s${curr_slide_id}" class="carousel slide w-100" data-ride="carousel" data-interval="2000">
        <ol class="carousel-indicators mt-2">
  		${slidecounter}
        </ol>
        <!-- carousel inner -->
          <div class="carousel-inner">
            <!-- carousel item -->
            <div class="carousel-item active">
             <div class="row pt-3 justify-content-center">
          	   ${caption_str_div}
               <div  class="col-md-12 pr-0 w-100">
               <img src="${img_string}" style="${img_style}" class="${img_class}" ${extra_attr} data-idkey="${datakey}"/>
               </div>
             </div>
           </div>
           <!-- carousel item -->
		   ${slide_node}
            <!-- carousel inner -->
            <a class="carousel-control-prev" href="#slide_s${curr_slide_id}" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            </a>
            <a class="carousel-control-next" href="#slide_s${curr_slide_id}" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
            </a> 
          </div>
             
      </div>
      <!--------------- End carousel ---------->
        `;
  
return [slide_tray, curr_slide_id];  
}
///////////////  slide show 

//////////////  image alert 
function mosy_img_pop(img_src,img_style, img_class,  extra_attr, slide_show_yes_no)
{
  var img_tray=
    `
    <img src="${img_src}" style="${img_style}" class="${img_class}"/>
    
    `;
  
  if(slide_show_yes_no=='yes')
  {
    
    var pop_tray_carousel = mosy_slide_wgt(img_src, img_style, img_class, extra_attr)[0];
    
    magic_screen(pop_tray_carousel, 'alert_box');
    
  }else{
  	magic_screen(img_tray, 'alert_box');
  }
  
}  

//////////////  image alert \

function mosy_snack_wgt(content, curr_position, push_to, snack_pos, snackid, color, bg, onclick_fun)
{
              
var snack_cont=`
<style>
/* The snackbar - position it at the bottom and in the middle of the screen */
#${snackid} {
  visibility: hidden; /* Hidden by default. Visible on click */
  min-width: 250px; /* Set a default minimum width */
  margin-left: -125px; /* Divide value of min-width by 2 */
  background:${bg}; /* Black background color */
  color: ${color}; /* White text color */
  text-align: center; /* Centered text */
  border-radius: 2px; /* Rounded borders */
  padding: 16px; /* Padding */
  position: fixed; /* Sit on top of the screen */
  z-index: 9999; /* Add a z-index if needed */
  left: 50%; /* Center the snackbar */
  ${curr_position}: ${snack_pos}; /* 30px from the bottom */
}

/* Show the snackbar when clicking on a button (class added with JavaScript) */
#${snackid}.show {
  visibility: visible; /* Show the snackbar */
  /* Add animation: Take 0.5 seconds to fade in and out the snackbar.
  However, delay the fade out process for 2.5 seconds */
  -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
  animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

/* Animations to fade the snackbar in and out */
@-webkit-keyframes fadein {
  from {${curr_position}: 0; opacity: 0;}
  to {${curr_position}: ${snack_pos}; opacity: 1;}
}

@keyframes fadein {
  from {${curr_position}: 0; opacity: 0;}
  to {${curr_position}: ${snack_pos}; opacity: 1;}
}

@-webkit-keyframes fadeout {
  from {${curr_position}: ${snack_pos}; opacity: 1;}
  to {${curr_position}: 0; opacity: 0;}
}

@keyframes fadeout {
  from {${curr_position}: ${snack_pos}; opacity: 1;}
  to {${curr_position}: 0; opacity: 0;}
}
</style>
  
  <div id="${snackid}" onclick="${onclick_fun};push_html('${push_to}', '')">${content}</div>

  `;


push_html(push_to, snack_cont);


} 

function new_location(new_location_str)
{
window.location=new_location_str;
}


function glass_modal()
{
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("background-color", "transparent", "important");;
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("border-top", "0px solid", "important");;
       document.getElementsByClassName("msg_modal-content")[0].style.setProperty("border", "0px solid", "important");;
}

function mosy_card(card_title="", card_content, attach_To)
{
	var mosy_card_title="";
    if(card_title!="")
    {
    var mosy_card_title=`
                          <!-- Start  Title ribbon-->
                      <h5 class="col-md-12 row p-2 justify-content-center p-0 m-0 ">
                        <div class="col-md-2 bg-dark mb-3 mb-lg-0 mt-lg-3" style="height: 1px"></div>
                        <div class="col-md-8 text-center"><b> ${card_title}</b></div>
                        <div class="col-md-2 bg-dark mt-3" style="height: 1px"></div>
                      </h5>
                      <!-- End Title ribbon--> 
    `;
    }
    var link_pop=`
    <div class="row justify-content-center m-0 p-0 col-md-12">
						${mosy_card_title}
                      <div class="row justify-content-center m-0 p-0 col-md-12 mt-3 mb-3">
                        ${card_content}
                      </div>
      </div>
    </div>

    `;

    if(attach_To=='' || attach_To==undefined)
    {
    magic_screen(link_pop, 'alert_box');
    }else{
      push_html(attach_To, link_pop);
    }

    return link_pop;
 
}
//<--ncgh-->
