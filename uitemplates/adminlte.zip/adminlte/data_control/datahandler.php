<?php 
//===============Start Mosy queries-============ 

    
 	//Start Add account_profiles Data ===============
 	function add_account_profiles($account_profiles_arr_)
    {
     $gw_account_profiles_cols=array();
     
     foreach($account_profiles_arr_ as $account_profiles_arr_gw => $account_profiles_arr_gw_val)
     {
     
     	$gw_account_profiles_cols[]=$account_profiles_arr_gw;
        
     }
     
     $gw_account_profiles_cols_str=implode(",", $gw_account_profiles_cols);
     
     $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "insert",$gw_account_profiles_cols_str);
     
     $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
     
     if($gwauthenticate_account_profiles_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("account_profiles", $account_profiles_arr_);
     
     	//echo $gwauthenticate_account_profiles_;

     }else{
     
     	echo $gwauthenticate_account_profiles_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_account_profiles_)."");

     }
     
    }
    
       function initialize_account_profiles()
        {
        
         global $account_profiles_uptoken;
             
         $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "select","");

         $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
         	
          //echo $gwauthenticate_account_profiles_;

         if($gwauthenticate_account_profiles_json["response"]=="ok")
         {
         
         	return get_account_profiles("*", "WHERE primkey='$account_profiles_uptoken'", "r");
         
            echo $gwauthenticate_account_profiles_;

         }else{

         	echo $gwauthenticate_account_profiles_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_account_profiles_)."");
         
         }
        }   
    //End Add account_profiles Data ===============
                
    //Start Update account_profiles Data ===============
    
 	function update_account_profiles($account_profiles_arr_, $where_str)
    {
         $gw_account_profiles_cols=array();
     
     foreach($account_profiles_arr_ as $account_profiles_arr_gw => $account_profiles_arr_gw_val)
     {
     
     	$gw_account_profiles_cols[]=$account_profiles_arr_gw;
        
     }
     
     $gw_account_profiles_cols_str=implode(",", $gw_account_profiles_cols);
     
     $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "update",$gw_account_profiles_cols_str);
     
     $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
     
     if($gwauthenticate_account_profiles_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("account_profiles", $account_profiles_arr_, $where_str);

       // echo $gwauthenticate_account_profiles_;
        
        exit;

     }else{

        echo $gwauthenticate_account_profiles_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_account_profiles_)."");


      }
    
    }
 	
    
    //End Update account_profiles Data ===============

    //Start get  account_profiles Data ===============
    
    function get_account_profiles($colstr, $where_str, $type)
    {
          
     $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "select","");
     
     $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
     
     if($gwauthenticate_account_profiles_json["response"]=="ok")
     {
    	return mosyflex_sel("account_profiles", $colstr, $where_str, $type);

        //echo $gwauthenticate_account_profiles_;

	  }else{
     
     	echo $gwauthenticate_account_profiles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_account_profiles_)."");


     }    
    }
    //End get  account_profiles Data ===============
    
    
    //======== qaccount_profiles_data qsingle query function
    
    function qaccount_profiles_data($qaccount_id_key)
    {
          
     $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "qdata","");
     
     $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
     
     if($gwauthenticate_account_profiles_json["response"]=="ok")
     {    
    	return get_account_profiles("*", "WHERE account_id='$qaccount_id_key'", "r");

		//echo $gwauthenticate_account_profiles_;

      }else{
     
     	echo $gwauthenticate_account_profiles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_account_profiles_)."");


     }  
    }
   
    //======== qaccount_profiles_data qsingle query function
    
    
     //======== account_profiles data to array
    
    function account_profiles_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "data_array","");
     
     $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
     
     if($gwauthenticate_account_profiles_json["response"]=="ok")
     {  
     	$append_account_profiles_arr=array();
    
    	$array_account_profiles_q=get_account_profiles($colstr, $where_str, "l");
        while($array_account_profiles_res=mysqli_fetch_array($array_account_profiles_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_account_profiles_arr[]=$array_account_profiles_res[$tbl_col];
            }
          }else{
          	          
               $append_account_profiles_arr[]=$array_account_profiles_res;

          }
        }
        
        return $append_account_profiles_arr;

		//echo $gwauthenticate_account_profiles_;

      }else{
     
     	echo $gwauthenticate_account_profiles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_account_profiles_)."");


     }  
    }
   
    //======== qaccount_profiles_data qsingle query function   
        
    //======== qaccount_profiles_ddata qsingle query function    
    function qaccount_profiles_ddata($account_id_col, $qaccount_id_key)
    {
     
     $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "qddata","");
     
     $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
     
     if($gwauthenticate_account_profiles_json["response"]=="ok")
     {    
    	return get_account_profiles("*", "WHERE $account_id_col='$qaccount_id_key'", "r");

		//echo $gwauthenticate_account_profiles_;

     }else{
     
     	echo $gwauthenticate_account_profiles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_account_profiles_)."");


     }   
    }
    //======== qaccount_profiles_ddata qsingle query function

    //======== count account_profiles data function
    
    function count_account_profiles($account_profiles_wherestr)
    {
     
     $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "count_data","");
     
     $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
     
     if($gwauthenticate_account_profiles_json["response"]=="ok")
     {    
      $clean_account_profiles_where_str="";
  
      if($account_profiles_wherestr!='')
      {
        $clean_account_profiles_where_str="Where ".$account_profiles_wherestr;
      }

      return get_account_profiles("count(*) as return_result", " ".$clean_account_profiles_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_account_profiles_;

      }else{
     
     	echo $gwauthenticate_account_profiles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_account_profiles_)."");


     }    
    }
    //======== count account_profiles data function

    //======== sum  account_profiles data function
    
    function sum_account_profiles($account_profiles_sumcol, $account_profiles_wherestr)
    {
     
     $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "sum_data","");
     
     $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
     
     if($gwauthenticate_account_profiles_json["response"]=="ok")
     {    
      $clean_account_profiles_where_str="";
  
      if($account_profiles_wherestr!='')
      {
        $clean_account_profiles_where_str="Where ".$account_profiles_wherestr;
      }

      return get_account_profiles("sum($account_profiles_sumcol) as return_result", " ".$clean_account_profiles_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_account_profiles_;


      }else{
     
     	echo $gwauthenticate_account_profiles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_account_profiles_)."");
        


     }    
    }
    
    //======== sum  account_profiles data function   
    
    
    //Start drop  account_profiles Data ===============
    
    function drop_account_profiles($where_str)
    {
     
     $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "drop_data","");
     
     $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
     
     if($gwauthenticate_account_profiles_json["response"]=="ok")
     {    
    	return magic_sql_delete("account_profiles", $where_str);

		//echo $gwauthenticate_account_profiles_;

      }else{
     
     	echo $gwauthenticate_account_profiles_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_account_profiles_)."");
		

     }
    }
    //End drop  account_profiles Data ===============    
    
    
            //Start Upload account_profiles_organization_logo Function 
            function upload_account_profiles_organization_logo($txt_account_profiles_organization_logo, $where_str){
              
                $file_name1=explode(".", basename($_FILES[$txt_account_profiles_organization_logo]['name']))[0];

                $file_name=str_replace(" ", "_", $file_name1);

                if (!file_exists('./img/account_profiles_organization_logo')) @mkdir('./img/account_profiles_organization_logo');

                $cur_item_photos=magic_upload_file('./img/account_profiles_organization_logo/', $txt_account_profiles_organization_logo, $file_name."_".magic_random_str(5));

                $item_photo=mmres($cur_item_photos);

                magic_compress_file($cur_item_photos, $cur_item_photos, 50);

                $account_profiles_node=get_account_profiles("*", "WHERE ".$where_str."", "r");

                  if (file_exists($account_profiles_node["organization_logo"]))
                  {

                      unlink($account_profiles_node["organization_logo"]);

                  }
                  if($where_str!="")
                  {
                    magic_sql_update('account_profiles', '{"organization_logo":"'.$cur_item_photos.'"}', $where_str);
                  } 

              return $cur_item_photos;

			}
           //End Upload account_profiles_organization_logo Function 

            
   

    
 	//Start Add advance_payments Data ===============
 	function add_advance_payments($advance_payments_arr_)
    {
     $gw_advance_payments_cols=array();
     
     foreach($advance_payments_arr_ as $advance_payments_arr_gw => $advance_payments_arr_gw_val)
     {
     
     	$gw_advance_payments_cols[]=$advance_payments_arr_gw;
        
     }
     
     $gw_advance_payments_cols_str=implode(",", $gw_advance_payments_cols);
     
     $gwauthenticate_advance_payments_=gw_oauth("table", magic_current_url(), "advance_payments", "insert",$gw_advance_payments_cols_str);
     
     $gwauthenticate_advance_payments_json=json_decode($gwauthenticate_advance_payments_, true);
     
     if($gwauthenticate_advance_payments_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("advance_payments", $advance_payments_arr_);
     
     	//echo $gwauthenticate_advance_payments_;

     }else{
     
     	echo $gwauthenticate_advance_payments_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_advance_payments_)."");

     }
     
    }
    
       function initialize_advance_payments()
        {
        
         global $advance_payments_uptoken;
             
         $gwauthenticate_advance_payments_=gw_oauth("table", magic_current_url(), "advance_payments", "select","");

         $gwauthenticate_advance_payments_json=json_decode($gwauthenticate_advance_payments_, true);
         	
          //echo $gwauthenticate_advance_payments_;

         if($gwauthenticate_advance_payments_json["response"]=="ok")
         {
         
         	return get_advance_payments("*", "WHERE primkey='$advance_payments_uptoken'", "r");
         
            echo $gwauthenticate_advance_payments_;

         }else{

         	echo $gwauthenticate_advance_payments_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_advance_payments_)."");
         
         }
        }   
    //End Add advance_payments Data ===============
                
    //Start Update advance_payments Data ===============
    
 	function update_advance_payments($advance_payments_arr_, $where_str)
    {
         $gw_advance_payments_cols=array();
     
     foreach($advance_payments_arr_ as $advance_payments_arr_gw => $advance_payments_arr_gw_val)
     {
     
     	$gw_advance_payments_cols[]=$advance_payments_arr_gw;
        
     }
     
     $gw_advance_payments_cols_str=implode(",", $gw_advance_payments_cols);
     
     $gwauthenticate_advance_payments_=gw_oauth("table", magic_current_url(), "advance_payments", "update",$gw_advance_payments_cols_str);
     
     $gwauthenticate_advance_payments_json=json_decode($gwauthenticate_advance_payments_, true);
     
     if($gwauthenticate_advance_payments_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("advance_payments", $advance_payments_arr_, $where_str);

       // echo $gwauthenticate_advance_payments_;
        
        exit;

     }else{

        echo $gwauthenticate_advance_payments_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_advance_payments_)."");


      }
    
    }
 	
    
    //End Update advance_payments Data ===============

    //Start get  advance_payments Data ===============
    
    function get_advance_payments($colstr, $where_str, $type)
    {
          
     $gwauthenticate_advance_payments_=gw_oauth("table", magic_current_url(), "advance_payments", "select","");
     
     $gwauthenticate_advance_payments_json=json_decode($gwauthenticate_advance_payments_, true);
     
     if($gwauthenticate_advance_payments_json["response"]=="ok")
     {
    	return mosyflex_sel("advance_payments", $colstr, $where_str, $type);

        //echo $gwauthenticate_advance_payments_;

	  }else{
     
     	echo $gwauthenticate_advance_payments_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_advance_payments_)."");


     }    
    }
    //End get  advance_payments Data ===============
    
    
    //======== qadvance_payments_data qsingle query function
    
    function qadvance_payments_data($qadvance_key_key)
    {
          
     $gwauthenticate_advance_payments_=gw_oauth("table", magic_current_url(), "advance_payments", "qdata","");
     
     $gwauthenticate_advance_payments_json=json_decode($gwauthenticate_advance_payments_, true);
     
     if($gwauthenticate_advance_payments_json["response"]=="ok")
     {    
    	return get_advance_payments("*", "WHERE advance_key='$qadvance_key_key'", "r");

		//echo $gwauthenticate_advance_payments_;

      }else{
     
     	echo $gwauthenticate_advance_payments_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_advance_payments_)."");


     }  
    }
   
    //======== qadvance_payments_data qsingle query function
    
    
     //======== advance_payments data to array
    
    function advance_payments_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_advance_payments_=gw_oauth("table", magic_current_url(), "advance_payments", "data_array","");
     
     $gwauthenticate_advance_payments_json=json_decode($gwauthenticate_advance_payments_, true);
     
     if($gwauthenticate_advance_payments_json["response"]=="ok")
     {  
     	$append_advance_payments_arr=array();
    
    	$array_advance_payments_q=get_advance_payments($colstr, $where_str, "l");
        while($array_advance_payments_res=mysqli_fetch_array($array_advance_payments_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_advance_payments_arr[]=$array_advance_payments_res[$tbl_col];
            }
          }else{
          	          
               $append_advance_payments_arr[]=$array_advance_payments_res;

          }
        }
        
        return $append_advance_payments_arr;

		//echo $gwauthenticate_advance_payments_;

      }else{
     
     	echo $gwauthenticate_advance_payments_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_advance_payments_)."");


     }  
    }
   
    //======== qadvance_payments_data qsingle query function   
        
    //======== qadvance_payments_ddata qsingle query function    
    function qadvance_payments_ddata($advance_key_col, $qadvance_key_key)
    {
     
     $gwauthenticate_advance_payments_=gw_oauth("table", magic_current_url(), "advance_payments", "qddata","");
     
     $gwauthenticate_advance_payments_json=json_decode($gwauthenticate_advance_payments_, true);
     
     if($gwauthenticate_advance_payments_json["response"]=="ok")
     {    
    	return get_advance_payments("*", "WHERE $advance_key_col='$qadvance_key_key'", "r");

		//echo $gwauthenticate_advance_payments_;

     }else{
     
     	echo $gwauthenticate_advance_payments_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_advance_payments_)."");


     }   
    }
    //======== qadvance_payments_ddata qsingle query function

    //======== count advance_payments data function
    
    function count_advance_payments($advance_payments_wherestr)
    {
     
     $gwauthenticate_advance_payments_=gw_oauth("table", magic_current_url(), "advance_payments", "count_data","");
     
     $gwauthenticate_advance_payments_json=json_decode($gwauthenticate_advance_payments_, true);
     
     if($gwauthenticate_advance_payments_json["response"]=="ok")
     {    
      $clean_advance_payments_where_str="";
  
      if($advance_payments_wherestr!='')
      {
        $clean_advance_payments_where_str="Where ".$advance_payments_wherestr;
      }

      return get_advance_payments("count(*) as return_result", " ".$clean_advance_payments_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_advance_payments_;

      }else{
     
     	echo $gwauthenticate_advance_payments_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_advance_payments_)."");


     }    
    }
    //======== count advance_payments data function

    //======== sum  advance_payments data function
    
    function sum_advance_payments($advance_payments_sumcol, $advance_payments_wherestr)
    {
     
     $gwauthenticate_advance_payments_=gw_oauth("table", magic_current_url(), "advance_payments", "sum_data","");
     
     $gwauthenticate_advance_payments_json=json_decode($gwauthenticate_advance_payments_, true);
     
     if($gwauthenticate_advance_payments_json["response"]=="ok")
     {    
      $clean_advance_payments_where_str="";
  
      if($advance_payments_wherestr!='')
      {
        $clean_advance_payments_where_str="Where ".$advance_payments_wherestr;
      }

      return get_advance_payments("sum($advance_payments_sumcol) as return_result", " ".$clean_advance_payments_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_advance_payments_;


      }else{
     
     	echo $gwauthenticate_advance_payments_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_advance_payments_)."");
        


     }    
    }
    
    //======== sum  advance_payments data function   
    
    
    //Start drop  advance_payments Data ===============
    
    function drop_advance_payments($where_str)
    {
     
     $gwauthenticate_advance_payments_=gw_oauth("table", magic_current_url(), "advance_payments", "drop_data","");
     
     $gwauthenticate_advance_payments_json=json_decode($gwauthenticate_advance_payments_, true);
     
     if($gwauthenticate_advance_payments_json["response"]=="ok")
     {    
    	return magic_sql_delete("advance_payments", $where_str);

		//echo $gwauthenticate_advance_payments_;

      }else{
     
     	echo $gwauthenticate_advance_payments_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_advance_payments_)."");
		

     }
    }
    //End drop  advance_payments Data ===============    
    
    
   

    
 	//Start Add allowances Data ===============
 	function add_allowances($allowances_arr_)
    {
     $gw_allowances_cols=array();
     
     foreach($allowances_arr_ as $allowances_arr_gw => $allowances_arr_gw_val)
     {
     
     	$gw_allowances_cols[]=$allowances_arr_gw;
        
     }
     
     $gw_allowances_cols_str=implode(",", $gw_allowances_cols);
     
     $gwauthenticate_allowances_=gw_oauth("table", magic_current_url(), "allowances", "insert",$gw_allowances_cols_str);
     
     $gwauthenticate_allowances_json=json_decode($gwauthenticate_allowances_, true);
     
     if($gwauthenticate_allowances_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("allowances", $allowances_arr_);
     
     	//echo $gwauthenticate_allowances_;

     }else{
     
     	echo $gwauthenticate_allowances_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_allowances_)."");

     }
     
    }
    
       function initialize_allowances()
        {
        
         global $allowances_uptoken;
             
         $gwauthenticate_allowances_=gw_oauth("table", magic_current_url(), "allowances", "select","");

         $gwauthenticate_allowances_json=json_decode($gwauthenticate_allowances_, true);
         	
          //echo $gwauthenticate_allowances_;

         if($gwauthenticate_allowances_json["response"]=="ok")
         {
         
         	return get_allowances("*", "WHERE primkey='$allowances_uptoken'", "r");
         
            echo $gwauthenticate_allowances_;

         }else{

         	echo $gwauthenticate_allowances_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_allowances_)."");
         
         }
        }   
    //End Add allowances Data ===============
                
    //Start Update allowances Data ===============
    
 	function update_allowances($allowances_arr_, $where_str)
    {
         $gw_allowances_cols=array();
     
     foreach($allowances_arr_ as $allowances_arr_gw => $allowances_arr_gw_val)
     {
     
     	$gw_allowances_cols[]=$allowances_arr_gw;
        
     }
     
     $gw_allowances_cols_str=implode(",", $gw_allowances_cols);
     
     $gwauthenticate_allowances_=gw_oauth("table", magic_current_url(), "allowances", "update",$gw_allowances_cols_str);
     
     $gwauthenticate_allowances_json=json_decode($gwauthenticate_allowances_, true);
     
     if($gwauthenticate_allowances_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("allowances", $allowances_arr_, $where_str);

       // echo $gwauthenticate_allowances_;
        
        exit;

     }else{

        echo $gwauthenticate_allowances_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_allowances_)."");


      }
    
    }
 	
    
    //End Update allowances Data ===============

    //Start get  allowances Data ===============
    
    function get_allowances($colstr, $where_str, $type)
    {
          
     $gwauthenticate_allowances_=gw_oauth("table", magic_current_url(), "allowances", "select","");
     
     $gwauthenticate_allowances_json=json_decode($gwauthenticate_allowances_, true);
     
     if($gwauthenticate_allowances_json["response"]=="ok")
     {
    	return mosyflex_sel("allowances", $colstr, $where_str, $type);

        //echo $gwauthenticate_allowances_;

	  }else{
     
     	echo $gwauthenticate_allowances_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_allowances_)."");


     }    
    }
    //End get  allowances Data ===============
    
    
    //======== qallowances_data qsingle query function
    
    function qallowances_data($qallowance_id_key)
    {
          
     $gwauthenticate_allowances_=gw_oauth("table", magic_current_url(), "allowances", "qdata","");
     
     $gwauthenticate_allowances_json=json_decode($gwauthenticate_allowances_, true);
     
     if($gwauthenticate_allowances_json["response"]=="ok")
     {    
    	return get_allowances("*", "WHERE allowance_id='$qallowance_id_key'", "r");

		//echo $gwauthenticate_allowances_;

      }else{
     
     	echo $gwauthenticate_allowances_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_allowances_)."");


     }  
    }
   
    //======== qallowances_data qsingle query function
    
    
     //======== allowances data to array
    
    function allowances_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_allowances_=gw_oauth("table", magic_current_url(), "allowances", "data_array","");
     
     $gwauthenticate_allowances_json=json_decode($gwauthenticate_allowances_, true);
     
     if($gwauthenticate_allowances_json["response"]=="ok")
     {  
     	$append_allowances_arr=array();
    
    	$array_allowances_q=get_allowances($colstr, $where_str, "l");
        while($array_allowances_res=mysqli_fetch_array($array_allowances_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_allowances_arr[]=$array_allowances_res[$tbl_col];
            }
          }else{
          	          
               $append_allowances_arr[]=$array_allowances_res;

          }
        }
        
        return $append_allowances_arr;

		//echo $gwauthenticate_allowances_;

      }else{
     
     	echo $gwauthenticate_allowances_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_allowances_)."");


     }  
    }
   
    //======== qallowances_data qsingle query function   
        
    //======== qallowances_ddata qsingle query function    
    function qallowances_ddata($allowance_id_col, $qallowance_id_key)
    {
     
     $gwauthenticate_allowances_=gw_oauth("table", magic_current_url(), "allowances", "qddata","");
     
     $gwauthenticate_allowances_json=json_decode($gwauthenticate_allowances_, true);
     
     if($gwauthenticate_allowances_json["response"]=="ok")
     {    
    	return get_allowances("*", "WHERE $allowance_id_col='$qallowance_id_key'", "r");

		//echo $gwauthenticate_allowances_;

     }else{
     
     	echo $gwauthenticate_allowances_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_allowances_)."");


     }   
    }
    //======== qallowances_ddata qsingle query function

    //======== count allowances data function
    
    function count_allowances($allowances_wherestr)
    {
     
     $gwauthenticate_allowances_=gw_oauth("table", magic_current_url(), "allowances", "count_data","");
     
     $gwauthenticate_allowances_json=json_decode($gwauthenticate_allowances_, true);
     
     if($gwauthenticate_allowances_json["response"]=="ok")
     {    
      $clean_allowances_where_str="";
  
      if($allowances_wherestr!='')
      {
        $clean_allowances_where_str="Where ".$allowances_wherestr;
      }

      return get_allowances("count(*) as return_result", " ".$clean_allowances_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_allowances_;

      }else{
     
     	echo $gwauthenticate_allowances_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_allowances_)."");


     }    
    }
    //======== count allowances data function

    //======== sum  allowances data function
    
    function sum_allowances($allowances_sumcol, $allowances_wherestr)
    {
     
     $gwauthenticate_allowances_=gw_oauth("table", magic_current_url(), "allowances", "sum_data","");
     
     $gwauthenticate_allowances_json=json_decode($gwauthenticate_allowances_, true);
     
     if($gwauthenticate_allowances_json["response"]=="ok")
     {    
      $clean_allowances_where_str="";
  
      if($allowances_wherestr!='')
      {
        $clean_allowances_where_str="Where ".$allowances_wherestr;
      }

      return get_allowances("sum($allowances_sumcol) as return_result", " ".$clean_allowances_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_allowances_;


      }else{
     
     	echo $gwauthenticate_allowances_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_allowances_)."");
        


     }    
    }
    
    //======== sum  allowances data function   
    
    
    //Start drop  allowances Data ===============
    
    function drop_allowances($where_str)
    {
     
     $gwauthenticate_allowances_=gw_oauth("table", magic_current_url(), "allowances", "drop_data","");
     
     $gwauthenticate_allowances_json=json_decode($gwauthenticate_allowances_, true);
     
     if($gwauthenticate_allowances_json["response"]=="ok")
     {    
    	return magic_sql_delete("allowances", $where_str);

		//echo $gwauthenticate_allowances_;

      }else{
     
     	echo $gwauthenticate_allowances_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_allowances_)."");
		

     }
    }
    //End drop  allowances Data ===============    
    
    
   

    
 	//Start Add app_users Data ===============
 	function add_app_users($app_users_arr_)
    {
     $gw_app_users_cols=array();
     
     foreach($app_users_arr_ as $app_users_arr_gw => $app_users_arr_gw_val)
     {
     
     	$gw_app_users_cols[]=$app_users_arr_gw;
        
     }
     
     $gw_app_users_cols_str=implode(",", $gw_app_users_cols);
     
     $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "insert",$gw_app_users_cols_str);
     
     $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
     
     if($gwauthenticate_app_users_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("app_users", $app_users_arr_);
     
     	//echo $gwauthenticate_app_users_;

     }else{
     
     	echo $gwauthenticate_app_users_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_users_)."");

     }
     
    }
    
       function initialize_app_users()
        {
        
         global $app_users_uptoken;
             
         $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "select","");

         $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
         	
          //echo $gwauthenticate_app_users_;

         if($gwauthenticate_app_users_json["response"]=="ok")
         {
         
         	return get_app_users("*", "WHERE primkey='$app_users_uptoken'", "r");
         
            echo $gwauthenticate_app_users_;

         }else{

         	echo $gwauthenticate_app_users_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_users_)."");
         
         }
        }   
    //End Add app_users Data ===============
                
    //Start Update app_users Data ===============
    
 	function update_app_users($app_users_arr_, $where_str)
    {
         $gw_app_users_cols=array();
     
     foreach($app_users_arr_ as $app_users_arr_gw => $app_users_arr_gw_val)
     {
     
     	$gw_app_users_cols[]=$app_users_arr_gw;
        
     }
     
     $gw_app_users_cols_str=implode(",", $gw_app_users_cols);
     
     $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "update",$gw_app_users_cols_str);
     
     $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
     
     if($gwauthenticate_app_users_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("app_users", $app_users_arr_, $where_str);

       // echo $gwauthenticate_app_users_;
        
        exit;

     }else{

        echo $gwauthenticate_app_users_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_users_)."");


      }
    
    }
 	
    
    //End Update app_users Data ===============

    //Start get  app_users Data ===============
    
    function get_app_users($colstr, $where_str, $type)
    {
          
     $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "select","");
     
     $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
     
     if($gwauthenticate_app_users_json["response"]=="ok")
     {
    	return mosyflex_sel("app_users", $colstr, $where_str, $type);

        //echo $gwauthenticate_app_users_;

	  }else{
     
     	echo $gwauthenticate_app_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_users_)."");


     }    
    }
    //End get  app_users Data ===============
    
    
    //======== qapp_users_data qsingle query function
    
    function qapp_users_data($quser_id_key)
    {
          
     $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "qdata","");
     
     $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
     
     if($gwauthenticate_app_users_json["response"]=="ok")
     {    
    	return get_app_users("*", "WHERE user_id='$quser_id_key'", "r");

		//echo $gwauthenticate_app_users_;

      }else{
     
     	echo $gwauthenticate_app_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_users_)."");


     }  
    }
   
    //======== qapp_users_data qsingle query function
    
    
     //======== app_users data to array
    
    function app_users_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "data_array","");
     
     $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
     
     if($gwauthenticate_app_users_json["response"]=="ok")
     {  
     	$append_app_users_arr=array();
    
    	$array_app_users_q=get_app_users($colstr, $where_str, "l");
        while($array_app_users_res=mysqli_fetch_array($array_app_users_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_app_users_arr[]=$array_app_users_res[$tbl_col];
            }
          }else{
          	          
               $append_app_users_arr[]=$array_app_users_res;

          }
        }
        
        return $append_app_users_arr;

		//echo $gwauthenticate_app_users_;

      }else{
     
     	echo $gwauthenticate_app_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_users_)."");


     }  
    }
   
    //======== qapp_users_data qsingle query function   
        
    //======== qapp_users_ddata qsingle query function    
    function qapp_users_ddata($user_id_col, $quser_id_key)
    {
     
     $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "qddata","");
     
     $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
     
     if($gwauthenticate_app_users_json["response"]=="ok")
     {    
    	return get_app_users("*", "WHERE $user_id_col='$quser_id_key'", "r");

		//echo $gwauthenticate_app_users_;

     }else{
     
     	echo $gwauthenticate_app_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_users_)."");


     }   
    }
    //======== qapp_users_ddata qsingle query function

    //======== count app_users data function
    
    function count_app_users($app_users_wherestr)
    {
     
     $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "count_data","");
     
     $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
     
     if($gwauthenticate_app_users_json["response"]=="ok")
     {    
      $clean_app_users_where_str="";
  
      if($app_users_wherestr!='')
      {
        $clean_app_users_where_str="Where ".$app_users_wherestr;
      }

      return get_app_users("count(*) as return_result", " ".$clean_app_users_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_app_users_;

      }else{
     
     	echo $gwauthenticate_app_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_users_)."");


     }    
    }
    //======== count app_users data function

    //======== sum  app_users data function
    
    function sum_app_users($app_users_sumcol, $app_users_wherestr)
    {
     
     $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "sum_data","");
     
     $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
     
     if($gwauthenticate_app_users_json["response"]=="ok")
     {    
      $clean_app_users_where_str="";
  
      if($app_users_wherestr!='')
      {
        $clean_app_users_where_str="Where ".$app_users_wherestr;
      }

      return get_app_users("sum($app_users_sumcol) as return_result", " ".$clean_app_users_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_app_users_;


      }else{
     
     	echo $gwauthenticate_app_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_users_)."");
        


     }    
    }
    
    //======== sum  app_users data function   
    
    
    //Start drop  app_users Data ===============
    
    function drop_app_users($where_str)
    {
     
     $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "drop_data","");
     
     $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
     
     if($gwauthenticate_app_users_json["response"]=="ok")
     {    
    	return magic_sql_delete("app_users", $where_str);

		//echo $gwauthenticate_app_users_;

      }else{
     
     	echo $gwauthenticate_app_users_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_users_)."");
		

     }
    }
    //End drop  app_users Data ===============    
    
    
            //Start Upload app_users_user_pic Function 
            function upload_app_users_user_pic($txt_app_users_user_pic, $where_str){
              
                $file_name1=explode(".", basename($_FILES[$txt_app_users_user_pic]['name']))[0];

                $file_name=str_replace(" ", "_", $file_name1);

                if (!file_exists('./img/app_users_user_pic')) @mkdir('./img/app_users_user_pic');

                $cur_item_photos=magic_upload_file('./img/app_users_user_pic/', $txt_app_users_user_pic, $file_name."_".magic_random_str(5));

                $item_photo=mmres($cur_item_photos);

                magic_compress_file($cur_item_photos, $cur_item_photos, 50);

                $app_users_node=get_app_users("*", "WHERE ".$where_str."", "r");

                  if (file_exists($app_users_node["user_pic"]))
                  {

                      unlink($app_users_node["user_pic"]);

                  }
                  if($where_str!="")
                  {
                    magic_sql_update('app_users', '{"user_pic":"'.$cur_item_photos.'"}', $where_str);
                  } 

              return $cur_item_photos;

			}
           //End Upload app_users_user_pic Function 

            
   

    
 	//Start Add casuals_payroll Data ===============
 	function add_casuals_payroll($casuals_payroll_arr_)
    {
     $gw_casuals_payroll_cols=array();
     
     foreach($casuals_payroll_arr_ as $casuals_payroll_arr_gw => $casuals_payroll_arr_gw_val)
     {
     
     	$gw_casuals_payroll_cols[]=$casuals_payroll_arr_gw;
        
     }
     
     $gw_casuals_payroll_cols_str=implode(",", $gw_casuals_payroll_cols);
     
     $gwauthenticate_casuals_payroll_=gw_oauth("table", magic_current_url(), "casuals_payroll", "insert",$gw_casuals_payroll_cols_str);
     
     $gwauthenticate_casuals_payroll_json=json_decode($gwauthenticate_casuals_payroll_, true);
     
     if($gwauthenticate_casuals_payroll_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("casuals_payroll", $casuals_payroll_arr_);
     
     	//echo $gwauthenticate_casuals_payroll_;

     }else{
     
     	echo $gwauthenticate_casuals_payroll_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_casuals_payroll_)."");

     }
     
    }
    
       function initialize_casuals_payroll()
        {
        
         global $casuals_payroll_uptoken;
             
         $gwauthenticate_casuals_payroll_=gw_oauth("table", magic_current_url(), "casuals_payroll", "select","");

         $gwauthenticate_casuals_payroll_json=json_decode($gwauthenticate_casuals_payroll_, true);
         	
          //echo $gwauthenticate_casuals_payroll_;

         if($gwauthenticate_casuals_payroll_json["response"]=="ok")
         {
         
         	return get_casuals_payroll("*", "WHERE primkey='$casuals_payroll_uptoken'", "r");
         
            echo $gwauthenticate_casuals_payroll_;

         }else{

         	echo $gwauthenticate_casuals_payroll_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_casuals_payroll_)."");
         
         }
        }   
    //End Add casuals_payroll Data ===============
                
    //Start Update casuals_payroll Data ===============
    
 	function update_casuals_payroll($casuals_payroll_arr_, $where_str)
    {
         $gw_casuals_payroll_cols=array();
     
     foreach($casuals_payroll_arr_ as $casuals_payroll_arr_gw => $casuals_payroll_arr_gw_val)
     {
     
     	$gw_casuals_payroll_cols[]=$casuals_payroll_arr_gw;
        
     }
     
     $gw_casuals_payroll_cols_str=implode(",", $gw_casuals_payroll_cols);
     
     $gwauthenticate_casuals_payroll_=gw_oauth("table", magic_current_url(), "casuals_payroll", "update",$gw_casuals_payroll_cols_str);
     
     $gwauthenticate_casuals_payroll_json=json_decode($gwauthenticate_casuals_payroll_, true);
     
     if($gwauthenticate_casuals_payroll_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("casuals_payroll", $casuals_payroll_arr_, $where_str);

       // echo $gwauthenticate_casuals_payroll_;
        
        exit;

     }else{

        echo $gwauthenticate_casuals_payroll_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_casuals_payroll_)."");


      }
    
    }
 	
    
    //End Update casuals_payroll Data ===============

    //Start get  casuals_payroll Data ===============
    
    function get_casuals_payroll($colstr, $where_str, $type)
    {
          
     $gwauthenticate_casuals_payroll_=gw_oauth("table", magic_current_url(), "casuals_payroll", "select","");
     
     $gwauthenticate_casuals_payroll_json=json_decode($gwauthenticate_casuals_payroll_, true);
     
     if($gwauthenticate_casuals_payroll_json["response"]=="ok")
     {
    	return mosyflex_sel("casuals_payroll", $colstr, $where_str, $type);

        //echo $gwauthenticate_casuals_payroll_;

	  }else{
     
     	echo $gwauthenticate_casuals_payroll_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_casuals_payroll_)."");


     }    
    }
    //End get  casuals_payroll Data ===============
    
    
    //======== qcasuals_payroll_data qsingle query function
    
    function qcasuals_payroll_data($qpayroll_id_key)
    {
          
     $gwauthenticate_casuals_payroll_=gw_oauth("table", magic_current_url(), "casuals_payroll", "qdata","");
     
     $gwauthenticate_casuals_payroll_json=json_decode($gwauthenticate_casuals_payroll_, true);
     
     if($gwauthenticate_casuals_payroll_json["response"]=="ok")
     {    
    	return get_casuals_payroll("*", "WHERE payroll_id='$qpayroll_id_key'", "r");

		//echo $gwauthenticate_casuals_payroll_;

      }else{
     
     	echo $gwauthenticate_casuals_payroll_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_casuals_payroll_)."");


     }  
    }
   
    //======== qcasuals_payroll_data qsingle query function
    
    
     //======== casuals_payroll data to array
    
    function casuals_payroll_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_casuals_payroll_=gw_oauth("table", magic_current_url(), "casuals_payroll", "data_array","");
     
     $gwauthenticate_casuals_payroll_json=json_decode($gwauthenticate_casuals_payroll_, true);
     
     if($gwauthenticate_casuals_payroll_json["response"]=="ok")
     {  
     	$append_casuals_payroll_arr=array();
    
    	$array_casuals_payroll_q=get_casuals_payroll($colstr, $where_str, "l");
        while($array_casuals_payroll_res=mysqli_fetch_array($array_casuals_payroll_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_casuals_payroll_arr[]=$array_casuals_payroll_res[$tbl_col];
            }
          }else{
          	          
               $append_casuals_payroll_arr[]=$array_casuals_payroll_res;

          }
        }
        
        return $append_casuals_payroll_arr;

		//echo $gwauthenticate_casuals_payroll_;

      }else{
     
     	echo $gwauthenticate_casuals_payroll_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_casuals_payroll_)."");


     }  
    }
   
    //======== qcasuals_payroll_data qsingle query function   
        
    //======== qcasuals_payroll_ddata qsingle query function    
    function qcasuals_payroll_ddata($payroll_id_col, $qpayroll_id_key)
    {
     
     $gwauthenticate_casuals_payroll_=gw_oauth("table", magic_current_url(), "casuals_payroll", "qddata","");
     
     $gwauthenticate_casuals_payroll_json=json_decode($gwauthenticate_casuals_payroll_, true);
     
     if($gwauthenticate_casuals_payroll_json["response"]=="ok")
     {    
    	return get_casuals_payroll("*", "WHERE $payroll_id_col='$qpayroll_id_key'", "r");

		//echo $gwauthenticate_casuals_payroll_;

     }else{
     
     	echo $gwauthenticate_casuals_payroll_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_casuals_payroll_)."");


     }   
    }
    //======== qcasuals_payroll_ddata qsingle query function

    //======== count casuals_payroll data function
    
    function count_casuals_payroll($casuals_payroll_wherestr)
    {
     
     $gwauthenticate_casuals_payroll_=gw_oauth("table", magic_current_url(), "casuals_payroll", "count_data","");
     
     $gwauthenticate_casuals_payroll_json=json_decode($gwauthenticate_casuals_payroll_, true);
     
     if($gwauthenticate_casuals_payroll_json["response"]=="ok")
     {    
      $clean_casuals_payroll_where_str="";
  
      if($casuals_payroll_wherestr!='')
      {
        $clean_casuals_payroll_where_str="Where ".$casuals_payroll_wherestr;
      }

      return get_casuals_payroll("count(*) as return_result", " ".$clean_casuals_payroll_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_casuals_payroll_;

      }else{
     
     	echo $gwauthenticate_casuals_payroll_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_casuals_payroll_)."");


     }    
    }
    //======== count casuals_payroll data function

    //======== sum  casuals_payroll data function
    
    function sum_casuals_payroll($casuals_payroll_sumcol, $casuals_payroll_wherestr)
    {
     
     $gwauthenticate_casuals_payroll_=gw_oauth("table", magic_current_url(), "casuals_payroll", "sum_data","");
     
     $gwauthenticate_casuals_payroll_json=json_decode($gwauthenticate_casuals_payroll_, true);
     
     if($gwauthenticate_casuals_payroll_json["response"]=="ok")
     {    
      $clean_casuals_payroll_where_str="";
  
      if($casuals_payroll_wherestr!='')
      {
        $clean_casuals_payroll_where_str="Where ".$casuals_payroll_wherestr;
      }

      return get_casuals_payroll("sum($casuals_payroll_sumcol) as return_result", " ".$clean_casuals_payroll_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_casuals_payroll_;


      }else{
     
     	echo $gwauthenticate_casuals_payroll_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_casuals_payroll_)."");
        


     }    
    }
    
    //======== sum  casuals_payroll data function   
    
    
    //Start drop  casuals_payroll Data ===============
    
    function drop_casuals_payroll($where_str)
    {
     
     $gwauthenticate_casuals_payroll_=gw_oauth("table", magic_current_url(), "casuals_payroll", "drop_data","");
     
     $gwauthenticate_casuals_payroll_json=json_decode($gwauthenticate_casuals_payroll_, true);
     
     if($gwauthenticate_casuals_payroll_json["response"]=="ok")
     {    
    	return magic_sql_delete("casuals_payroll", $where_str);

		//echo $gwauthenticate_casuals_payroll_;

      }else{
     
     	echo $gwauthenticate_casuals_payroll_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_casuals_payroll_)."");
		

     }
    }
    //End drop  casuals_payroll Data ===============    
    
    
   

    
 	//Start Add commissions Data ===============
 	function add_commissions($commissions_arr_)
    {
     $gw_commissions_cols=array();
     
     foreach($commissions_arr_ as $commissions_arr_gw => $commissions_arr_gw_val)
     {
     
     	$gw_commissions_cols[]=$commissions_arr_gw;
        
     }
     
     $gw_commissions_cols_str=implode(",", $gw_commissions_cols);
     
     $gwauthenticate_commissions_=gw_oauth("table", magic_current_url(), "commissions", "insert",$gw_commissions_cols_str);
     
     $gwauthenticate_commissions_json=json_decode($gwauthenticate_commissions_, true);
     
     if($gwauthenticate_commissions_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("commissions", $commissions_arr_);
     
     	//echo $gwauthenticate_commissions_;

     }else{
     
     	echo $gwauthenticate_commissions_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_commissions_)."");

     }
     
    }
    
       function initialize_commissions()
        {
        
         global $commissions_uptoken;
             
         $gwauthenticate_commissions_=gw_oauth("table", magic_current_url(), "commissions", "select","");

         $gwauthenticate_commissions_json=json_decode($gwauthenticate_commissions_, true);
         	
          //echo $gwauthenticate_commissions_;

         if($gwauthenticate_commissions_json["response"]=="ok")
         {
         
         	return get_commissions("*", "WHERE primkey='$commissions_uptoken'", "r");
         
            echo $gwauthenticate_commissions_;

         }else{

         	echo $gwauthenticate_commissions_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_commissions_)."");
         
         }
        }   
    //End Add commissions Data ===============
                
    //Start Update commissions Data ===============
    
 	function update_commissions($commissions_arr_, $where_str)
    {
         $gw_commissions_cols=array();
     
     foreach($commissions_arr_ as $commissions_arr_gw => $commissions_arr_gw_val)
     {
     
     	$gw_commissions_cols[]=$commissions_arr_gw;
        
     }
     
     $gw_commissions_cols_str=implode(",", $gw_commissions_cols);
     
     $gwauthenticate_commissions_=gw_oauth("table", magic_current_url(), "commissions", "update",$gw_commissions_cols_str);
     
     $gwauthenticate_commissions_json=json_decode($gwauthenticate_commissions_, true);
     
     if($gwauthenticate_commissions_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("commissions", $commissions_arr_, $where_str);

       // echo $gwauthenticate_commissions_;
        
        exit;

     }else{

        echo $gwauthenticate_commissions_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_commissions_)."");


      }
    
    }
 	
    
    //End Update commissions Data ===============

    //Start get  commissions Data ===============
    
    function get_commissions($colstr, $where_str, $type)
    {
          
     $gwauthenticate_commissions_=gw_oauth("table", magic_current_url(), "commissions", "select","");
     
     $gwauthenticate_commissions_json=json_decode($gwauthenticate_commissions_, true);
     
     if($gwauthenticate_commissions_json["response"]=="ok")
     {
    	return mosyflex_sel("commissions", $colstr, $where_str, $type);

        //echo $gwauthenticate_commissions_;

	  }else{
     
     	echo $gwauthenticate_commissions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_commissions_)."");


     }    
    }
    //End get  commissions Data ===============
    
    
    //======== qcommissions_data qsingle query function
    
    function qcommissions_data($qcommission_id_key)
    {
          
     $gwauthenticate_commissions_=gw_oauth("table", magic_current_url(), "commissions", "qdata","");
     
     $gwauthenticate_commissions_json=json_decode($gwauthenticate_commissions_, true);
     
     if($gwauthenticate_commissions_json["response"]=="ok")
     {    
    	return get_commissions("*", "WHERE commission_id='$qcommission_id_key'", "r");

		//echo $gwauthenticate_commissions_;

      }else{
     
     	echo $gwauthenticate_commissions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_commissions_)."");


     }  
    }
   
    //======== qcommissions_data qsingle query function
    
    
     //======== commissions data to array
    
    function commissions_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_commissions_=gw_oauth("table", magic_current_url(), "commissions", "data_array","");
     
     $gwauthenticate_commissions_json=json_decode($gwauthenticate_commissions_, true);
     
     if($gwauthenticate_commissions_json["response"]=="ok")
     {  
     	$append_commissions_arr=array();
    
    	$array_commissions_q=get_commissions($colstr, $where_str, "l");
        while($array_commissions_res=mysqli_fetch_array($array_commissions_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_commissions_arr[]=$array_commissions_res[$tbl_col];
            }
          }else{
          	          
               $append_commissions_arr[]=$array_commissions_res;

          }
        }
        
        return $append_commissions_arr;

		//echo $gwauthenticate_commissions_;

      }else{
     
     	echo $gwauthenticate_commissions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_commissions_)."");


     }  
    }
   
    //======== qcommissions_data qsingle query function   
        
    //======== qcommissions_ddata qsingle query function    
    function qcommissions_ddata($commission_id_col, $qcommission_id_key)
    {
     
     $gwauthenticate_commissions_=gw_oauth("table", magic_current_url(), "commissions", "qddata","");
     
     $gwauthenticate_commissions_json=json_decode($gwauthenticate_commissions_, true);
     
     if($gwauthenticate_commissions_json["response"]=="ok")
     {    
    	return get_commissions("*", "WHERE $commission_id_col='$qcommission_id_key'", "r");

		//echo $gwauthenticate_commissions_;

     }else{
     
     	echo $gwauthenticate_commissions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_commissions_)."");


     }   
    }
    //======== qcommissions_ddata qsingle query function

    //======== count commissions data function
    
    function count_commissions($commissions_wherestr)
    {
     
     $gwauthenticate_commissions_=gw_oauth("table", magic_current_url(), "commissions", "count_data","");
     
     $gwauthenticate_commissions_json=json_decode($gwauthenticate_commissions_, true);
     
     if($gwauthenticate_commissions_json["response"]=="ok")
     {    
      $clean_commissions_where_str="";
  
      if($commissions_wherestr!='')
      {
        $clean_commissions_where_str="Where ".$commissions_wherestr;
      }

      return get_commissions("count(*) as return_result", " ".$clean_commissions_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_commissions_;

      }else{
     
     	echo $gwauthenticate_commissions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_commissions_)."");


     }    
    }
    //======== count commissions data function

    //======== sum  commissions data function
    
    function sum_commissions($commissions_sumcol, $commissions_wherestr)
    {
     
     $gwauthenticate_commissions_=gw_oauth("table", magic_current_url(), "commissions", "sum_data","");
     
     $gwauthenticate_commissions_json=json_decode($gwauthenticate_commissions_, true);
     
     if($gwauthenticate_commissions_json["response"]=="ok")
     {    
      $clean_commissions_where_str="";
  
      if($commissions_wherestr!='')
      {
        $clean_commissions_where_str="Where ".$commissions_wherestr;
      }

      return get_commissions("sum($commissions_sumcol) as return_result", " ".$clean_commissions_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_commissions_;


      }else{
     
     	echo $gwauthenticate_commissions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_commissions_)."");
        


     }    
    }
    
    //======== sum  commissions data function   
    
    
    //Start drop  commissions Data ===============
    
    function drop_commissions($where_str)
    {
     
     $gwauthenticate_commissions_=gw_oauth("table", magic_current_url(), "commissions", "drop_data","");
     
     $gwauthenticate_commissions_json=json_decode($gwauthenticate_commissions_, true);
     
     if($gwauthenticate_commissions_json["response"]=="ok")
     {    
    	return magic_sql_delete("commissions", $where_str);

		//echo $gwauthenticate_commissions_;

      }else{
     
     	echo $gwauthenticate_commissions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_commissions_)."");
		

     }
    }
    //End drop  commissions Data ===============    
    
    
   

    
 	//Start Add deductions Data ===============
 	function add_deductions($deductions_arr_)
    {
     $gw_deductions_cols=array();
     
     foreach($deductions_arr_ as $deductions_arr_gw => $deductions_arr_gw_val)
     {
     
     	$gw_deductions_cols[]=$deductions_arr_gw;
        
     }
     
     $gw_deductions_cols_str=implode(",", $gw_deductions_cols);
     
     $gwauthenticate_deductions_=gw_oauth("table", magic_current_url(), "deductions", "insert",$gw_deductions_cols_str);
     
     $gwauthenticate_deductions_json=json_decode($gwauthenticate_deductions_, true);
     
     if($gwauthenticate_deductions_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("deductions", $deductions_arr_);
     
     	//echo $gwauthenticate_deductions_;

     }else{
     
     	echo $gwauthenticate_deductions_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_deductions_)."");

     }
     
    }
    
       function initialize_deductions()
        {
        
         global $deductions_uptoken;
             
         $gwauthenticate_deductions_=gw_oauth("table", magic_current_url(), "deductions", "select","");

         $gwauthenticate_deductions_json=json_decode($gwauthenticate_deductions_, true);
         	
          //echo $gwauthenticate_deductions_;

         if($gwauthenticate_deductions_json["response"]=="ok")
         {
         
         	return get_deductions("*", "WHERE primkey='$deductions_uptoken'", "r");
         
            echo $gwauthenticate_deductions_;

         }else{

         	echo $gwauthenticate_deductions_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_deductions_)."");
         
         }
        }   
    //End Add deductions Data ===============
                
    //Start Update deductions Data ===============
    
 	function update_deductions($deductions_arr_, $where_str)
    {
         $gw_deductions_cols=array();
     
     foreach($deductions_arr_ as $deductions_arr_gw => $deductions_arr_gw_val)
     {
     
     	$gw_deductions_cols[]=$deductions_arr_gw;
        
     }
     
     $gw_deductions_cols_str=implode(",", $gw_deductions_cols);
     
     $gwauthenticate_deductions_=gw_oauth("table", magic_current_url(), "deductions", "update",$gw_deductions_cols_str);
     
     $gwauthenticate_deductions_json=json_decode($gwauthenticate_deductions_, true);
     
     if($gwauthenticate_deductions_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("deductions", $deductions_arr_, $where_str);

       // echo $gwauthenticate_deductions_;
        
        exit;

     }else{

        echo $gwauthenticate_deductions_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_deductions_)."");


      }
    
    }
 	
    
    //End Update deductions Data ===============

    //Start get  deductions Data ===============
    
    function get_deductions($colstr, $where_str, $type)
    {
          
     $gwauthenticate_deductions_=gw_oauth("table", magic_current_url(), "deductions", "select","");
     
     $gwauthenticate_deductions_json=json_decode($gwauthenticate_deductions_, true);
     
     if($gwauthenticate_deductions_json["response"]=="ok")
     {
    	return mosyflex_sel("deductions", $colstr, $where_str, $type);

        //echo $gwauthenticate_deductions_;

	  }else{
     
     	echo $gwauthenticate_deductions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_deductions_)."");


     }    
    }
    //End get  deductions Data ===============
    
    
    //======== qdeductions_data qsingle query function
    
    function qdeductions_data($qdeduction_id_key)
    {
          
     $gwauthenticate_deductions_=gw_oauth("table", magic_current_url(), "deductions", "qdata","");
     
     $gwauthenticate_deductions_json=json_decode($gwauthenticate_deductions_, true);
     
     if($gwauthenticate_deductions_json["response"]=="ok")
     {    
    	return get_deductions("*", "WHERE deduction_id='$qdeduction_id_key'", "r");

		//echo $gwauthenticate_deductions_;

      }else{
     
     	echo $gwauthenticate_deductions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_deductions_)."");


     }  
    }
   
    //======== qdeductions_data qsingle query function
    
    
     //======== deductions data to array
    
    function deductions_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_deductions_=gw_oauth("table", magic_current_url(), "deductions", "data_array","");
     
     $gwauthenticate_deductions_json=json_decode($gwauthenticate_deductions_, true);
     
     if($gwauthenticate_deductions_json["response"]=="ok")
     {  
     	$append_deductions_arr=array();
    
    	$array_deductions_q=get_deductions($colstr, $where_str, "l");
        while($array_deductions_res=mysqli_fetch_array($array_deductions_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_deductions_arr[]=$array_deductions_res[$tbl_col];
            }
          }else{
          	          
               $append_deductions_arr[]=$array_deductions_res;

          }
        }
        
        return $append_deductions_arr;

		//echo $gwauthenticate_deductions_;

      }else{
     
     	echo $gwauthenticate_deductions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_deductions_)."");


     }  
    }
   
    //======== qdeductions_data qsingle query function   
        
    //======== qdeductions_ddata qsingle query function    
    function qdeductions_ddata($deduction_id_col, $qdeduction_id_key)
    {
     
     $gwauthenticate_deductions_=gw_oauth("table", magic_current_url(), "deductions", "qddata","");
     
     $gwauthenticate_deductions_json=json_decode($gwauthenticate_deductions_, true);
     
     if($gwauthenticate_deductions_json["response"]=="ok")
     {    
    	return get_deductions("*", "WHERE $deduction_id_col='$qdeduction_id_key'", "r");

		//echo $gwauthenticate_deductions_;

     }else{
     
     	echo $gwauthenticate_deductions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_deductions_)."");


     }   
    }
    //======== qdeductions_ddata qsingle query function

    //======== count deductions data function
    
    function count_deductions($deductions_wherestr)
    {
     
     $gwauthenticate_deductions_=gw_oauth("table", magic_current_url(), "deductions", "count_data","");
     
     $gwauthenticate_deductions_json=json_decode($gwauthenticate_deductions_, true);
     
     if($gwauthenticate_deductions_json["response"]=="ok")
     {    
      $clean_deductions_where_str="";
  
      if($deductions_wherestr!='')
      {
        $clean_deductions_where_str="Where ".$deductions_wherestr;
      }

      return get_deductions("count(*) as return_result", " ".$clean_deductions_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_deductions_;

      }else{
     
     	echo $gwauthenticate_deductions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_deductions_)."");


     }    
    }
    //======== count deductions data function

    //======== sum  deductions data function
    
    function sum_deductions($deductions_sumcol, $deductions_wherestr)
    {
     
     $gwauthenticate_deductions_=gw_oauth("table", magic_current_url(), "deductions", "sum_data","");
     
     $gwauthenticate_deductions_json=json_decode($gwauthenticate_deductions_, true);
     
     if($gwauthenticate_deductions_json["response"]=="ok")
     {    
      $clean_deductions_where_str="";
  
      if($deductions_wherestr!='')
      {
        $clean_deductions_where_str="Where ".$deductions_wherestr;
      }

      return get_deductions("sum($deductions_sumcol) as return_result", " ".$clean_deductions_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_deductions_;


      }else{
     
     	echo $gwauthenticate_deductions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_deductions_)."");
        


     }    
    }
    
    //======== sum  deductions data function   
    
    
    //Start drop  deductions Data ===============
    
    function drop_deductions($where_str)
    {
     
     $gwauthenticate_deductions_=gw_oauth("table", magic_current_url(), "deductions", "drop_data","");
     
     $gwauthenticate_deductions_json=json_decode($gwauthenticate_deductions_, true);
     
     if($gwauthenticate_deductions_json["response"]=="ok")
     {    
    	return magic_sql_delete("deductions", $where_str);

		//echo $gwauthenticate_deductions_;

      }else{
     
     	echo $gwauthenticate_deductions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_deductions_)."");
		

     }
    }
    //End drop  deductions Data ===============    
    
    
   

    
 	//Start Add employee_loans Data ===============
 	function add_employee_loans($employee_loans_arr_)
    {
     $gw_employee_loans_cols=array();
     
     foreach($employee_loans_arr_ as $employee_loans_arr_gw => $employee_loans_arr_gw_val)
     {
     
     	$gw_employee_loans_cols[]=$employee_loans_arr_gw;
        
     }
     
     $gw_employee_loans_cols_str=implode(",", $gw_employee_loans_cols);
     
     $gwauthenticate_employee_loans_=gw_oauth("table", magic_current_url(), "employee_loans", "insert",$gw_employee_loans_cols_str);
     
     $gwauthenticate_employee_loans_json=json_decode($gwauthenticate_employee_loans_, true);
     
     if($gwauthenticate_employee_loans_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("employee_loans", $employee_loans_arr_);
     
     	//echo $gwauthenticate_employee_loans_;

     }else{
     
     	echo $gwauthenticate_employee_loans_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employee_loans_)."");

     }
     
    }
    
       function initialize_employee_loans()
        {
        
         global $employee_loans_uptoken;
             
         $gwauthenticate_employee_loans_=gw_oauth("table", magic_current_url(), "employee_loans", "select","");

         $gwauthenticate_employee_loans_json=json_decode($gwauthenticate_employee_loans_, true);
         	
          //echo $gwauthenticate_employee_loans_;

         if($gwauthenticate_employee_loans_json["response"]=="ok")
         {
         
         	return get_employee_loans("*", "WHERE primkey='$employee_loans_uptoken'", "r");
         
            echo $gwauthenticate_employee_loans_;

         }else{

         	echo $gwauthenticate_employee_loans_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employee_loans_)."");
         
         }
        }   
    //End Add employee_loans Data ===============
                
    //Start Update employee_loans Data ===============
    
 	function update_employee_loans($employee_loans_arr_, $where_str)
    {
         $gw_employee_loans_cols=array();
     
     foreach($employee_loans_arr_ as $employee_loans_arr_gw => $employee_loans_arr_gw_val)
     {
     
     	$gw_employee_loans_cols[]=$employee_loans_arr_gw;
        
     }
     
     $gw_employee_loans_cols_str=implode(",", $gw_employee_loans_cols);
     
     $gwauthenticate_employee_loans_=gw_oauth("table", magic_current_url(), "employee_loans", "update",$gw_employee_loans_cols_str);
     
     $gwauthenticate_employee_loans_json=json_decode($gwauthenticate_employee_loans_, true);
     
     if($gwauthenticate_employee_loans_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("employee_loans", $employee_loans_arr_, $where_str);

       // echo $gwauthenticate_employee_loans_;
        
        exit;

     }else{

        echo $gwauthenticate_employee_loans_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employee_loans_)."");


      }
    
    }
 	
    
    //End Update employee_loans Data ===============

    //Start get  employee_loans Data ===============
    
    function get_employee_loans($colstr, $where_str, $type)
    {
          
     $gwauthenticate_employee_loans_=gw_oauth("table", magic_current_url(), "employee_loans", "select","");
     
     $gwauthenticate_employee_loans_json=json_decode($gwauthenticate_employee_loans_, true);
     
     if($gwauthenticate_employee_loans_json["response"]=="ok")
     {
    	return mosyflex_sel("employee_loans", $colstr, $where_str, $type);

        //echo $gwauthenticate_employee_loans_;

	  }else{
     
     	echo $gwauthenticate_employee_loans_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employee_loans_)."");


     }    
    }
    //End get  employee_loans Data ===============
    
    
    //======== qemployee_loans_data qsingle query function
    
    function qemployee_loans_data($qloan_id_key)
    {
          
     $gwauthenticate_employee_loans_=gw_oauth("table", magic_current_url(), "employee_loans", "qdata","");
     
     $gwauthenticate_employee_loans_json=json_decode($gwauthenticate_employee_loans_, true);
     
     if($gwauthenticate_employee_loans_json["response"]=="ok")
     {    
    	return get_employee_loans("*", "WHERE loan_id='$qloan_id_key'", "r");

		//echo $gwauthenticate_employee_loans_;

      }else{
     
     	echo $gwauthenticate_employee_loans_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employee_loans_)."");


     }  
    }
   
    //======== qemployee_loans_data qsingle query function
    
    
     //======== employee_loans data to array
    
    function employee_loans_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_employee_loans_=gw_oauth("table", magic_current_url(), "employee_loans", "data_array","");
     
     $gwauthenticate_employee_loans_json=json_decode($gwauthenticate_employee_loans_, true);
     
     if($gwauthenticate_employee_loans_json["response"]=="ok")
     {  
     	$append_employee_loans_arr=array();
    
    	$array_employee_loans_q=get_employee_loans($colstr, $where_str, "l");
        while($array_employee_loans_res=mysqli_fetch_array($array_employee_loans_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_employee_loans_arr[]=$array_employee_loans_res[$tbl_col];
            }
          }else{
          	          
               $append_employee_loans_arr[]=$array_employee_loans_res;

          }
        }
        
        return $append_employee_loans_arr;

		//echo $gwauthenticate_employee_loans_;

      }else{
     
     	echo $gwauthenticate_employee_loans_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employee_loans_)."");


     }  
    }
   
    //======== qemployee_loans_data qsingle query function   
        
    //======== qemployee_loans_ddata qsingle query function    
    function qemployee_loans_ddata($loan_id_col, $qloan_id_key)
    {
     
     $gwauthenticate_employee_loans_=gw_oauth("table", magic_current_url(), "employee_loans", "qddata","");
     
     $gwauthenticate_employee_loans_json=json_decode($gwauthenticate_employee_loans_, true);
     
     if($gwauthenticate_employee_loans_json["response"]=="ok")
     {    
    	return get_employee_loans("*", "WHERE $loan_id_col='$qloan_id_key'", "r");

		//echo $gwauthenticate_employee_loans_;

     }else{
     
     	echo $gwauthenticate_employee_loans_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employee_loans_)."");


     }   
    }
    //======== qemployee_loans_ddata qsingle query function

    //======== count employee_loans data function
    
    function count_employee_loans($employee_loans_wherestr)
    {
     
     $gwauthenticate_employee_loans_=gw_oauth("table", magic_current_url(), "employee_loans", "count_data","");
     
     $gwauthenticate_employee_loans_json=json_decode($gwauthenticate_employee_loans_, true);
     
     if($gwauthenticate_employee_loans_json["response"]=="ok")
     {    
      $clean_employee_loans_where_str="";
  
      if($employee_loans_wherestr!='')
      {
        $clean_employee_loans_where_str="Where ".$employee_loans_wherestr;
      }

      return get_employee_loans("count(*) as return_result", " ".$clean_employee_loans_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_employee_loans_;

      }else{
     
     	echo $gwauthenticate_employee_loans_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employee_loans_)."");


     }    
    }
    //======== count employee_loans data function

    //======== sum  employee_loans data function
    
    function sum_employee_loans($employee_loans_sumcol, $employee_loans_wherestr)
    {
     
     $gwauthenticate_employee_loans_=gw_oauth("table", magic_current_url(), "employee_loans", "sum_data","");
     
     $gwauthenticate_employee_loans_json=json_decode($gwauthenticate_employee_loans_, true);
     
     if($gwauthenticate_employee_loans_json["response"]=="ok")
     {    
      $clean_employee_loans_where_str="";
  
      if($employee_loans_wherestr!='')
      {
        $clean_employee_loans_where_str="Where ".$employee_loans_wherestr;
      }

      return get_employee_loans("sum($employee_loans_sumcol) as return_result", " ".$clean_employee_loans_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_employee_loans_;


      }else{
     
     	echo $gwauthenticate_employee_loans_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employee_loans_)."");
        


     }    
    }
    
    //======== sum  employee_loans data function   
    
    
    //Start drop  employee_loans Data ===============
    
    function drop_employee_loans($where_str)
    {
     
     $gwauthenticate_employee_loans_=gw_oauth("table", magic_current_url(), "employee_loans", "drop_data","");
     
     $gwauthenticate_employee_loans_json=json_decode($gwauthenticate_employee_loans_, true);
     
     if($gwauthenticate_employee_loans_json["response"]=="ok")
     {    
    	return magic_sql_delete("employee_loans", $where_str);

		//echo $gwauthenticate_employee_loans_;

      }else{
     
     	echo $gwauthenticate_employee_loans_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employee_loans_)."");
		

     }
    }
    //End drop  employee_loans Data ===============    
    
    
   

    
 	//Start Add employees Data ===============
 	function add_employees($employees_arr_)
    {
     $gw_employees_cols=array();
     
     foreach($employees_arr_ as $employees_arr_gw => $employees_arr_gw_val)
     {
     
     	$gw_employees_cols[]=$employees_arr_gw;
        
     }
     
     $gw_employees_cols_str=implode(",", $gw_employees_cols);
     
     $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "insert",$gw_employees_cols_str);
     
     $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
     
     if($gwauthenticate_employees_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("employees", $employees_arr_);
     
     	//echo $gwauthenticate_employees_;

     }else{
     
     	echo $gwauthenticate_employees_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_)."");

     }
     
    }
    
       function initialize_employees()
        {
        
         global $employees_uptoken;
             
         $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "select","");

         $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
         	
          //echo $gwauthenticate_employees_;

         if($gwauthenticate_employees_json["response"]=="ok")
         {
         
         	return get_employees("*", "WHERE primkey='$employees_uptoken'", "r");
         
            echo $gwauthenticate_employees_;

         }else{

         	echo $gwauthenticate_employees_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_)."");
         
         }
        }   
    //End Add employees Data ===============
                
    //Start Update employees Data ===============
    
 	function update_employees($employees_arr_, $where_str)
    {
         $gw_employees_cols=array();
     
     foreach($employees_arr_ as $employees_arr_gw => $employees_arr_gw_val)
     {
     
     	$gw_employees_cols[]=$employees_arr_gw;
        
     }
     
     $gw_employees_cols_str=implode(",", $gw_employees_cols);
     
     $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "update",$gw_employees_cols_str);
     
     $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
     
     if($gwauthenticate_employees_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("employees", $employees_arr_, $where_str);

       // echo $gwauthenticate_employees_;
        
        exit;

     }else{

        echo $gwauthenticate_employees_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_)."");


      }
    
    }
 	
    
    //End Update employees Data ===============

    //Start get  employees Data ===============
    
    function get_employees($colstr, $where_str, $type)
    {
          
     $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "select","");
     
     $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
     
     if($gwauthenticate_employees_json["response"]=="ok")
     {
    	return mosyflex_sel("employees", $colstr, $where_str, $type);

        //echo $gwauthenticate_employees_;

	  }else{
     
     	echo $gwauthenticate_employees_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_)."");


     }    
    }
    //End get  employees Data ===============
    
    
    //======== qemployees_data qsingle query function
    
    function qemployees_data($quser_id_key)
    {
          
     $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "qdata","");
     
     $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
     
     if($gwauthenticate_employees_json["response"]=="ok")
     {    
    	return get_employees("*", "WHERE user_id='$quser_id_key'", "r");

		//echo $gwauthenticate_employees_;

      }else{
     
     	echo $gwauthenticate_employees_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_)."");


     }  
    }
   
    //======== qemployees_data qsingle query function
    
    
     //======== employees data to array
    
    function employees_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "data_array","");
     
     $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
     
     if($gwauthenticate_employees_json["response"]=="ok")
     {  
     	$append_employees_arr=array();
    
    	$array_employees_q=get_employees($colstr, $where_str, "l");
        while($array_employees_res=mysqli_fetch_array($array_employees_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_employees_arr[]=$array_employees_res[$tbl_col];
            }
          }else{
          	          
               $append_employees_arr[]=$array_employees_res;

          }
        }
        
        return $append_employees_arr;

		//echo $gwauthenticate_employees_;

      }else{
     
     	echo $gwauthenticate_employees_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_)."");


     }  
    }
   
    //======== qemployees_data qsingle query function   
        
    //======== qemployees_ddata qsingle query function    
    function qemployees_ddata($user_id_col, $quser_id_key)
    {
     
     $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "qddata","");
     
     $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
     
     if($gwauthenticate_employees_json["response"]=="ok")
     {    
    	return get_employees("*", "WHERE $user_id_col='$quser_id_key'", "r");

		//echo $gwauthenticate_employees_;

     }else{
     
     	echo $gwauthenticate_employees_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_)."");


     }   
    }
    //======== qemployees_ddata qsingle query function

    //======== count employees data function
    
    function count_employees($employees_wherestr)
    {
     
     $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "count_data","");
     
     $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
     
     if($gwauthenticate_employees_json["response"]=="ok")
     {    
      $clean_employees_where_str="";
  
      if($employees_wherestr!='')
      {
        $clean_employees_where_str="Where ".$employees_wherestr;
      }

      return get_employees("count(*) as return_result", " ".$clean_employees_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_employees_;

      }else{
     
     	echo $gwauthenticate_employees_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_)."");


     }    
    }
    //======== count employees data function

    //======== sum  employees data function
    
    function sum_employees($employees_sumcol, $employees_wherestr)
    {
     
     $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "sum_data","");
     
     $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
     
     if($gwauthenticate_employees_json["response"]=="ok")
     {    
      $clean_employees_where_str="";
  
      if($employees_wherestr!='')
      {
        $clean_employees_where_str="Where ".$employees_wherestr;
      }

      return get_employees("sum($employees_sumcol) as return_result", " ".$clean_employees_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_employees_;


      }else{
     
     	echo $gwauthenticate_employees_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_)."");
        


     }    
    }
    
    //======== sum  employees data function   
    
    
    //Start drop  employees Data ===============
    
    function drop_employees($where_str)
    {
     
     $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "drop_data","");
     
     $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
     
     if($gwauthenticate_employees_json["response"]=="ok")
     {    
    	return magic_sql_delete("employees", $where_str);

		//echo $gwauthenticate_employees_;

      }else{
     
     	echo $gwauthenticate_employees_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_)."");
		

     }
    }
    //End drop  employees Data ===============    
    
    
            //Start Upload employees_passport_photo Function 
            function upload_employees_passport_photo($txt_employees_passport_photo, $where_str){
              
                $file_name1=explode(".", basename($_FILES[$txt_employees_passport_photo]['name']))[0];

                $file_name=str_replace(" ", "_", $file_name1);

                if (!file_exists('./img/employees_passport_photo')) @mkdir('./img/employees_passport_photo');

                $cur_item_photos=magic_upload_file('./img/employees_passport_photo/', $txt_employees_passport_photo, $file_name."_".magic_random_str(5));

                $item_photo=mmres($cur_item_photos);

                magic_compress_file($cur_item_photos, $cur_item_photos, 50);

                $employees_node=get_employees("*", "WHERE ".$where_str."", "r");

                  if (file_exists($employees_node["passport_photo"]))
                  {

                      unlink($employees_node["passport_photo"]);

                  }
                  if($where_str!="")
                  {
                    magic_sql_update('employees', '{"passport_photo":"'.$cur_item_photos.'"}', $where_str);
                  } 

              return $cur_item_photos;

			}
           //End Upload employees_passport_photo Function 

            
   

    
 	//Start Add employees_next_of_kin Data ===============
 	function add_employees_next_of_kin($employees_next_of_kin_arr_)
    {
     $gw_employees_next_of_kin_cols=array();
     
     foreach($employees_next_of_kin_arr_ as $employees_next_of_kin_arr_gw => $employees_next_of_kin_arr_gw_val)
     {
     
     	$gw_employees_next_of_kin_cols[]=$employees_next_of_kin_arr_gw;
        
     }
     
     $gw_employees_next_of_kin_cols_str=implode(",", $gw_employees_next_of_kin_cols);
     
     $gwauthenticate_employees_next_of_kin_=gw_oauth("table", magic_current_url(), "employees_next_of_kin", "insert",$gw_employees_next_of_kin_cols_str);
     
     $gwauthenticate_employees_next_of_kin_json=json_decode($gwauthenticate_employees_next_of_kin_, true);
     
     if($gwauthenticate_employees_next_of_kin_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("employees_next_of_kin", $employees_next_of_kin_arr_);
     
     	//echo $gwauthenticate_employees_next_of_kin_;

     }else{
     
     	echo $gwauthenticate_employees_next_of_kin_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_next_of_kin_)."");

     }
     
    }
    
       function initialize_employees_next_of_kin()
        {
        
         global $employees_next_of_kin_uptoken;
             
         $gwauthenticate_employees_next_of_kin_=gw_oauth("table", magic_current_url(), "employees_next_of_kin", "select","");

         $gwauthenticate_employees_next_of_kin_json=json_decode($gwauthenticate_employees_next_of_kin_, true);
         	
          //echo $gwauthenticate_employees_next_of_kin_;

         if($gwauthenticate_employees_next_of_kin_json["response"]=="ok")
         {
         
         	return get_employees_next_of_kin("*", "WHERE primkey='$employees_next_of_kin_uptoken'", "r");
         
            echo $gwauthenticate_employees_next_of_kin_;

         }else{

         	echo $gwauthenticate_employees_next_of_kin_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_next_of_kin_)."");
         
         }
        }   
    //End Add employees_next_of_kin Data ===============
                
    //Start Update employees_next_of_kin Data ===============
    
 	function update_employees_next_of_kin($employees_next_of_kin_arr_, $where_str)
    {
         $gw_employees_next_of_kin_cols=array();
     
     foreach($employees_next_of_kin_arr_ as $employees_next_of_kin_arr_gw => $employees_next_of_kin_arr_gw_val)
     {
     
     	$gw_employees_next_of_kin_cols[]=$employees_next_of_kin_arr_gw;
        
     }
     
     $gw_employees_next_of_kin_cols_str=implode(",", $gw_employees_next_of_kin_cols);
     
     $gwauthenticate_employees_next_of_kin_=gw_oauth("table", magic_current_url(), "employees_next_of_kin", "update",$gw_employees_next_of_kin_cols_str);
     
     $gwauthenticate_employees_next_of_kin_json=json_decode($gwauthenticate_employees_next_of_kin_, true);
     
     if($gwauthenticate_employees_next_of_kin_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("employees_next_of_kin", $employees_next_of_kin_arr_, $where_str);

       // echo $gwauthenticate_employees_next_of_kin_;
        
        exit;

     }else{

        echo $gwauthenticate_employees_next_of_kin_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_next_of_kin_)."");


      }
    
    }
 	
    
    //End Update employees_next_of_kin Data ===============

    //Start get  employees_next_of_kin Data ===============
    
    function get_employees_next_of_kin($colstr, $where_str, $type)
    {
          
     $gwauthenticate_employees_next_of_kin_=gw_oauth("table", magic_current_url(), "employees_next_of_kin", "select","");
     
     $gwauthenticate_employees_next_of_kin_json=json_decode($gwauthenticate_employees_next_of_kin_, true);
     
     if($gwauthenticate_employees_next_of_kin_json["response"]=="ok")
     {
    	return mosyflex_sel("employees_next_of_kin", $colstr, $where_str, $type);

        //echo $gwauthenticate_employees_next_of_kin_;

	  }else{
     
     	echo $gwauthenticate_employees_next_of_kin_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_next_of_kin_)."");


     }    
    }
    //End get  employees_next_of_kin Data ===============
    
    
    //======== qemployees_next_of_kin_data qsingle query function
    
    function qemployees_next_of_kin_data($qkin_id_key)
    {
          
     $gwauthenticate_employees_next_of_kin_=gw_oauth("table", magic_current_url(), "employees_next_of_kin", "qdata","");
     
     $gwauthenticate_employees_next_of_kin_json=json_decode($gwauthenticate_employees_next_of_kin_, true);
     
     if($gwauthenticate_employees_next_of_kin_json["response"]=="ok")
     {    
    	return get_employees_next_of_kin("*", "WHERE kin_id='$qkin_id_key'", "r");

		//echo $gwauthenticate_employees_next_of_kin_;

      }else{
     
     	echo $gwauthenticate_employees_next_of_kin_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_next_of_kin_)."");


     }  
    }
   
    //======== qemployees_next_of_kin_data qsingle query function
    
    
     //======== employees_next_of_kin data to array
    
    function employees_next_of_kin_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_employees_next_of_kin_=gw_oauth("table", magic_current_url(), "employees_next_of_kin", "data_array","");
     
     $gwauthenticate_employees_next_of_kin_json=json_decode($gwauthenticate_employees_next_of_kin_, true);
     
     if($gwauthenticate_employees_next_of_kin_json["response"]=="ok")
     {  
     	$append_employees_next_of_kin_arr=array();
    
    	$array_employees_next_of_kin_q=get_employees_next_of_kin($colstr, $where_str, "l");
        while($array_employees_next_of_kin_res=mysqli_fetch_array($array_employees_next_of_kin_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_employees_next_of_kin_arr[]=$array_employees_next_of_kin_res[$tbl_col];
            }
          }else{
          	          
               $append_employees_next_of_kin_arr[]=$array_employees_next_of_kin_res;

          }
        }
        
        return $append_employees_next_of_kin_arr;

		//echo $gwauthenticate_employees_next_of_kin_;

      }else{
     
     	echo $gwauthenticate_employees_next_of_kin_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_next_of_kin_)."");


     }  
    }
   
    //======== qemployees_next_of_kin_data qsingle query function   
        
    //======== qemployees_next_of_kin_ddata qsingle query function    
    function qemployees_next_of_kin_ddata($kin_id_col, $qkin_id_key)
    {
     
     $gwauthenticate_employees_next_of_kin_=gw_oauth("table", magic_current_url(), "employees_next_of_kin", "qddata","");
     
     $gwauthenticate_employees_next_of_kin_json=json_decode($gwauthenticate_employees_next_of_kin_, true);
     
     if($gwauthenticate_employees_next_of_kin_json["response"]=="ok")
     {    
    	return get_employees_next_of_kin("*", "WHERE $kin_id_col='$qkin_id_key'", "r");

		//echo $gwauthenticate_employees_next_of_kin_;

     }else{
     
     	echo $gwauthenticate_employees_next_of_kin_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_next_of_kin_)."");


     }   
    }
    //======== qemployees_next_of_kin_ddata qsingle query function

    //======== count employees_next_of_kin data function
    
    function count_employees_next_of_kin($employees_next_of_kin_wherestr)
    {
     
     $gwauthenticate_employees_next_of_kin_=gw_oauth("table", magic_current_url(), "employees_next_of_kin", "count_data","");
     
     $gwauthenticate_employees_next_of_kin_json=json_decode($gwauthenticate_employees_next_of_kin_, true);
     
     if($gwauthenticate_employees_next_of_kin_json["response"]=="ok")
     {    
      $clean_employees_next_of_kin_where_str="";
  
      if($employees_next_of_kin_wherestr!='')
      {
        $clean_employees_next_of_kin_where_str="Where ".$employees_next_of_kin_wherestr;
      }

      return get_employees_next_of_kin("count(*) as return_result", " ".$clean_employees_next_of_kin_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_employees_next_of_kin_;

      }else{
     
     	echo $gwauthenticate_employees_next_of_kin_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_next_of_kin_)."");


     }    
    }
    //======== count employees_next_of_kin data function

    //======== sum  employees_next_of_kin data function
    
    function sum_employees_next_of_kin($employees_next_of_kin_sumcol, $employees_next_of_kin_wherestr)
    {
     
     $gwauthenticate_employees_next_of_kin_=gw_oauth("table", magic_current_url(), "employees_next_of_kin", "sum_data","");
     
     $gwauthenticate_employees_next_of_kin_json=json_decode($gwauthenticate_employees_next_of_kin_, true);
     
     if($gwauthenticate_employees_next_of_kin_json["response"]=="ok")
     {    
      $clean_employees_next_of_kin_where_str="";
  
      if($employees_next_of_kin_wherestr!='')
      {
        $clean_employees_next_of_kin_where_str="Where ".$employees_next_of_kin_wherestr;
      }

      return get_employees_next_of_kin("sum($employees_next_of_kin_sumcol) as return_result", " ".$clean_employees_next_of_kin_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_employees_next_of_kin_;


      }else{
     
     	echo $gwauthenticate_employees_next_of_kin_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_next_of_kin_)."");
        


     }    
    }
    
    //======== sum  employees_next_of_kin data function   
    
    
    //Start drop  employees_next_of_kin Data ===============
    
    function drop_employees_next_of_kin($where_str)
    {
     
     $gwauthenticate_employees_next_of_kin_=gw_oauth("table", magic_current_url(), "employees_next_of_kin", "drop_data","");
     
     $gwauthenticate_employees_next_of_kin_json=json_decode($gwauthenticate_employees_next_of_kin_, true);
     
     if($gwauthenticate_employees_next_of_kin_json["response"]=="ok")
     {    
    	return magic_sql_delete("employees_next_of_kin", $where_str);

		//echo $gwauthenticate_employees_next_of_kin_;

      }else{
     
     	echo $gwauthenticate_employees_next_of_kin_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_next_of_kin_)."");
		

     }
    }
    //End drop  employees_next_of_kin Data ===============    
    
    
   

    
 	//Start Add expense_claims Data ===============
 	function add_expense_claims($expense_claims_arr_)
    {
     $gw_expense_claims_cols=array();
     
     foreach($expense_claims_arr_ as $expense_claims_arr_gw => $expense_claims_arr_gw_val)
     {
     
     	$gw_expense_claims_cols[]=$expense_claims_arr_gw;
        
     }
     
     $gw_expense_claims_cols_str=implode(",", $gw_expense_claims_cols);
     
     $gwauthenticate_expense_claims_=gw_oauth("table", magic_current_url(), "expense_claims", "insert",$gw_expense_claims_cols_str);
     
     $gwauthenticate_expense_claims_json=json_decode($gwauthenticate_expense_claims_, true);
     
     if($gwauthenticate_expense_claims_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("expense_claims", $expense_claims_arr_);
     
     	//echo $gwauthenticate_expense_claims_;

     }else{
     
     	echo $gwauthenticate_expense_claims_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expense_claims_)."");

     }
     
    }
    
       function initialize_expense_claims()
        {
        
         global $expense_claims_uptoken;
             
         $gwauthenticate_expense_claims_=gw_oauth("table", magic_current_url(), "expense_claims", "select","");

         $gwauthenticate_expense_claims_json=json_decode($gwauthenticate_expense_claims_, true);
         	
          //echo $gwauthenticate_expense_claims_;

         if($gwauthenticate_expense_claims_json["response"]=="ok")
         {
         
         	return get_expense_claims("*", "WHERE primkey='$expense_claims_uptoken'", "r");
         
            echo $gwauthenticate_expense_claims_;

         }else{

         	echo $gwauthenticate_expense_claims_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expense_claims_)."");
         
         }
        }   
    //End Add expense_claims Data ===============
                
    //Start Update expense_claims Data ===============
    
 	function update_expense_claims($expense_claims_arr_, $where_str)
    {
         $gw_expense_claims_cols=array();
     
     foreach($expense_claims_arr_ as $expense_claims_arr_gw => $expense_claims_arr_gw_val)
     {
     
     	$gw_expense_claims_cols[]=$expense_claims_arr_gw;
        
     }
     
     $gw_expense_claims_cols_str=implode(",", $gw_expense_claims_cols);
     
     $gwauthenticate_expense_claims_=gw_oauth("table", magic_current_url(), "expense_claims", "update",$gw_expense_claims_cols_str);
     
     $gwauthenticate_expense_claims_json=json_decode($gwauthenticate_expense_claims_, true);
     
     if($gwauthenticate_expense_claims_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("expense_claims", $expense_claims_arr_, $where_str);

       // echo $gwauthenticate_expense_claims_;
        
        exit;

     }else{

        echo $gwauthenticate_expense_claims_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expense_claims_)."");


      }
    
    }
 	
    
    //End Update expense_claims Data ===============

    //Start get  expense_claims Data ===============
    
    function get_expense_claims($colstr, $where_str, $type)
    {
          
     $gwauthenticate_expense_claims_=gw_oauth("table", magic_current_url(), "expense_claims", "select","");
     
     $gwauthenticate_expense_claims_json=json_decode($gwauthenticate_expense_claims_, true);
     
     if($gwauthenticate_expense_claims_json["response"]=="ok")
     {
    	return mosyflex_sel("expense_claims", $colstr, $where_str, $type);

        //echo $gwauthenticate_expense_claims_;

	  }else{
     
     	echo $gwauthenticate_expense_claims_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expense_claims_)."");


     }    
    }
    //End get  expense_claims Data ===============
    
    
    //======== qexpense_claims_data qsingle query function
    
    function qexpense_claims_data($qclaim_key_key)
    {
          
     $gwauthenticate_expense_claims_=gw_oauth("table", magic_current_url(), "expense_claims", "qdata","");
     
     $gwauthenticate_expense_claims_json=json_decode($gwauthenticate_expense_claims_, true);
     
     if($gwauthenticate_expense_claims_json["response"]=="ok")
     {    
    	return get_expense_claims("*", "WHERE claim_key='$qclaim_key_key'", "r");

		//echo $gwauthenticate_expense_claims_;

      }else{
     
     	echo $gwauthenticate_expense_claims_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expense_claims_)."");


     }  
    }
   
    //======== qexpense_claims_data qsingle query function
    
    
     //======== expense_claims data to array
    
    function expense_claims_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_expense_claims_=gw_oauth("table", magic_current_url(), "expense_claims", "data_array","");
     
     $gwauthenticate_expense_claims_json=json_decode($gwauthenticate_expense_claims_, true);
     
     if($gwauthenticate_expense_claims_json["response"]=="ok")
     {  
     	$append_expense_claims_arr=array();
    
    	$array_expense_claims_q=get_expense_claims($colstr, $where_str, "l");
        while($array_expense_claims_res=mysqli_fetch_array($array_expense_claims_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_expense_claims_arr[]=$array_expense_claims_res[$tbl_col];
            }
          }else{
          	          
               $append_expense_claims_arr[]=$array_expense_claims_res;

          }
        }
        
        return $append_expense_claims_arr;

		//echo $gwauthenticate_expense_claims_;

      }else{
     
     	echo $gwauthenticate_expense_claims_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expense_claims_)."");


     }  
    }
   
    //======== qexpense_claims_data qsingle query function   
        
    //======== qexpense_claims_ddata qsingle query function    
    function qexpense_claims_ddata($claim_key_col, $qclaim_key_key)
    {
     
     $gwauthenticate_expense_claims_=gw_oauth("table", magic_current_url(), "expense_claims", "qddata","");
     
     $gwauthenticate_expense_claims_json=json_decode($gwauthenticate_expense_claims_, true);
     
     if($gwauthenticate_expense_claims_json["response"]=="ok")
     {    
    	return get_expense_claims("*", "WHERE $claim_key_col='$qclaim_key_key'", "r");

		//echo $gwauthenticate_expense_claims_;

     }else{
     
     	echo $gwauthenticate_expense_claims_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expense_claims_)."");


     }   
    }
    //======== qexpense_claims_ddata qsingle query function

    //======== count expense_claims data function
    
    function count_expense_claims($expense_claims_wherestr)
    {
     
     $gwauthenticate_expense_claims_=gw_oauth("table", magic_current_url(), "expense_claims", "count_data","");
     
     $gwauthenticate_expense_claims_json=json_decode($gwauthenticate_expense_claims_, true);
     
     if($gwauthenticate_expense_claims_json["response"]=="ok")
     {    
      $clean_expense_claims_where_str="";
  
      if($expense_claims_wherestr!='')
      {
        $clean_expense_claims_where_str="Where ".$expense_claims_wherestr;
      }

      return get_expense_claims("count(*) as return_result", " ".$clean_expense_claims_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_expense_claims_;

      }else{
     
     	echo $gwauthenticate_expense_claims_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expense_claims_)."");


     }    
    }
    //======== count expense_claims data function

    //======== sum  expense_claims data function
    
    function sum_expense_claims($expense_claims_sumcol, $expense_claims_wherestr)
    {
     
     $gwauthenticate_expense_claims_=gw_oauth("table", magic_current_url(), "expense_claims", "sum_data","");
     
     $gwauthenticate_expense_claims_json=json_decode($gwauthenticate_expense_claims_, true);
     
     if($gwauthenticate_expense_claims_json["response"]=="ok")
     {    
      $clean_expense_claims_where_str="";
  
      if($expense_claims_wherestr!='')
      {
        $clean_expense_claims_where_str="Where ".$expense_claims_wherestr;
      }

      return get_expense_claims("sum($expense_claims_sumcol) as return_result", " ".$clean_expense_claims_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_expense_claims_;


      }else{
     
     	echo $gwauthenticate_expense_claims_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expense_claims_)."");
        


     }    
    }
    
    //======== sum  expense_claims data function   
    
    
    //Start drop  expense_claims Data ===============
    
    function drop_expense_claims($where_str)
    {
     
     $gwauthenticate_expense_claims_=gw_oauth("table", magic_current_url(), "expense_claims", "drop_data","");
     
     $gwauthenticate_expense_claims_json=json_decode($gwauthenticate_expense_claims_, true);
     
     if($gwauthenticate_expense_claims_json["response"]=="ok")
     {    
    	return magic_sql_delete("expense_claims", $where_str);

		//echo $gwauthenticate_expense_claims_;

      }else{
     
     	echo $gwauthenticate_expense_claims_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expense_claims_)."");
		

     }
    }
    //End drop  expense_claims Data ===============    
    
    
   

    
 	//Start Add job_groups Data ===============
 	function add_job_groups($job_groups_arr_)
    {
     $gw_job_groups_cols=array();
     
     foreach($job_groups_arr_ as $job_groups_arr_gw => $job_groups_arr_gw_val)
     {
     
     	$gw_job_groups_cols[]=$job_groups_arr_gw;
        
     }
     
     $gw_job_groups_cols_str=implode(",", $gw_job_groups_cols);
     
     $gwauthenticate_job_groups_=gw_oauth("table", magic_current_url(), "job_groups", "insert",$gw_job_groups_cols_str);
     
     $gwauthenticate_job_groups_json=json_decode($gwauthenticate_job_groups_, true);
     
     if($gwauthenticate_job_groups_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("job_groups", $job_groups_arr_);
     
     	//echo $gwauthenticate_job_groups_;

     }else{
     
     	echo $gwauthenticate_job_groups_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_job_groups_)."");

     }
     
    }
    
       function initialize_job_groups()
        {
        
         global $job_groups_uptoken;
             
         $gwauthenticate_job_groups_=gw_oauth("table", magic_current_url(), "job_groups", "select","");

         $gwauthenticate_job_groups_json=json_decode($gwauthenticate_job_groups_, true);
         	
          //echo $gwauthenticate_job_groups_;

         if($gwauthenticate_job_groups_json["response"]=="ok")
         {
         
         	return get_job_groups("*", "WHERE primkey='$job_groups_uptoken'", "r");
         
            echo $gwauthenticate_job_groups_;

         }else{

         	echo $gwauthenticate_job_groups_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_job_groups_)."");
         
         }
        }   
    //End Add job_groups Data ===============
                
    //Start Update job_groups Data ===============
    
 	function update_job_groups($job_groups_arr_, $where_str)
    {
         $gw_job_groups_cols=array();
     
     foreach($job_groups_arr_ as $job_groups_arr_gw => $job_groups_arr_gw_val)
     {
     
     	$gw_job_groups_cols[]=$job_groups_arr_gw;
        
     }
     
     $gw_job_groups_cols_str=implode(",", $gw_job_groups_cols);
     
     $gwauthenticate_job_groups_=gw_oauth("table", magic_current_url(), "job_groups", "update",$gw_job_groups_cols_str);
     
     $gwauthenticate_job_groups_json=json_decode($gwauthenticate_job_groups_, true);
     
     if($gwauthenticate_job_groups_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("job_groups", $job_groups_arr_, $where_str);

       // echo $gwauthenticate_job_groups_;
        
        exit;

     }else{

        echo $gwauthenticate_job_groups_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_job_groups_)."");


      }
    
    }
 	
    
    //End Update job_groups Data ===============

    //Start get  job_groups Data ===============
    
    function get_job_groups($colstr, $where_str, $type)
    {
          
     $gwauthenticate_job_groups_=gw_oauth("table", magic_current_url(), "job_groups", "select","");
     
     $gwauthenticate_job_groups_json=json_decode($gwauthenticate_job_groups_, true);
     
     if($gwauthenticate_job_groups_json["response"]=="ok")
     {
    	return mosyflex_sel("job_groups", $colstr, $where_str, $type);

        //echo $gwauthenticate_job_groups_;

	  }else{
     
     	echo $gwauthenticate_job_groups_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_job_groups_)."");


     }    
    }
    //End get  job_groups Data ===============
    
    
    //======== qjob_groups_data qsingle query function
    
    function qjob_groups_data($qjob_group_id_key)
    {
          
     $gwauthenticate_job_groups_=gw_oauth("table", magic_current_url(), "job_groups", "qdata","");
     
     $gwauthenticate_job_groups_json=json_decode($gwauthenticate_job_groups_, true);
     
     if($gwauthenticate_job_groups_json["response"]=="ok")
     {    
    	return get_job_groups("*", "WHERE job_group_id='$qjob_group_id_key'", "r");

		//echo $gwauthenticate_job_groups_;

      }else{
     
     	echo $gwauthenticate_job_groups_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_job_groups_)."");


     }  
    }
   
    //======== qjob_groups_data qsingle query function
    
    
     //======== job_groups data to array
    
    function job_groups_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_job_groups_=gw_oauth("table", magic_current_url(), "job_groups", "data_array","");
     
     $gwauthenticate_job_groups_json=json_decode($gwauthenticate_job_groups_, true);
     
     if($gwauthenticate_job_groups_json["response"]=="ok")
     {  
     	$append_job_groups_arr=array();
    
    	$array_job_groups_q=get_job_groups($colstr, $where_str, "l");
        while($array_job_groups_res=mysqli_fetch_array($array_job_groups_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_job_groups_arr[]=$array_job_groups_res[$tbl_col];
            }
          }else{
          	          
               $append_job_groups_arr[]=$array_job_groups_res;

          }
        }
        
        return $append_job_groups_arr;

		//echo $gwauthenticate_job_groups_;

      }else{
     
     	echo $gwauthenticate_job_groups_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_job_groups_)."");


     }  
    }
   
    //======== qjob_groups_data qsingle query function   
        
    //======== qjob_groups_ddata qsingle query function    
    function qjob_groups_ddata($job_group_id_col, $qjob_group_id_key)
    {
     
     $gwauthenticate_job_groups_=gw_oauth("table", magic_current_url(), "job_groups", "qddata","");
     
     $gwauthenticate_job_groups_json=json_decode($gwauthenticate_job_groups_, true);
     
     if($gwauthenticate_job_groups_json["response"]=="ok")
     {    
    	return get_job_groups("*", "WHERE $job_group_id_col='$qjob_group_id_key'", "r");

		//echo $gwauthenticate_job_groups_;

     }else{
     
     	echo $gwauthenticate_job_groups_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_job_groups_)."");


     }   
    }
    //======== qjob_groups_ddata qsingle query function

    //======== count job_groups data function
    
    function count_job_groups($job_groups_wherestr)
    {
     
     $gwauthenticate_job_groups_=gw_oauth("table", magic_current_url(), "job_groups", "count_data","");
     
     $gwauthenticate_job_groups_json=json_decode($gwauthenticate_job_groups_, true);
     
     if($gwauthenticate_job_groups_json["response"]=="ok")
     {    
      $clean_job_groups_where_str="";
  
      if($job_groups_wherestr!='')
      {
        $clean_job_groups_where_str="Where ".$job_groups_wherestr;
      }

      return get_job_groups("count(*) as return_result", " ".$clean_job_groups_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_job_groups_;

      }else{
     
     	echo $gwauthenticate_job_groups_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_job_groups_)."");


     }    
    }
    //======== count job_groups data function

    //======== sum  job_groups data function
    
    function sum_job_groups($job_groups_sumcol, $job_groups_wherestr)
    {
     
     $gwauthenticate_job_groups_=gw_oauth("table", magic_current_url(), "job_groups", "sum_data","");
     
     $gwauthenticate_job_groups_json=json_decode($gwauthenticate_job_groups_, true);
     
     if($gwauthenticate_job_groups_json["response"]=="ok")
     {    
      $clean_job_groups_where_str="";
  
      if($job_groups_wherestr!='')
      {
        $clean_job_groups_where_str="Where ".$job_groups_wherestr;
      }

      return get_job_groups("sum($job_groups_sumcol) as return_result", " ".$clean_job_groups_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_job_groups_;


      }else{
     
     	echo $gwauthenticate_job_groups_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_job_groups_)."");
        


     }    
    }
    
    //======== sum  job_groups data function   
    
    
    //Start drop  job_groups Data ===============
    
    function drop_job_groups($where_str)
    {
     
     $gwauthenticate_job_groups_=gw_oauth("table", magic_current_url(), "job_groups", "drop_data","");
     
     $gwauthenticate_job_groups_json=json_decode($gwauthenticate_job_groups_, true);
     
     if($gwauthenticate_job_groups_json["response"]=="ok")
     {    
    	return magic_sql_delete("job_groups", $where_str);

		//echo $gwauthenticate_job_groups_;

      }else{
     
     	echo $gwauthenticate_job_groups_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_job_groups_)."");
		

     }
    }
    //End drop  job_groups Data ===============    
    
    
   

    
 	//Start Add leave_entitlement Data ===============
 	function add_leave_entitlement($leave_entitlement_arr_)
    {
     $gw_leave_entitlement_cols=array();
     
     foreach($leave_entitlement_arr_ as $leave_entitlement_arr_gw => $leave_entitlement_arr_gw_val)
     {
     
     	$gw_leave_entitlement_cols[]=$leave_entitlement_arr_gw;
        
     }
     
     $gw_leave_entitlement_cols_str=implode(",", $gw_leave_entitlement_cols);
     
     $gwauthenticate_leave_entitlement_=gw_oauth("table", magic_current_url(), "leave_entitlement", "insert",$gw_leave_entitlement_cols_str);
     
     $gwauthenticate_leave_entitlement_json=json_decode($gwauthenticate_leave_entitlement_, true);
     
     if($gwauthenticate_leave_entitlement_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("leave_entitlement", $leave_entitlement_arr_);
     
     	//echo $gwauthenticate_leave_entitlement_;

     }else{
     
     	echo $gwauthenticate_leave_entitlement_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_leave_entitlement_)."");

     }
     
    }
    
       function initialize_leave_entitlement()
        {
        
         global $leave_entitlement_uptoken;
             
         $gwauthenticate_leave_entitlement_=gw_oauth("table", magic_current_url(), "leave_entitlement", "select","");

         $gwauthenticate_leave_entitlement_json=json_decode($gwauthenticate_leave_entitlement_, true);
         	
          //echo $gwauthenticate_leave_entitlement_;

         if($gwauthenticate_leave_entitlement_json["response"]=="ok")
         {
         
         	return get_leave_entitlement("*", "WHERE primkey='$leave_entitlement_uptoken'", "r");
         
            echo $gwauthenticate_leave_entitlement_;

         }else{

         	echo $gwauthenticate_leave_entitlement_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_leave_entitlement_)."");
         
         }
        }   
    //End Add leave_entitlement Data ===============
                
    //Start Update leave_entitlement Data ===============
    
 	function update_leave_entitlement($leave_entitlement_arr_, $where_str)
    {
         $gw_leave_entitlement_cols=array();
     
     foreach($leave_entitlement_arr_ as $leave_entitlement_arr_gw => $leave_entitlement_arr_gw_val)
     {
     
     	$gw_leave_entitlement_cols[]=$leave_entitlement_arr_gw;
        
     }
     
     $gw_leave_entitlement_cols_str=implode(",", $gw_leave_entitlement_cols);
     
     $gwauthenticate_leave_entitlement_=gw_oauth("table", magic_current_url(), "leave_entitlement", "update",$gw_leave_entitlement_cols_str);
     
     $gwauthenticate_leave_entitlement_json=json_decode($gwauthenticate_leave_entitlement_, true);
     
     if($gwauthenticate_leave_entitlement_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("leave_entitlement", $leave_entitlement_arr_, $where_str);

       // echo $gwauthenticate_leave_entitlement_;
        
        exit;

     }else{

        echo $gwauthenticate_leave_entitlement_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_leave_entitlement_)."");


      }
    
    }
 	
    
    //End Update leave_entitlement Data ===============

    //Start get  leave_entitlement Data ===============
    
    function get_leave_entitlement($colstr, $where_str, $type)
    {
          
     $gwauthenticate_leave_entitlement_=gw_oauth("table", magic_current_url(), "leave_entitlement", "select","");
     
     $gwauthenticate_leave_entitlement_json=json_decode($gwauthenticate_leave_entitlement_, true);
     
     if($gwauthenticate_leave_entitlement_json["response"]=="ok")
     {
    	return mosyflex_sel("leave_entitlement", $colstr, $where_str, $type);

        //echo $gwauthenticate_leave_entitlement_;

	  }else{
     
     	echo $gwauthenticate_leave_entitlement_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_leave_entitlement_)."");


     }    
    }
    //End get  leave_entitlement Data ===============
    
    
    //======== qleave_entitlement_data qsingle query function
    
    function qleave_entitlement_data($qleave_cart_id_key)
    {
          
     $gwauthenticate_leave_entitlement_=gw_oauth("table", magic_current_url(), "leave_entitlement", "qdata","");
     
     $gwauthenticate_leave_entitlement_json=json_decode($gwauthenticate_leave_entitlement_, true);
     
     if($gwauthenticate_leave_entitlement_json["response"]=="ok")
     {    
    	return get_leave_entitlement("*", "WHERE leave_cart_id='$qleave_cart_id_key'", "r");

		//echo $gwauthenticate_leave_entitlement_;

      }else{
     
     	echo $gwauthenticate_leave_entitlement_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_leave_entitlement_)."");


     }  
    }
   
    //======== qleave_entitlement_data qsingle query function
    
    
     //======== leave_entitlement data to array
    
    function leave_entitlement_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_leave_entitlement_=gw_oauth("table", magic_current_url(), "leave_entitlement", "data_array","");
     
     $gwauthenticate_leave_entitlement_json=json_decode($gwauthenticate_leave_entitlement_, true);
     
     if($gwauthenticate_leave_entitlement_json["response"]=="ok")
     {  
     	$append_leave_entitlement_arr=array();
    
    	$array_leave_entitlement_q=get_leave_entitlement($colstr, $where_str, "l");
        while($array_leave_entitlement_res=mysqli_fetch_array($array_leave_entitlement_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_leave_entitlement_arr[]=$array_leave_entitlement_res[$tbl_col];
            }
          }else{
          	          
               $append_leave_entitlement_arr[]=$array_leave_entitlement_res;

          }
        }
        
        return $append_leave_entitlement_arr;

		//echo $gwauthenticate_leave_entitlement_;

      }else{
     
     	echo $gwauthenticate_leave_entitlement_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_leave_entitlement_)."");


     }  
    }
   
    //======== qleave_entitlement_data qsingle query function   
        
    //======== qleave_entitlement_ddata qsingle query function    
    function qleave_entitlement_ddata($leave_cart_id_col, $qleave_cart_id_key)
    {
     
     $gwauthenticate_leave_entitlement_=gw_oauth("table", magic_current_url(), "leave_entitlement", "qddata","");
     
     $gwauthenticate_leave_entitlement_json=json_decode($gwauthenticate_leave_entitlement_, true);
     
     if($gwauthenticate_leave_entitlement_json["response"]=="ok")
     {    
    	return get_leave_entitlement("*", "WHERE $leave_cart_id_col='$qleave_cart_id_key'", "r");

		//echo $gwauthenticate_leave_entitlement_;

     }else{
     
     	echo $gwauthenticate_leave_entitlement_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_leave_entitlement_)."");


     }   
    }
    //======== qleave_entitlement_ddata qsingle query function

    //======== count leave_entitlement data function
    
    function count_leave_entitlement($leave_entitlement_wherestr)
    {
     
     $gwauthenticate_leave_entitlement_=gw_oauth("table", magic_current_url(), "leave_entitlement", "count_data","");
     
     $gwauthenticate_leave_entitlement_json=json_decode($gwauthenticate_leave_entitlement_, true);
     
     if($gwauthenticate_leave_entitlement_json["response"]=="ok")
     {    
      $clean_leave_entitlement_where_str="";
  
      if($leave_entitlement_wherestr!='')
      {
        $clean_leave_entitlement_where_str="Where ".$leave_entitlement_wherestr;
      }

      return get_leave_entitlement("count(*) as return_result", " ".$clean_leave_entitlement_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_leave_entitlement_;

      }else{
     
     	echo $gwauthenticate_leave_entitlement_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_leave_entitlement_)."");


     }    
    }
    //======== count leave_entitlement data function

    //======== sum  leave_entitlement data function
    
    function sum_leave_entitlement($leave_entitlement_sumcol, $leave_entitlement_wherestr)
    {
     
     $gwauthenticate_leave_entitlement_=gw_oauth("table", magic_current_url(), "leave_entitlement", "sum_data","");
     
     $gwauthenticate_leave_entitlement_json=json_decode($gwauthenticate_leave_entitlement_, true);
     
     if($gwauthenticate_leave_entitlement_json["response"]=="ok")
     {    
      $clean_leave_entitlement_where_str="";
  
      if($leave_entitlement_wherestr!='')
      {
        $clean_leave_entitlement_where_str="Where ".$leave_entitlement_wherestr;
      }

      return get_leave_entitlement("sum($leave_entitlement_sumcol) as return_result", " ".$clean_leave_entitlement_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_leave_entitlement_;


      }else{
     
     	echo $gwauthenticate_leave_entitlement_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_leave_entitlement_)."");
        


     }    
    }
    
    //======== sum  leave_entitlement data function   
    
    
    //Start drop  leave_entitlement Data ===============
    
    function drop_leave_entitlement($where_str)
    {
     
     $gwauthenticate_leave_entitlement_=gw_oauth("table", magic_current_url(), "leave_entitlement", "drop_data","");
     
     $gwauthenticate_leave_entitlement_json=json_decode($gwauthenticate_leave_entitlement_, true);
     
     if($gwauthenticate_leave_entitlement_json["response"]=="ok")
     {    
    	return magic_sql_delete("leave_entitlement", $where_str);

		//echo $gwauthenticate_leave_entitlement_;

      }else{
     
     	echo $gwauthenticate_leave_entitlement_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_leave_entitlement_)."");
		

     }
    }
    //End drop  leave_entitlement Data ===============    
    
    
   

    
 	//Start Add loan_repayment Data ===============
 	function add_loan_repayment($loan_repayment_arr_)
    {
     $gw_loan_repayment_cols=array();
     
     foreach($loan_repayment_arr_ as $loan_repayment_arr_gw => $loan_repayment_arr_gw_val)
     {
     
     	$gw_loan_repayment_cols[]=$loan_repayment_arr_gw;
        
     }
     
     $gw_loan_repayment_cols_str=implode(",", $gw_loan_repayment_cols);
     
     $gwauthenticate_loan_repayment_=gw_oauth("table", magic_current_url(), "loan_repayment", "insert",$gw_loan_repayment_cols_str);
     
     $gwauthenticate_loan_repayment_json=json_decode($gwauthenticate_loan_repayment_, true);
     
     if($gwauthenticate_loan_repayment_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("loan_repayment", $loan_repayment_arr_);
     
     	//echo $gwauthenticate_loan_repayment_;

     }else{
     
     	echo $gwauthenticate_loan_repayment_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_loan_repayment_)."");

     }
     
    }
    
       function initialize_loan_repayment()
        {
        
         global $loan_repayment_uptoken;
             
         $gwauthenticate_loan_repayment_=gw_oauth("table", magic_current_url(), "loan_repayment", "select","");

         $gwauthenticate_loan_repayment_json=json_decode($gwauthenticate_loan_repayment_, true);
         	
          //echo $gwauthenticate_loan_repayment_;

         if($gwauthenticate_loan_repayment_json["response"]=="ok")
         {
         
         	return get_loan_repayment("*", "WHERE primkey='$loan_repayment_uptoken'", "r");
         
            echo $gwauthenticate_loan_repayment_;

         }else{

         	echo $gwauthenticate_loan_repayment_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_loan_repayment_)."");
         
         }
        }   
    //End Add loan_repayment Data ===============
                
    //Start Update loan_repayment Data ===============
    
 	function update_loan_repayment($loan_repayment_arr_, $where_str)
    {
         $gw_loan_repayment_cols=array();
     
     foreach($loan_repayment_arr_ as $loan_repayment_arr_gw => $loan_repayment_arr_gw_val)
     {
     
     	$gw_loan_repayment_cols[]=$loan_repayment_arr_gw;
        
     }
     
     $gw_loan_repayment_cols_str=implode(",", $gw_loan_repayment_cols);
     
     $gwauthenticate_loan_repayment_=gw_oauth("table", magic_current_url(), "loan_repayment", "update",$gw_loan_repayment_cols_str);
     
     $gwauthenticate_loan_repayment_json=json_decode($gwauthenticate_loan_repayment_, true);
     
     if($gwauthenticate_loan_repayment_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("loan_repayment", $loan_repayment_arr_, $where_str);

       // echo $gwauthenticate_loan_repayment_;
        
        exit;

     }else{

        echo $gwauthenticate_loan_repayment_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_loan_repayment_)."");


      }
    
    }
 	
    
    //End Update loan_repayment Data ===============

    //Start get  loan_repayment Data ===============
    
    function get_loan_repayment($colstr, $where_str, $type)
    {
          
     $gwauthenticate_loan_repayment_=gw_oauth("table", magic_current_url(), "loan_repayment", "select","");
     
     $gwauthenticate_loan_repayment_json=json_decode($gwauthenticate_loan_repayment_, true);
     
     if($gwauthenticate_loan_repayment_json["response"]=="ok")
     {
    	return mosyflex_sel("loan_repayment", $colstr, $where_str, $type);

        //echo $gwauthenticate_loan_repayment_;

	  }else{
     
     	echo $gwauthenticate_loan_repayment_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_loan_repayment_)."");


     }    
    }
    //End get  loan_repayment Data ===============
    
    
    //======== qloan_repayment_data qsingle query function
    
    function qloan_repayment_data($qpayment_id_key)
    {
          
     $gwauthenticate_loan_repayment_=gw_oauth("table", magic_current_url(), "loan_repayment", "qdata","");
     
     $gwauthenticate_loan_repayment_json=json_decode($gwauthenticate_loan_repayment_, true);
     
     if($gwauthenticate_loan_repayment_json["response"]=="ok")
     {    
    	return get_loan_repayment("*", "WHERE payment_id='$qpayment_id_key'", "r");

		//echo $gwauthenticate_loan_repayment_;

      }else{
     
     	echo $gwauthenticate_loan_repayment_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_loan_repayment_)."");


     }  
    }
   
    //======== qloan_repayment_data qsingle query function
    
    
     //======== loan_repayment data to array
    
    function loan_repayment_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_loan_repayment_=gw_oauth("table", magic_current_url(), "loan_repayment", "data_array","");
     
     $gwauthenticate_loan_repayment_json=json_decode($gwauthenticate_loan_repayment_, true);
     
     if($gwauthenticate_loan_repayment_json["response"]=="ok")
     {  
     	$append_loan_repayment_arr=array();
    
    	$array_loan_repayment_q=get_loan_repayment($colstr, $where_str, "l");
        while($array_loan_repayment_res=mysqli_fetch_array($array_loan_repayment_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_loan_repayment_arr[]=$array_loan_repayment_res[$tbl_col];
            }
          }else{
          	          
               $append_loan_repayment_arr[]=$array_loan_repayment_res;

          }
        }
        
        return $append_loan_repayment_arr;

		//echo $gwauthenticate_loan_repayment_;

      }else{
     
     	echo $gwauthenticate_loan_repayment_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_loan_repayment_)."");


     }  
    }
   
    //======== qloan_repayment_data qsingle query function   
        
    //======== qloan_repayment_ddata qsingle query function    
    function qloan_repayment_ddata($payment_id_col, $qpayment_id_key)
    {
     
     $gwauthenticate_loan_repayment_=gw_oauth("table", magic_current_url(), "loan_repayment", "qddata","");
     
     $gwauthenticate_loan_repayment_json=json_decode($gwauthenticate_loan_repayment_, true);
     
     if($gwauthenticate_loan_repayment_json["response"]=="ok")
     {    
    	return get_loan_repayment("*", "WHERE $payment_id_col='$qpayment_id_key'", "r");

		//echo $gwauthenticate_loan_repayment_;

     }else{
     
     	echo $gwauthenticate_loan_repayment_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_loan_repayment_)."");


     }   
    }
    //======== qloan_repayment_ddata qsingle query function

    //======== count loan_repayment data function
    
    function count_loan_repayment($loan_repayment_wherestr)
    {
     
     $gwauthenticate_loan_repayment_=gw_oauth("table", magic_current_url(), "loan_repayment", "count_data","");
     
     $gwauthenticate_loan_repayment_json=json_decode($gwauthenticate_loan_repayment_, true);
     
     if($gwauthenticate_loan_repayment_json["response"]=="ok")
     {    
      $clean_loan_repayment_where_str="";
  
      if($loan_repayment_wherestr!='')
      {
        $clean_loan_repayment_where_str="Where ".$loan_repayment_wherestr;
      }

      return get_loan_repayment("count(*) as return_result", " ".$clean_loan_repayment_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_loan_repayment_;

      }else{
     
     	echo $gwauthenticate_loan_repayment_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_loan_repayment_)."");


     }    
    }
    //======== count loan_repayment data function

    //======== sum  loan_repayment data function
    
    function sum_loan_repayment($loan_repayment_sumcol, $loan_repayment_wherestr)
    {
     
     $gwauthenticate_loan_repayment_=gw_oauth("table", magic_current_url(), "loan_repayment", "sum_data","");
     
     $gwauthenticate_loan_repayment_json=json_decode($gwauthenticate_loan_repayment_, true);
     
     if($gwauthenticate_loan_repayment_json["response"]=="ok")
     {    
      $clean_loan_repayment_where_str="";
  
      if($loan_repayment_wherestr!='')
      {
        $clean_loan_repayment_where_str="Where ".$loan_repayment_wherestr;
      }

      return get_loan_repayment("sum($loan_repayment_sumcol) as return_result", " ".$clean_loan_repayment_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_loan_repayment_;


      }else{
     
     	echo $gwauthenticate_loan_repayment_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_loan_repayment_)."");
        


     }    
    }
    
    //======== sum  loan_repayment data function   
    
    
    //Start drop  loan_repayment Data ===============
    
    function drop_loan_repayment($where_str)
    {
     
     $gwauthenticate_loan_repayment_=gw_oauth("table", magic_current_url(), "loan_repayment", "drop_data","");
     
     $gwauthenticate_loan_repayment_json=json_decode($gwauthenticate_loan_repayment_, true);
     
     if($gwauthenticate_loan_repayment_json["response"]=="ok")
     {    
    	return magic_sql_delete("loan_repayment", $where_str);

		//echo $gwauthenticate_loan_repayment_;

      }else{
     
     	echo $gwauthenticate_loan_repayment_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_loan_repayment_)."");
		

     }
    }
    //End drop  loan_repayment Data ===============    
    
    
   

    
 	//Start Add mosy_sql_roll_back Data ===============
 	function add_mosy_sql_roll_back($mosy_sql_roll_back_arr_)
    {
     $gw_mosy_sql_roll_back_cols=array();
     
     foreach($mosy_sql_roll_back_arr_ as $mosy_sql_roll_back_arr_gw => $mosy_sql_roll_back_arr_gw_val)
     {
     
     	$gw_mosy_sql_roll_back_cols[]=$mosy_sql_roll_back_arr_gw;
        
     }
     
     $gw_mosy_sql_roll_back_cols_str=implode(",", $gw_mosy_sql_roll_back_cols);
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "insert",$gw_mosy_sql_roll_back_cols_str);
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("mosy_sql_roll_back", $mosy_sql_roll_back_arr_);
     
     	//echo $gwauthenticate_mosy_sql_roll_back_;

     }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");

     }
     
    }
    
       function initialize_mosy_sql_roll_back()
        {
        
         global $mosy_sql_roll_back_uptoken;
             
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "select","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         
         	return get_mosy_sql_roll_back("*", "WHERE primkey='$mosy_sql_roll_back_uptoken'", "r");
         
            echo $gwauthenticate_mosy_sql_roll_back_;

         }else{

         	echo $gwauthenticate_mosy_sql_roll_back_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
         
         }
        }   
    //End Add mosy_sql_roll_back Data ===============
                
    //Start Update mosy_sql_roll_back Data ===============
    
 	function update_mosy_sql_roll_back($mosy_sql_roll_back_arr_, $where_str)
    {
         $gw_mosy_sql_roll_back_cols=array();
     
     foreach($mosy_sql_roll_back_arr_ as $mosy_sql_roll_back_arr_gw => $mosy_sql_roll_back_arr_gw_val)
     {
     
     	$gw_mosy_sql_roll_back_cols[]=$mosy_sql_roll_back_arr_gw;
        
     }
     
     $gw_mosy_sql_roll_back_cols_str=implode(",", $gw_mosy_sql_roll_back_cols);
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "update",$gw_mosy_sql_roll_back_cols_str);
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("mosy_sql_roll_back", $mosy_sql_roll_back_arr_, $where_str);

       // echo $gwauthenticate_mosy_sql_roll_back_;
        
        exit;

     }else{

        echo $gwauthenticate_mosy_sql_roll_back_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


      }
    
    }
 	
    
    //End Update mosy_sql_roll_back Data ===============

    //Start get  mosy_sql_roll_back Data ===============
    
    function get_mosy_sql_roll_back($colstr, $where_str, $type)
    {
          
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "select","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {
    	return mosyflex_sel("mosy_sql_roll_back", $colstr, $where_str, $type);

        //echo $gwauthenticate_mosy_sql_roll_back_;

	  }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }    
    }
    //End get  mosy_sql_roll_back Data ===============
    
    
    //======== qmosy_sql_roll_back_data qsingle query function
    
    function qmosy_sql_roll_back_data($qroll_bk_key_key)
    {
          
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "qdata","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
    	return get_mosy_sql_roll_back("*", "WHERE roll_bk_key='$qroll_bk_key_key'", "r");

		//echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }  
    }
   
    //======== qmosy_sql_roll_back_data qsingle query function
    
    
     //======== mosy_sql_roll_back data to array
    
    function mosy_sql_roll_back_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "data_array","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {  
     	$append_mosy_sql_roll_back_arr=array();
    
    	$array_mosy_sql_roll_back_q=get_mosy_sql_roll_back($colstr, $where_str, "l");
        while($array_mosy_sql_roll_back_res=mysqli_fetch_array($array_mosy_sql_roll_back_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_mosy_sql_roll_back_arr[]=$array_mosy_sql_roll_back_res[$tbl_col];
            }
          }else{
          	          
               $append_mosy_sql_roll_back_arr[]=$array_mosy_sql_roll_back_res;

          }
        }
        
        return $append_mosy_sql_roll_back_arr;

		//echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }  
    }
   
    //======== qmosy_sql_roll_back_data qsingle query function   
        
    //======== qmosy_sql_roll_back_ddata qsingle query function    
    function qmosy_sql_roll_back_ddata($roll_bk_key_col, $qroll_bk_key_key)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "qddata","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
    	return get_mosy_sql_roll_back("*", "WHERE $roll_bk_key_col='$qroll_bk_key_key'", "r");

		//echo $gwauthenticate_mosy_sql_roll_back_;

     }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }   
    }
    //======== qmosy_sql_roll_back_ddata qsingle query function

    //======== count mosy_sql_roll_back data function
    
    function count_mosy_sql_roll_back($mosy_sql_roll_back_wherestr)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "count_data","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
      $clean_mosy_sql_roll_back_where_str="";
  
      if($mosy_sql_roll_back_wherestr!='')
      {
        $clean_mosy_sql_roll_back_where_str="Where ".$mosy_sql_roll_back_wherestr;
      }

      return get_mosy_sql_roll_back("count(*) as return_result", " ".$clean_mosy_sql_roll_back_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");


     }    
    }
    //======== count mosy_sql_roll_back data function

    //======== sum  mosy_sql_roll_back data function
    
    function sum_mosy_sql_roll_back($mosy_sql_roll_back_sumcol, $mosy_sql_roll_back_wherestr)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "sum_data","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
      $clean_mosy_sql_roll_back_where_str="";
  
      if($mosy_sql_roll_back_wherestr!='')
      {
        $clean_mosy_sql_roll_back_where_str="Where ".$mosy_sql_roll_back_wherestr;
      }

      return get_mosy_sql_roll_back("sum($mosy_sql_roll_back_sumcol) as return_result", " ".$clean_mosy_sql_roll_back_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_mosy_sql_roll_back_;


      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
        


     }    
    }
    
    //======== sum  mosy_sql_roll_back data function   
    
    
    //Start drop  mosy_sql_roll_back Data ===============
    
    function drop_mosy_sql_roll_back($where_str)
    {
     
     $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "drop_data","");
     
     $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
     
     if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
     {    
    	return magic_sql_delete("mosy_sql_roll_back", $where_str);

		//echo $gwauthenticate_mosy_sql_roll_back_;

      }else{
     
     	echo $gwauthenticate_mosy_sql_roll_back_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
		

     }
    }
    //End drop  mosy_sql_roll_back Data ===============    
    
    
   

    
 	//Start Add payroll_list Data ===============
 	function add_payroll_list($payroll_list_arr_)
    {
     $gw_payroll_list_cols=array();
     
     foreach($payroll_list_arr_ as $payroll_list_arr_gw => $payroll_list_arr_gw_val)
     {
     
     	$gw_payroll_list_cols[]=$payroll_list_arr_gw;
        
     }
     
     $gw_payroll_list_cols_str=implode(",", $gw_payroll_list_cols);
     
     $gwauthenticate_payroll_list_=gw_oauth("table", magic_current_url(), "payroll_list", "insert",$gw_payroll_list_cols_str);
     
     $gwauthenticate_payroll_list_json=json_decode($gwauthenticate_payroll_list_, true);
     
     if($gwauthenticate_payroll_list_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("payroll_list", $payroll_list_arr_);
     
     	//echo $gwauthenticate_payroll_list_;

     }else{
     
     	echo $gwauthenticate_payroll_list_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_payroll_list_)."");

     }
     
    }
    
       function initialize_payroll_list()
        {
        
         global $payroll_list_uptoken;
             
         $gwauthenticate_payroll_list_=gw_oauth("table", magic_current_url(), "payroll_list", "select","");

         $gwauthenticate_payroll_list_json=json_decode($gwauthenticate_payroll_list_, true);
         	
          //echo $gwauthenticate_payroll_list_;

         if($gwauthenticate_payroll_list_json["response"]=="ok")
         {
         
         	return get_payroll_list("*", "WHERE primkey='$payroll_list_uptoken'", "r");
         
            echo $gwauthenticate_payroll_list_;

         }else{

         	echo $gwauthenticate_payroll_list_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_payroll_list_)."");
         
         }
        }   
    //End Add payroll_list Data ===============
                
    //Start Update payroll_list Data ===============
    
 	function update_payroll_list($payroll_list_arr_, $where_str)
    {
         $gw_payroll_list_cols=array();
     
     foreach($payroll_list_arr_ as $payroll_list_arr_gw => $payroll_list_arr_gw_val)
     {
     
     	$gw_payroll_list_cols[]=$payroll_list_arr_gw;
        
     }
     
     $gw_payroll_list_cols_str=implode(",", $gw_payroll_list_cols);
     
     $gwauthenticate_payroll_list_=gw_oauth("table", magic_current_url(), "payroll_list", "update",$gw_payroll_list_cols_str);
     
     $gwauthenticate_payroll_list_json=json_decode($gwauthenticate_payroll_list_, true);
     
     if($gwauthenticate_payroll_list_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("payroll_list", $payroll_list_arr_, $where_str);

       // echo $gwauthenticate_payroll_list_;
        
        exit;

     }else{

        echo $gwauthenticate_payroll_list_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_payroll_list_)."");


      }
    
    }
 	
    
    //End Update payroll_list Data ===============

    //Start get  payroll_list Data ===============
    
    function get_payroll_list($colstr, $where_str, $type)
    {
          
     $gwauthenticate_payroll_list_=gw_oauth("table", magic_current_url(), "payroll_list", "select","");
     
     $gwauthenticate_payroll_list_json=json_decode($gwauthenticate_payroll_list_, true);
     
     if($gwauthenticate_payroll_list_json["response"]=="ok")
     {
    	return mosyflex_sel("payroll_list", $colstr, $where_str, $type);

        //echo $gwauthenticate_payroll_list_;

	  }else{
     
     	echo $gwauthenticate_payroll_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_payroll_list_)."");


     }    
    }
    //End get  payroll_list Data ===============
    
    
    //======== qpayroll_list_data qsingle query function
    
    function qpayroll_list_data($qpayroll_id_key)
    {
          
     $gwauthenticate_payroll_list_=gw_oauth("table", magic_current_url(), "payroll_list", "qdata","");
     
     $gwauthenticate_payroll_list_json=json_decode($gwauthenticate_payroll_list_, true);
     
     if($gwauthenticate_payroll_list_json["response"]=="ok")
     {    
    	return get_payroll_list("*", "WHERE payroll_id='$qpayroll_id_key'", "r");

		//echo $gwauthenticate_payroll_list_;

      }else{
     
     	echo $gwauthenticate_payroll_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_payroll_list_)."");


     }  
    }
   
    //======== qpayroll_list_data qsingle query function
    
    
     //======== payroll_list data to array
    
    function payroll_list_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_payroll_list_=gw_oauth("table", magic_current_url(), "payroll_list", "data_array","");
     
     $gwauthenticate_payroll_list_json=json_decode($gwauthenticate_payroll_list_, true);
     
     if($gwauthenticate_payroll_list_json["response"]=="ok")
     {  
     	$append_payroll_list_arr=array();
    
    	$array_payroll_list_q=get_payroll_list($colstr, $where_str, "l");
        while($array_payroll_list_res=mysqli_fetch_array($array_payroll_list_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_payroll_list_arr[]=$array_payroll_list_res[$tbl_col];
            }
          }else{
          	          
               $append_payroll_list_arr[]=$array_payroll_list_res;

          }
        }
        
        return $append_payroll_list_arr;

		//echo $gwauthenticate_payroll_list_;

      }else{
     
     	echo $gwauthenticate_payroll_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_payroll_list_)."");


     }  
    }
   
    //======== qpayroll_list_data qsingle query function   
        
    //======== qpayroll_list_ddata qsingle query function    
    function qpayroll_list_ddata($payroll_id_col, $qpayroll_id_key)
    {
     
     $gwauthenticate_payroll_list_=gw_oauth("table", magic_current_url(), "payroll_list", "qddata","");
     
     $gwauthenticate_payroll_list_json=json_decode($gwauthenticate_payroll_list_, true);
     
     if($gwauthenticate_payroll_list_json["response"]=="ok")
     {    
    	return get_payroll_list("*", "WHERE $payroll_id_col='$qpayroll_id_key'", "r");

		//echo $gwauthenticate_payroll_list_;

     }else{
     
     	echo $gwauthenticate_payroll_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_payroll_list_)."");


     }   
    }
    //======== qpayroll_list_ddata qsingle query function

    //======== count payroll_list data function
    
    function count_payroll_list($payroll_list_wherestr)
    {
     
     $gwauthenticate_payroll_list_=gw_oauth("table", magic_current_url(), "payroll_list", "count_data","");
     
     $gwauthenticate_payroll_list_json=json_decode($gwauthenticate_payroll_list_, true);
     
     if($gwauthenticate_payroll_list_json["response"]=="ok")
     {    
      $clean_payroll_list_where_str="";
  
      if($payroll_list_wherestr!='')
      {
        $clean_payroll_list_where_str="Where ".$payroll_list_wherestr;
      }

      return get_payroll_list("count(*) as return_result", " ".$clean_payroll_list_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_payroll_list_;

      }else{
     
     	echo $gwauthenticate_payroll_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_payroll_list_)."");


     }    
    }
    //======== count payroll_list data function

    //======== sum  payroll_list data function
    
    function sum_payroll_list($payroll_list_sumcol, $payroll_list_wherestr)
    {
     
     $gwauthenticate_payroll_list_=gw_oauth("table", magic_current_url(), "payroll_list", "sum_data","");
     
     $gwauthenticate_payroll_list_json=json_decode($gwauthenticate_payroll_list_, true);
     
     if($gwauthenticate_payroll_list_json["response"]=="ok")
     {    
      $clean_payroll_list_where_str="";
  
      if($payroll_list_wherestr!='')
      {
        $clean_payroll_list_where_str="Where ".$payroll_list_wherestr;
      }

      return get_payroll_list("sum($payroll_list_sumcol) as return_result", " ".$clean_payroll_list_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_payroll_list_;


      }else{
     
     	echo $gwauthenticate_payroll_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_payroll_list_)."");
        


     }    
    }
    
    //======== sum  payroll_list data function   
    
    
    //Start drop  payroll_list Data ===============
    
    function drop_payroll_list($where_str)
    {
     
     $gwauthenticate_payroll_list_=gw_oauth("table", magic_current_url(), "payroll_list", "drop_data","");
     
     $gwauthenticate_payroll_list_json=json_decode($gwauthenticate_payroll_list_, true);
     
     if($gwauthenticate_payroll_list_json["response"]=="ok")
     {    
    	return magic_sql_delete("payroll_list", $where_str);

		//echo $gwauthenticate_payroll_list_;

      }else{
     
     	echo $gwauthenticate_payroll_list_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_payroll_list_)."");
		

     }
    }
    //End drop  payroll_list Data ===============    
    
    
   

    
 	//Start Add prl_allowances Data ===============
 	function add_prl_allowances($prl_allowances_arr_)
    {
     $gw_prl_allowances_cols=array();
     
     foreach($prl_allowances_arr_ as $prl_allowances_arr_gw => $prl_allowances_arr_gw_val)
     {
     
     	$gw_prl_allowances_cols[]=$prl_allowances_arr_gw;
        
     }
     
     $gw_prl_allowances_cols_str=implode(",", $gw_prl_allowances_cols);
     
     $gwauthenticate_prl_allowances_=gw_oauth("table", magic_current_url(), "prl_allowances", "insert",$gw_prl_allowances_cols_str);
     
     $gwauthenticate_prl_allowances_json=json_decode($gwauthenticate_prl_allowances_, true);
     
     if($gwauthenticate_prl_allowances_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("prl_allowances", $prl_allowances_arr_);
     
     	//echo $gwauthenticate_prl_allowances_;

     }else{
     
     	echo $gwauthenticate_prl_allowances_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_prl_allowances_)."");

     }
     
    }
    
       function initialize_prl_allowances()
        {
        
         global $prl_allowances_uptoken;
             
         $gwauthenticate_prl_allowances_=gw_oauth("table", magic_current_url(), "prl_allowances", "select","");

         $gwauthenticate_prl_allowances_json=json_decode($gwauthenticate_prl_allowances_, true);
         	
          //echo $gwauthenticate_prl_allowances_;

         if($gwauthenticate_prl_allowances_json["response"]=="ok")
         {
         
         	return get_prl_allowances("*", "WHERE primkey='$prl_allowances_uptoken'", "r");
         
            echo $gwauthenticate_prl_allowances_;

         }else{

         	echo $gwauthenticate_prl_allowances_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_prl_allowances_)."");
         
         }
        }   
    //End Add prl_allowances Data ===============
                
    //Start Update prl_allowances Data ===============
    
 	function update_prl_allowances($prl_allowances_arr_, $where_str)
    {
         $gw_prl_allowances_cols=array();
     
     foreach($prl_allowances_arr_ as $prl_allowances_arr_gw => $prl_allowances_arr_gw_val)
     {
     
     	$gw_prl_allowances_cols[]=$prl_allowances_arr_gw;
        
     }
     
     $gw_prl_allowances_cols_str=implode(",", $gw_prl_allowances_cols);
     
     $gwauthenticate_prl_allowances_=gw_oauth("table", magic_current_url(), "prl_allowances", "update",$gw_prl_allowances_cols_str);
     
     $gwauthenticate_prl_allowances_json=json_decode($gwauthenticate_prl_allowances_, true);
     
     if($gwauthenticate_prl_allowances_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("prl_allowances", $prl_allowances_arr_, $where_str);

       // echo $gwauthenticate_prl_allowances_;
        
        exit;

     }else{

        echo $gwauthenticate_prl_allowances_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_prl_allowances_)."");


      }
    
    }
 	
    
    //End Update prl_allowances Data ===============

    //Start get  prl_allowances Data ===============
    
    function get_prl_allowances($colstr, $where_str, $type)
    {
          
     $gwauthenticate_prl_allowances_=gw_oauth("table", magic_current_url(), "prl_allowances", "select","");
     
     $gwauthenticate_prl_allowances_json=json_decode($gwauthenticate_prl_allowances_, true);
     
     if($gwauthenticate_prl_allowances_json["response"]=="ok")
     {
    	return mosyflex_sel("prl_allowances", $colstr, $where_str, $type);

        //echo $gwauthenticate_prl_allowances_;

	  }else{
     
     	echo $gwauthenticate_prl_allowances_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_prl_allowances_)."");


     }    
    }
    //End get  prl_allowances Data ===============
    
    
    //======== qprl_allowances_data qsingle query function
    
    function qprl_allowances_data($qallowance_id_key)
    {
          
     $gwauthenticate_prl_allowances_=gw_oauth("table", magic_current_url(), "prl_allowances", "qdata","");
     
     $gwauthenticate_prl_allowances_json=json_decode($gwauthenticate_prl_allowances_, true);
     
     if($gwauthenticate_prl_allowances_json["response"]=="ok")
     {    
    	return get_prl_allowances("*", "WHERE allowance_id='$qallowance_id_key'", "r");

		//echo $gwauthenticate_prl_allowances_;

      }else{
     
     	echo $gwauthenticate_prl_allowances_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_prl_allowances_)."");


     }  
    }
   
    //======== qprl_allowances_data qsingle query function
    
    
     //======== prl_allowances data to array
    
    function prl_allowances_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_prl_allowances_=gw_oauth("table", magic_current_url(), "prl_allowances", "data_array","");
     
     $gwauthenticate_prl_allowances_json=json_decode($gwauthenticate_prl_allowances_, true);
     
     if($gwauthenticate_prl_allowances_json["response"]=="ok")
     {  
     	$append_prl_allowances_arr=array();
    
    	$array_prl_allowances_q=get_prl_allowances($colstr, $where_str, "l");
        while($array_prl_allowances_res=mysqli_fetch_array($array_prl_allowances_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_prl_allowances_arr[]=$array_prl_allowances_res[$tbl_col];
            }
          }else{
          	          
               $append_prl_allowances_arr[]=$array_prl_allowances_res;

          }
        }
        
        return $append_prl_allowances_arr;

		//echo $gwauthenticate_prl_allowances_;

      }else{
     
     	echo $gwauthenticate_prl_allowances_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_prl_allowances_)."");


     }  
    }
   
    //======== qprl_allowances_data qsingle query function   
        
    //======== qprl_allowances_ddata qsingle query function    
    function qprl_allowances_ddata($allowance_id_col, $qallowance_id_key)
    {
     
     $gwauthenticate_prl_allowances_=gw_oauth("table", magic_current_url(), "prl_allowances", "qddata","");
     
     $gwauthenticate_prl_allowances_json=json_decode($gwauthenticate_prl_allowances_, true);
     
     if($gwauthenticate_prl_allowances_json["response"]=="ok")
     {    
    	return get_prl_allowances("*", "WHERE $allowance_id_col='$qallowance_id_key'", "r");

		//echo $gwauthenticate_prl_allowances_;

     }else{
     
     	echo $gwauthenticate_prl_allowances_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_prl_allowances_)."");


     }   
    }
    //======== qprl_allowances_ddata qsingle query function

    //======== count prl_allowances data function
    
    function count_prl_allowances($prl_allowances_wherestr)
    {
     
     $gwauthenticate_prl_allowances_=gw_oauth("table", magic_current_url(), "prl_allowances", "count_data","");
     
     $gwauthenticate_prl_allowances_json=json_decode($gwauthenticate_prl_allowances_, true);
     
     if($gwauthenticate_prl_allowances_json["response"]=="ok")
     {    
      $clean_prl_allowances_where_str="";
  
      if($prl_allowances_wherestr!='')
      {
        $clean_prl_allowances_where_str="Where ".$prl_allowances_wherestr;
      }

      return get_prl_allowances("count(*) as return_result", " ".$clean_prl_allowances_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_prl_allowances_;

      }else{
     
     	echo $gwauthenticate_prl_allowances_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_prl_allowances_)."");


     }    
    }
    //======== count prl_allowances data function

    //======== sum  prl_allowances data function
    
    function sum_prl_allowances($prl_allowances_sumcol, $prl_allowances_wherestr)
    {
     
     $gwauthenticate_prl_allowances_=gw_oauth("table", magic_current_url(), "prl_allowances", "sum_data","");
     
     $gwauthenticate_prl_allowances_json=json_decode($gwauthenticate_prl_allowances_, true);
     
     if($gwauthenticate_prl_allowances_json["response"]=="ok")
     {    
      $clean_prl_allowances_where_str="";
  
      if($prl_allowances_wherestr!='')
      {
        $clean_prl_allowances_where_str="Where ".$prl_allowances_wherestr;
      }

      return get_prl_allowances("sum($prl_allowances_sumcol) as return_result", " ".$clean_prl_allowances_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_prl_allowances_;


      }else{
     
     	echo $gwauthenticate_prl_allowances_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_prl_allowances_)."");
        


     }    
    }
    
    //======== sum  prl_allowances data function   
    
    
    //Start drop  prl_allowances Data ===============
    
    function drop_prl_allowances($where_str)
    {
     
     $gwauthenticate_prl_allowances_=gw_oauth("table", magic_current_url(), "prl_allowances", "drop_data","");
     
     $gwauthenticate_prl_allowances_json=json_decode($gwauthenticate_prl_allowances_, true);
     
     if($gwauthenticate_prl_allowances_json["response"]=="ok")
     {    
    	return magic_sql_delete("prl_allowances", $where_str);

		//echo $gwauthenticate_prl_allowances_;

      }else{
     
     	echo $gwauthenticate_prl_allowances_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_prl_allowances_)."");
		

     }
    }
    //End drop  prl_allowances Data ===============    
    
    
   

    
 	//Start Add subcriptions Data ===============
 	function add_subcriptions($subcriptions_arr_)
    {
     $gw_subcriptions_cols=array();
     
     foreach($subcriptions_arr_ as $subcriptions_arr_gw => $subcriptions_arr_gw_val)
     {
     
     	$gw_subcriptions_cols[]=$subcriptions_arr_gw;
        
     }
     
     $gw_subcriptions_cols_str=implode(",", $gw_subcriptions_cols);
     
     $gwauthenticate_subcriptions_=gw_oauth("table", magic_current_url(), "subcriptions", "insert",$gw_subcriptions_cols_str);
     
     $gwauthenticate_subcriptions_json=json_decode($gwauthenticate_subcriptions_, true);
     
     if($gwauthenticate_subcriptions_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("subcriptions", $subcriptions_arr_);
     
     	//echo $gwauthenticate_subcriptions_;

     }else{
     
     	echo $gwauthenticate_subcriptions_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_subcriptions_)."");

     }
     
    }
    
       function initialize_subcriptions()
        {
        
         global $subcriptions_uptoken;
             
         $gwauthenticate_subcriptions_=gw_oauth("table", magic_current_url(), "subcriptions", "select","");

         $gwauthenticate_subcriptions_json=json_decode($gwauthenticate_subcriptions_, true);
         	
          //echo $gwauthenticate_subcriptions_;

         if($gwauthenticate_subcriptions_json["response"]=="ok")
         {
         
         	return get_subcriptions("*", "WHERE primkey='$subcriptions_uptoken'", "r");
         
            echo $gwauthenticate_subcriptions_;

         }else{

         	echo $gwauthenticate_subcriptions_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_subcriptions_)."");
         
         }
        }   
    //End Add subcriptions Data ===============
                
    //Start Update subcriptions Data ===============
    
 	function update_subcriptions($subcriptions_arr_, $where_str)
    {
         $gw_subcriptions_cols=array();
     
     foreach($subcriptions_arr_ as $subcriptions_arr_gw => $subcriptions_arr_gw_val)
     {
     
     	$gw_subcriptions_cols[]=$subcriptions_arr_gw;
        
     }
     
     $gw_subcriptions_cols_str=implode(",", $gw_subcriptions_cols);
     
     $gwauthenticate_subcriptions_=gw_oauth("table", magic_current_url(), "subcriptions", "update",$gw_subcriptions_cols_str);
     
     $gwauthenticate_subcriptions_json=json_decode($gwauthenticate_subcriptions_, true);
     
     if($gwauthenticate_subcriptions_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("subcriptions", $subcriptions_arr_, $where_str);

       // echo $gwauthenticate_subcriptions_;
        
        exit;

     }else{

        echo $gwauthenticate_subcriptions_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_subcriptions_)."");


      }
    
    }
 	
    
    //End Update subcriptions Data ===============

    //Start get  subcriptions Data ===============
    
    function get_subcriptions($colstr, $where_str, $type)
    {
          
     $gwauthenticate_subcriptions_=gw_oauth("table", magic_current_url(), "subcriptions", "select","");
     
     $gwauthenticate_subcriptions_json=json_decode($gwauthenticate_subcriptions_, true);
     
     if($gwauthenticate_subcriptions_json["response"]=="ok")
     {
    	return mosyflex_sel("subcriptions", $colstr, $where_str, $type);

        //echo $gwauthenticate_subcriptions_;

	  }else{
     
     	echo $gwauthenticate_subcriptions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_subcriptions_)."");


     }    
    }
    //End get  subcriptions Data ===============
    
    
    //======== qsubcriptions_data qsingle query function
    
    function qsubcriptions_data($qsubcription_id_key)
    {
          
     $gwauthenticate_subcriptions_=gw_oauth("table", magic_current_url(), "subcriptions", "qdata","");
     
     $gwauthenticate_subcriptions_json=json_decode($gwauthenticate_subcriptions_, true);
     
     if($gwauthenticate_subcriptions_json["response"]=="ok")
     {    
    	return get_subcriptions("*", "WHERE subcription_id='$qsubcription_id_key'", "r");

		//echo $gwauthenticate_subcriptions_;

      }else{
     
     	echo $gwauthenticate_subcriptions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_subcriptions_)."");


     }  
    }
   
    //======== qsubcriptions_data qsingle query function
    
    
     //======== subcriptions data to array
    
    function subcriptions_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_subcriptions_=gw_oauth("table", magic_current_url(), "subcriptions", "data_array","");
     
     $gwauthenticate_subcriptions_json=json_decode($gwauthenticate_subcriptions_, true);
     
     if($gwauthenticate_subcriptions_json["response"]=="ok")
     {  
     	$append_subcriptions_arr=array();
    
    	$array_subcriptions_q=get_subcriptions($colstr, $where_str, "l");
        while($array_subcriptions_res=mysqli_fetch_array($array_subcriptions_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_subcriptions_arr[]=$array_subcriptions_res[$tbl_col];
            }
          }else{
          	          
               $append_subcriptions_arr[]=$array_subcriptions_res;

          }
        }
        
        return $append_subcriptions_arr;

		//echo $gwauthenticate_subcriptions_;

      }else{
     
     	echo $gwauthenticate_subcriptions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_subcriptions_)."");


     }  
    }
   
    //======== qsubcriptions_data qsingle query function   
        
    //======== qsubcriptions_ddata qsingle query function    
    function qsubcriptions_ddata($subcription_id_col, $qsubcription_id_key)
    {
     
     $gwauthenticate_subcriptions_=gw_oauth("table", magic_current_url(), "subcriptions", "qddata","");
     
     $gwauthenticate_subcriptions_json=json_decode($gwauthenticate_subcriptions_, true);
     
     if($gwauthenticate_subcriptions_json["response"]=="ok")
     {    
    	return get_subcriptions("*", "WHERE $subcription_id_col='$qsubcription_id_key'", "r");

		//echo $gwauthenticate_subcriptions_;

     }else{
     
     	echo $gwauthenticate_subcriptions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_subcriptions_)."");


     }   
    }
    //======== qsubcriptions_ddata qsingle query function

    //======== count subcriptions data function
    
    function count_subcriptions($subcriptions_wherestr)
    {
     
     $gwauthenticate_subcriptions_=gw_oauth("table", magic_current_url(), "subcriptions", "count_data","");
     
     $gwauthenticate_subcriptions_json=json_decode($gwauthenticate_subcriptions_, true);
     
     if($gwauthenticate_subcriptions_json["response"]=="ok")
     {    
      $clean_subcriptions_where_str="";
  
      if($subcriptions_wherestr!='')
      {
        $clean_subcriptions_where_str="Where ".$subcriptions_wherestr;
      }

      return get_subcriptions("count(*) as return_result", " ".$clean_subcriptions_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_subcriptions_;

      }else{
     
     	echo $gwauthenticate_subcriptions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_subcriptions_)."");


     }    
    }
    //======== count subcriptions data function

    //======== sum  subcriptions data function
    
    function sum_subcriptions($subcriptions_sumcol, $subcriptions_wherestr)
    {
     
     $gwauthenticate_subcriptions_=gw_oauth("table", magic_current_url(), "subcriptions", "sum_data","");
     
     $gwauthenticate_subcriptions_json=json_decode($gwauthenticate_subcriptions_, true);
     
     if($gwauthenticate_subcriptions_json["response"]=="ok")
     {    
      $clean_subcriptions_where_str="";
  
      if($subcriptions_wherestr!='')
      {
        $clean_subcriptions_where_str="Where ".$subcriptions_wherestr;
      }

      return get_subcriptions("sum($subcriptions_sumcol) as return_result", " ".$clean_subcriptions_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_subcriptions_;


      }else{
     
     	echo $gwauthenticate_subcriptions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_subcriptions_)."");
        


     }    
    }
    
    //======== sum  subcriptions data function   
    
    
    //Start drop  subcriptions Data ===============
    
    function drop_subcriptions($where_str)
    {
     
     $gwauthenticate_subcriptions_=gw_oauth("table", magic_current_url(), "subcriptions", "drop_data","");
     
     $gwauthenticate_subcriptions_json=json_decode($gwauthenticate_subcriptions_, true);
     
     if($gwauthenticate_subcriptions_json["response"]=="ok")
     {    
    	return magic_sql_delete("subcriptions", $where_str);

		//echo $gwauthenticate_subcriptions_;

      }else{
     
     	echo $gwauthenticate_subcriptions_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_subcriptions_)."");
		

     }
    }
    //End drop  subcriptions Data ===============    
    
    
   

    
 	//Start Add system_admins Data ===============
 	function add_system_admins($system_admins_arr_)
    {
     $gw_system_admins_cols=array();
     
     foreach($system_admins_arr_ as $system_admins_arr_gw => $system_admins_arr_gw_val)
     {
     
     	$gw_system_admins_cols[]=$system_admins_arr_gw;
        
     }
     
     $gw_system_admins_cols_str=implode(",", $gw_system_admins_cols);
     
     $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "insert",$gw_system_admins_cols_str);
     
     $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
     
     if($gwauthenticate_system_admins_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("system_admins", $system_admins_arr_);
     
     	//echo $gwauthenticate_system_admins_;

     }else{
     
     	echo $gwauthenticate_system_admins_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_admins_)."");

     }
     
    }
    
       function initialize_system_admins()
        {
        
         global $system_admins_uptoken;
             
         $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "select","");

         $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
         	
          //echo $gwauthenticate_system_admins_;

         if($gwauthenticate_system_admins_json["response"]=="ok")
         {
         
         	return get_system_admins("*", "WHERE primkey='$system_admins_uptoken'", "r");
         
            echo $gwauthenticate_system_admins_;

         }else{

         	echo $gwauthenticate_system_admins_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_admins_)."");
         
         }
        }   
    //End Add system_admins Data ===============
                
    //Start Update system_admins Data ===============
    
 	function update_system_admins($system_admins_arr_, $where_str)
    {
         $gw_system_admins_cols=array();
     
     foreach($system_admins_arr_ as $system_admins_arr_gw => $system_admins_arr_gw_val)
     {
     
     	$gw_system_admins_cols[]=$system_admins_arr_gw;
        
     }
     
     $gw_system_admins_cols_str=implode(",", $gw_system_admins_cols);
     
     $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "update",$gw_system_admins_cols_str);
     
     $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
     
     if($gwauthenticate_system_admins_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("system_admins", $system_admins_arr_, $where_str);

       // echo $gwauthenticate_system_admins_;
        
        exit;

     }else{

        echo $gwauthenticate_system_admins_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_admins_)."");


      }
    
    }
 	
    
    //End Update system_admins Data ===============

    //Start get  system_admins Data ===============
    
    function get_system_admins($colstr, $where_str, $type)
    {
          
     $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "select","");
     
     $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
     
     if($gwauthenticate_system_admins_json["response"]=="ok")
     {
    	return mosyflex_sel("system_admins", $colstr, $where_str, $type);

        //echo $gwauthenticate_system_admins_;

	  }else{
     
     	echo $gwauthenticate_system_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_admins_)."");


     }    
    }
    //End get  system_admins Data ===============
    
    
    //======== qsystem_admins_data qsingle query function
    
    function qsystem_admins_data($quser_id_key)
    {
          
     $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "qdata","");
     
     $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
     
     if($gwauthenticate_system_admins_json["response"]=="ok")
     {    
    	return get_system_admins("*", "WHERE user_id='$quser_id_key'", "r");

		//echo $gwauthenticate_system_admins_;

      }else{
     
     	echo $gwauthenticate_system_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_admins_)."");


     }  
    }
   
    //======== qsystem_admins_data qsingle query function
    
    
     //======== system_admins data to array
    
    function system_admins_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "data_array","");
     
     $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
     
     if($gwauthenticate_system_admins_json["response"]=="ok")
     {  
     	$append_system_admins_arr=array();
    
    	$array_system_admins_q=get_system_admins($colstr, $where_str, "l");
        while($array_system_admins_res=mysqli_fetch_array($array_system_admins_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_system_admins_arr[]=$array_system_admins_res[$tbl_col];
            }
          }else{
          	          
               $append_system_admins_arr[]=$array_system_admins_res;

          }
        }
        
        return $append_system_admins_arr;

		//echo $gwauthenticate_system_admins_;

      }else{
     
     	echo $gwauthenticate_system_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_admins_)."");


     }  
    }
   
    //======== qsystem_admins_data qsingle query function   
        
    //======== qsystem_admins_ddata qsingle query function    
    function qsystem_admins_ddata($user_id_col, $quser_id_key)
    {
     
     $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "qddata","");
     
     $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
     
     if($gwauthenticate_system_admins_json["response"]=="ok")
     {    
    	return get_system_admins("*", "WHERE $user_id_col='$quser_id_key'", "r");

		//echo $gwauthenticate_system_admins_;

     }else{
     
     	echo $gwauthenticate_system_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_admins_)."");


     }   
    }
    //======== qsystem_admins_ddata qsingle query function

    //======== count system_admins data function
    
    function count_system_admins($system_admins_wherestr)
    {
     
     $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "count_data","");
     
     $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
     
     if($gwauthenticate_system_admins_json["response"]=="ok")
     {    
      $clean_system_admins_where_str="";
  
      if($system_admins_wherestr!='')
      {
        $clean_system_admins_where_str="Where ".$system_admins_wherestr;
      }

      return get_system_admins("count(*) as return_result", " ".$clean_system_admins_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_system_admins_;

      }else{
     
     	echo $gwauthenticate_system_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_admins_)."");


     }    
    }
    //======== count system_admins data function

    //======== sum  system_admins data function
    
    function sum_system_admins($system_admins_sumcol, $system_admins_wherestr)
    {
     
     $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "sum_data","");
     
     $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
     
     if($gwauthenticate_system_admins_json["response"]=="ok")
     {    
      $clean_system_admins_where_str="";
  
      if($system_admins_wherestr!='')
      {
        $clean_system_admins_where_str="Where ".$system_admins_wherestr;
      }

      return get_system_admins("sum($system_admins_sumcol) as return_result", " ".$clean_system_admins_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_system_admins_;


      }else{
     
     	echo $gwauthenticate_system_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_admins_)."");
        


     }    
    }
    
    //======== sum  system_admins data function   
    
    
    //Start drop  system_admins Data ===============
    
    function drop_system_admins($where_str)
    {
     
     $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "drop_data","");
     
     $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
     
     if($gwauthenticate_system_admins_json["response"]=="ok")
     {    
    	return magic_sql_delete("system_admins", $where_str);

		//echo $gwauthenticate_system_admins_;

      }else{
     
     	echo $gwauthenticate_system_admins_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_admins_)."");
		

     }
    }
    //End drop  system_admins Data ===============    
    
    
            //Start Upload system_admins_user_pic Function 
            function upload_system_admins_user_pic($txt_system_admins_user_pic, $where_str){
              
                $file_name1=explode(".", basename($_FILES[$txt_system_admins_user_pic]['name']))[0];

                $file_name=str_replace(" ", "_", $file_name1);

                if (!file_exists('./img/system_admins_user_pic')) @mkdir('./img/system_admins_user_pic');

                $cur_item_photos=magic_upload_file('./img/system_admins_user_pic/', $txt_system_admins_user_pic, $file_name."_".magic_random_str(5));

                $item_photo=mmres($cur_item_photos);

                magic_compress_file($cur_item_photos, $cur_item_photos, 50);

                $system_admins_node=get_system_admins("*", "WHERE ".$where_str."", "r");

                  if (file_exists($system_admins_node["user_pic"]))
                  {

                      unlink($system_admins_node["user_pic"]);

                  }
                  if($where_str!="")
                  {
                    magic_sql_update('system_admins', '{"user_pic":"'.$cur_item_photos.'"}', $where_str);
                  } 

              return $cur_item_photos;

			}
           //End Upload system_admins_user_pic Function 

            
   

    
 	//Start Add system_files Data ===============
 	function add_system_files($system_files_arr_)
    {
     $gw_system_files_cols=array();
     
     foreach($system_files_arr_ as $system_files_arr_gw => $system_files_arr_gw_val)
     {
     
     	$gw_system_files_cols[]=$system_files_arr_gw;
        
     }
     
     $gw_system_files_cols_str=implode(",", $gw_system_files_cols);
     
     $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "insert",$gw_system_files_cols_str);
     
     $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
     
     if($gwauthenticate_system_files_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("system_files", $system_files_arr_);
     
     	//echo $gwauthenticate_system_files_;

     }else{
     
     	echo $gwauthenticate_system_files_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_files_)."");

     }
     
    }
    
       function initialize_system_files()
        {
        
         global $system_files_uptoken;
             
         $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "select","");

         $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
         	
          //echo $gwauthenticate_system_files_;

         if($gwauthenticate_system_files_json["response"]=="ok")
         {
         
         	return get_system_files("*", "WHERE primkey='$system_files_uptoken'", "r");
         
            echo $gwauthenticate_system_files_;

         }else{

         	echo $gwauthenticate_system_files_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_files_)."");
         
         }
        }   
    //End Add system_files Data ===============
                
    //Start Update system_files Data ===============
    
 	function update_system_files($system_files_arr_, $where_str)
    {
         $gw_system_files_cols=array();
     
     foreach($system_files_arr_ as $system_files_arr_gw => $system_files_arr_gw_val)
     {
     
     	$gw_system_files_cols[]=$system_files_arr_gw;
        
     }
     
     $gw_system_files_cols_str=implode(",", $gw_system_files_cols);
     
     $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "update",$gw_system_files_cols_str);
     
     $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
     
     if($gwauthenticate_system_files_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("system_files", $system_files_arr_, $where_str);

       // echo $gwauthenticate_system_files_;
        
        exit;

     }else{

        echo $gwauthenticate_system_files_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_files_)."");


      }
    
    }
 	
    
    //End Update system_files Data ===============

    //Start get  system_files Data ===============
    
    function get_system_files($colstr, $where_str, $type)
    {
          
     $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "select","");
     
     $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
     
     if($gwauthenticate_system_files_json["response"]=="ok")
     {
    	return mosyflex_sel("system_files", $colstr, $where_str, $type);

        //echo $gwauthenticate_system_files_;

	  }else{
     
     	echo $gwauthenticate_system_files_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_files_)."");


     }    
    }
    //End get  system_files Data ===============
    
    
    //======== qsystem_files_data qsingle query function
    
    function qsystem_files_data($qfile_id_key)
    {
          
     $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "qdata","");
     
     $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
     
     if($gwauthenticate_system_files_json["response"]=="ok")
     {    
    	return get_system_files("*", "WHERE file_id='$qfile_id_key'", "r");

		//echo $gwauthenticate_system_files_;

      }else{
     
     	echo $gwauthenticate_system_files_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_files_)."");


     }  
    }
   
    //======== qsystem_files_data qsingle query function
    
    
     //======== system_files data to array
    
    function system_files_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "data_array","");
     
     $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
     
     if($gwauthenticate_system_files_json["response"]=="ok")
     {  
     	$append_system_files_arr=array();
    
    	$array_system_files_q=get_system_files($colstr, $where_str, "l");
        while($array_system_files_res=mysqli_fetch_array($array_system_files_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_system_files_arr[]=$array_system_files_res[$tbl_col];
            }
          }else{
          	          
               $append_system_files_arr[]=$array_system_files_res;

          }
        }
        
        return $append_system_files_arr;

		//echo $gwauthenticate_system_files_;

      }else{
     
     	echo $gwauthenticate_system_files_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_files_)."");


     }  
    }
   
    //======== qsystem_files_data qsingle query function   
        
    //======== qsystem_files_ddata qsingle query function    
    function qsystem_files_ddata($file_id_col, $qfile_id_key)
    {
     
     $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "qddata","");
     
     $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
     
     if($gwauthenticate_system_files_json["response"]=="ok")
     {    
    	return get_system_files("*", "WHERE $file_id_col='$qfile_id_key'", "r");

		//echo $gwauthenticate_system_files_;

     }else{
     
     	echo $gwauthenticate_system_files_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_files_)."");


     }   
    }
    //======== qsystem_files_ddata qsingle query function

    //======== count system_files data function
    
    function count_system_files($system_files_wherestr)
    {
     
     $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "count_data","");
     
     $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
     
     if($gwauthenticate_system_files_json["response"]=="ok")
     {    
      $clean_system_files_where_str="";
  
      if($system_files_wherestr!='')
      {
        $clean_system_files_where_str="Where ".$system_files_wherestr;
      }

      return get_system_files("count(*) as return_result", " ".$clean_system_files_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_system_files_;

      }else{
     
     	echo $gwauthenticate_system_files_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_files_)."");


     }    
    }
    //======== count system_files data function

    //======== sum  system_files data function
    
    function sum_system_files($system_files_sumcol, $system_files_wherestr)
    {
     
     $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "sum_data","");
     
     $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
     
     if($gwauthenticate_system_files_json["response"]=="ok")
     {    
      $clean_system_files_where_str="";
  
      if($system_files_wherestr!='')
      {
        $clean_system_files_where_str="Where ".$system_files_wherestr;
      }

      return get_system_files("sum($system_files_sumcol) as return_result", " ".$clean_system_files_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_system_files_;


      }else{
     
     	echo $gwauthenticate_system_files_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_files_)."");
        


     }    
    }
    
    //======== sum  system_files data function   
    
    
    //Start drop  system_files Data ===============
    
    function drop_system_files($where_str)
    {
     
     $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "drop_data","");
     
     $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
     
     if($gwauthenticate_system_files_json["response"]=="ok")
     {    
    	return magic_sql_delete("system_files", $where_str);

		//echo $gwauthenticate_system_files_;

      }else{
     
     	echo $gwauthenticate_system_files_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_files_)."");
		

     }
    }
    //End drop  system_files Data ===============    
    
    
            //Start Upload system_files_file_url Function 
            function upload_system_files_file_url($txt_system_files_file_url, $where_str){
              
                $file_name1=explode(".", basename($_FILES[$txt_system_files_file_url]['name']))[0];

                $file_name=str_replace(" ", "_", $file_name1);

                if (!file_exists('./img/system_files_file_url')) @mkdir('./img/system_files_file_url');

                $cur_item_photos=magic_upload_file('./img/system_files_file_url/', $txt_system_files_file_url, $file_name."_".magic_random_str(5));

                $item_photo=mmres($cur_item_photos);

                magic_compress_file($cur_item_photos, $cur_item_photos, 50);

                $system_files_node=get_system_files("*", "WHERE ".$where_str."", "r");

                  if (file_exists($system_files_node["file_url"]))
                  {

                      unlink($system_files_node["file_url"]);

                  }
                  if($where_str!="")
                  {
                    magic_sql_update('system_files', '{"file_url":"'.$cur_item_photos.'"}', $where_str);
                  } 

              return $cur_item_photos;

			}
           //End Upload system_files_file_url Function 

            
   

    
 	//Start Add ux_table Data ===============
 	function add_ux_table($ux_table_arr_)
    {
     $gw_ux_table_cols=array();
     
     foreach($ux_table_arr_ as $ux_table_arr_gw => $ux_table_arr_gw_val)
     {
     
     	$gw_ux_table_cols[]=$ux_table_arr_gw;
        
     }
     
     $gw_ux_table_cols_str=implode(",", $gw_ux_table_cols);
     
     $gwauthenticate_ux_table_=gw_oauth("table", magic_current_url(), "ux_table", "insert",$gw_ux_table_cols_str);
     
     $gwauthenticate_ux_table_json=json_decode($gwauthenticate_ux_table_, true);
     
     if($gwauthenticate_ux_table_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_insert("ux_table", $ux_table_arr_);
     
     	//echo $gwauthenticate_ux_table_;

     }else{
     
     	echo $gwauthenticate_ux_table_;
          	
        //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_ux_table_)."");

     }
     
    }
    
       function initialize_ux_table()
        {
        
         global $ux_table_uptoken;
             
         $gwauthenticate_ux_table_=gw_oauth("table", magic_current_url(), "ux_table", "select","");

         $gwauthenticate_ux_table_json=json_decode($gwauthenticate_ux_table_, true);
         	
          //echo $gwauthenticate_ux_table_;

         if($gwauthenticate_ux_table_json["response"]=="ok")
         {
         
         	return get_ux_table("*", "WHERE primkey='$ux_table_uptoken'", "r");
         
            echo $gwauthenticate_ux_table_;

         }else{

         	echo $gwauthenticate_ux_table_;
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_ux_table_)."");
         
         }
        }   
    //End Add ux_table Data ===============
                
    //Start Update ux_table Data ===============
    
 	function update_ux_table($ux_table_arr_, $where_str)
    {
         $gw_ux_table_cols=array();
     
     foreach($ux_table_arr_ as $ux_table_arr_gw => $ux_table_arr_gw_val)
     {
     
     	$gw_ux_table_cols[]=$ux_table_arr_gw;
        
     }
     
     $gw_ux_table_cols_str=implode(",", $gw_ux_table_cols);
     
     $gwauthenticate_ux_table_=gw_oauth("table", magic_current_url(), "ux_table", "update",$gw_ux_table_cols_str);
     
     $gwauthenticate_ux_table_json=json_decode($gwauthenticate_ux_table_, true);
     
     if($gwauthenticate_ux_table_json["response"]=="ok")
     {
     
     	return mosy_sqlarr_update("ux_table", $ux_table_arr_, $where_str);

       // echo $gwauthenticate_ux_table_;
        
        exit;

     }else{

        echo $gwauthenticate_ux_table_;
       
     	//header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_ux_table_)."");


      }
    
    }
 	
    
    //End Update ux_table Data ===============

    //Start get  ux_table Data ===============
    
    function get_ux_table($colstr, $where_str, $type)
    {
          
     $gwauthenticate_ux_table_=gw_oauth("table", magic_current_url(), "ux_table", "select","");
     
     $gwauthenticate_ux_table_json=json_decode($gwauthenticate_ux_table_, true);
     
     if($gwauthenticate_ux_table_json["response"]=="ok")
     {
    	return mosyflex_sel("ux_table", $colstr, $where_str, $type);

        //echo $gwauthenticate_ux_table_;

	  }else{
     
     	echo $gwauthenticate_ux_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_ux_table_)."");


     }    
    }
    //End get  ux_table Data ===============
    
    
    //======== qux_table_data qsingle query function
    
    function qux_table_data($qux_id_key)
    {
          
     $gwauthenticate_ux_table_=gw_oauth("table", magic_current_url(), "ux_table", "qdata","");
     
     $gwauthenticate_ux_table_json=json_decode($gwauthenticate_ux_table_, true);
     
     if($gwauthenticate_ux_table_json["response"]=="ok")
     {    
    	return get_ux_table("*", "WHERE ux_id='$qux_id_key'", "r");

		//echo $gwauthenticate_ux_table_;

      }else{
     
     	echo $gwauthenticate_ux_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_ux_table_)."");


     }  
    }
   
    //======== qux_table_data qsingle query function
    
    
     //======== ux_table data to array
    
    function ux_table_data_array($colstr, $where_str, $column_arr)
    {
          
     $gwauthenticate_ux_table_=gw_oauth("table", magic_current_url(), "ux_table", "data_array","");
     
     $gwauthenticate_ux_table_json=json_decode($gwauthenticate_ux_table_, true);
     
     if($gwauthenticate_ux_table_json["response"]=="ok")
     {  
     	$append_ux_table_arr=array();
    
    	$array_ux_table_q=get_ux_table($colstr, $where_str, "l");
        while($array_ux_table_res=mysqli_fetch_array($array_ux_table_q))
        {
          if($column_arr!="")
          {
          	$column_arr_exp=explode(",", $column_arr);
            
            foreach($column_arr_exp as $tbl_col)
            {
				$append_ux_table_arr[]=$array_ux_table_res[$tbl_col];
            }
          }else{
          	          
               $append_ux_table_arr[]=$array_ux_table_res;

          }
        }
        
        return $append_ux_table_arr;

		//echo $gwauthenticate_ux_table_;

      }else{
     
     	echo $gwauthenticate_ux_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_ux_table_)."");


     }  
    }
   
    //======== qux_table_data qsingle query function   
        
    //======== qux_table_ddata qsingle query function    
    function qux_table_ddata($ux_id_col, $qux_id_key)
    {
     
     $gwauthenticate_ux_table_=gw_oauth("table", magic_current_url(), "ux_table", "qddata","");
     
     $gwauthenticate_ux_table_json=json_decode($gwauthenticate_ux_table_, true);
     
     if($gwauthenticate_ux_table_json["response"]=="ok")
     {    
    	return get_ux_table("*", "WHERE $ux_id_col='$qux_id_key'", "r");

		//echo $gwauthenticate_ux_table_;

     }else{
     
     	echo $gwauthenticate_ux_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_ux_table_)."");


     }   
    }
    //======== qux_table_ddata qsingle query function

    //======== count ux_table data function
    
    function count_ux_table($ux_table_wherestr)
    {
     
     $gwauthenticate_ux_table_=gw_oauth("table", magic_current_url(), "ux_table", "count_data","");
     
     $gwauthenticate_ux_table_json=json_decode($gwauthenticate_ux_table_, true);
     
     if($gwauthenticate_ux_table_json["response"]=="ok")
     {    
      $clean_ux_table_where_str="";
  
      if($ux_table_wherestr!='')
      {
        $clean_ux_table_where_str="Where ".$ux_table_wherestr;
      }

      return get_ux_table("count(*) as return_result", " ".$clean_ux_table_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_ux_table_;

      }else{
     
     	echo $gwauthenticate_ux_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_ux_table_)."");


     }    
    }
    //======== count ux_table data function

    //======== sum  ux_table data function
    
    function sum_ux_table($ux_table_sumcol, $ux_table_wherestr)
    {
     
     $gwauthenticate_ux_table_=gw_oauth("table", magic_current_url(), "ux_table", "sum_data","");
     
     $gwauthenticate_ux_table_json=json_decode($gwauthenticate_ux_table_, true);
     
     if($gwauthenticate_ux_table_json["response"]=="ok")
     {    
      $clean_ux_table_where_str="";
  
      if($ux_table_wherestr!='')
      {
        $clean_ux_table_where_str="Where ".$ux_table_wherestr;
      }

      return get_ux_table("sum($ux_table_sumcol) as return_result", " ".$clean_ux_table_where_str."", "r")["return_result"];
      
      //echo $gwauthenticate_ux_table_;


      }else{
     
     	echo $gwauthenticate_ux_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_ux_table_)."");
        


     }    
    }
    
    //======== sum  ux_table data function   
    
    
    //Start drop  ux_table Data ===============
    
    function drop_ux_table($where_str)
    {
     
     $gwauthenticate_ux_table_=gw_oauth("table", magic_current_url(), "ux_table", "drop_data","");
     
     $gwauthenticate_ux_table_json=json_decode($gwauthenticate_ux_table_, true);
     
     if($gwauthenticate_ux_table_json["response"]=="ok")
     {    
    	return magic_sql_delete("ux_table", $where_str);

		//echo $gwauthenticate_ux_table_;

      }else{
     
     	echo $gwauthenticate_ux_table_;
     
     	///header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_ux_table_)."");
		

     }
    }
    //End drop  ux_table Data ===============    
    
    
  //===============End Mosy queries-============

//============= Start Sql chart  Script =====================

function mosy_sql_rollback($tbl, $where, $type)
{
  $sql_fun="get_".$tbl;

  $curr_sql_ret_=$sql_fun("*", " where ".$where." ", "r");
  
  $json_sql_str=json_encode($curr_sql_ret_, true);
  
  //------- begin mosy_sql_roll_back_post_arr --> 
  $mosy_sql_roll_back_post_arr_=array(

  "primkey"=>"NULL",
  "roll_bk_key"=>mmres(magic_random_str(20)),
  "table_name"=>mmres($tbl),
  "where_str"=>mmres($where),
  "roll_type"=>mmres($type),
  "roll_timestamp"=>date("Y-m-d H:i:s"),
  "value_entries"=>mmres($json_sql_str)

  );
  //===-- End mosy_sql_roll_back_post_arr -->

  add_mosy_sql_roll_back($mosy_sql_roll_back_post_arr_);
  
  return $json_sql_str;
  
}


function get_mosychart_data($tbl, $colstr, $where_str, $xcol, $ycol, $groupby)
 {
   global $single_conn;
   global $single_db;
   global $buttonclr;
   
   $fun_where_str="";
   $groupby_cols="";
   
   if($where_str!='')
   {
     $fun_where_str=" WHERE ".$where_str;
   }
   
   if($groupby!='')
   {
     $groupby_cols=" GROUP BY ".$groupby;
   }
   
   if (strpos($xcol, ':') !== false) 
   {
     $extract_xcol=explode(":", $xcol);
     
     $xcol_title=$extract_xcol[2];
     $xcol_column=$extract_xcol[0];

   }
   
   if (strpos($ycol, ':') !== false) 
   {
     $extract_ycol=explode(":", $ycol);
     
     $ycol_title=$extract_ycol[2];
     $ycol_column=$extract_ycol[0];
         
   }
   
   $chart_q=mosyflex_sel($tbl, $colstr, " ".$fun_where_str." ".$groupby_cols." ", '');
	
   $data_array=array();
   
   $data_array[]=[$xcol_title, $ycol_title, '{ role: \'style\' }'];
   $i=0;
   
   while($chart_r=mysqli_fetch_array($chart_q))
   {
	$i  ;
     

     if($extract_ycol[1]=="?")
     {
       $ycol_custom_data_point=$chart_r[''.$ycol_column.''];
     }else{

       $ycol_custom_data_point1=eval(("\$yreturn = ".$extract_ycol[1].";"));
       
       $ycol_custom_data_point=$xreturn;

     }
     

     if($extract_xcol[1]=="?")
     {
           $xcol_custom_data_point=$chart_r[''.$xcol_column.''];

     }else{

       //$xcol_custom_data_point=(($extract_xcol[1]));
       $xcol_custom_data_point1=eval(("\$xreturn =".$extract_xcol[1].";"));
		$xcol_custom_data_point=$xreturn;
     }
     
     $xcol_custom_data_point_pr=$xcol_custom_data_point;
     
     if($xcol_custom_data_point=='')
     {
       $xcol_custom_data_point_pr="''";
     }
     
     $ycol_custom_data_point_pr=$ycol_custom_data_point;
     
     if($ycol_custom_data_point=='')
     {
       $ycol_custom_data_point_pr="0";
     }     
     
   	$data_array[]=[$xcol_custom_data_point_pr, $ycol_custom_data_point_pr, $buttonclr];
     
   }

   return json_encode($data_array, JSON_NUMERIC_CHECK);
 }
//============= End Sql chart  Script =====================


//============= Start   mosy flex select script =====================

function mosyflex_sel($tbl, $colstr, $where_str, $loop_or_row_l_r)
{
   global $single_conn;
   global $single_db;
   global $flex_result;
   global $datalimit;
  
  $paginate_q="";
  $paginate_state="";
  
  $pagination_token=$tbl."_mpgtkn";
  
  $loop_or_row_l_rtype=$loop_or_row_l_r;
  
  if (strpos($loop_or_row_l_r, ':') !== false)
  {
    $loop_or_row_l_r_str=explode(":", $loop_or_row_l_r);

    $pagination_token=$loop_or_row_l_r_str[1];

    $loop_or_row_l_rtype=$loop_or_row_l_r_str[0];

    $paginate_state="paginate";
    
    $pagination_sql="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$where_str."";

    $process_pagination=mysqli_query($single_conn, $pagination_sql) or die(mysqli_error($single_conn));

    $paginate_q=mosy_paginate($process_pagination, $datalimit, $pagination_token);

    $new_where_str=$where_str." LIMIT ".$paginate_q[0].", $datalimit ";

    $sql_str="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$new_where_str."";
    

  }else{
    
      $sql_str="SELECT ".$colstr."   FROM `$single_db`.`".$tbl."` ".$where_str."";

  }
   
    
  $flex_result_q=mysqli_query($single_conn, $sql_str) or die(mysqli_error($single_conn));
  
  $flex_result=$flex_result_q;

  if($loop_or_row_l_rtype=='r')
  {
    $flex_result_r=mysqli_fetch_array($flex_result_q);
    
    $flex_result=$flex_result_r;
    
  }
  
  if($paginate_state=='paginate')
  {
  	$flex_result=array($flex_result_q, $paginate_q[1], $paginate_q[0], $sql_str, $pagination_sql);  
  }
  
  return $flex_result;
  
}

function mosy_paginate($sqlstring, $reclimit, $token_name)
{

  $requested_page = isset($_GET[$token_name]) ? intval(base64_decode($_GET[$token_name])) : 1;

  $rows_count = mysqli_num_rows($sqlstring);

  $items_per_page = $reclimit;

  $page_count = ceil($rows_count / $items_per_page);
  // You can check if $requested_page is > to $page_count OR < 1,
  // and redirect to the page one.

  $first_row = ($requested_page - 1) * $items_per_page;

  $recordperpage_data=array($first_row,$page_count);

  return $recordperpage_data;
  
}
//============= End  mosy flex select script =====================

  function tonum($number_str)
  {
	if($number_str=='')
    {
      $number_str=0;
    }
  	return number_format($number_str, 0, ".", ",");
  	

  }
  
//checkblank fuction

function checkblank($value, $return_val)
{
  
  global $fun_resonse;

  if($value!='')
  {
  $fun_resonse=$value;
  }else{
    $fun_resonse=$return_val;

  }
  return $fun_resonse;

}

//get date foramrt

function ftime($time_st, $type)
{
  	global $timeresp;
    
  $timeresp=date("l, jS, M, y, @ H:i:s");

  if($time_st=="") 
  {
    $timeresp=date("l, jS, M, y, @ H:i:s");

  	if($type=="date")
    {
    $timeresp=date("l, jS, M, y");
    }
    
  }
  
  if($time_st!=""){
  
     $timeresp=date("l, jS, M, y, @ H:i:s", strtotime($time_st));

    if($type=="date")
    {
    	$timeresp=date("l, jS, M, y", strtotime($time_st));
    }
    
  }
	return $timeresp;
}

function date_time_input($time_st, $full_date_time)
{
  	global $timeresp;
    
    $date_form="Y-m-d\TH:i:s";
    
    if($full_date_time=="date")
    {
    $date_form="Y-m-d";
    }
    
    if($full_date_time=="time")
    {
    $date_form="H:i:s";
    }
    
  if($time_st==""){
  	$timeresp=date($date_form);
  }else{
   
   $timeresp=date($date_form, strtotime($time_st));

  }
	return $timeresp;
}
function daytime()
{
  global $daytime;

  $daytime='Hello';

  $fromdate=date('A');

  if($fromdate=='AM'){
 	 $daytime='Morning';
  }

  if($fromdate=='PM'){
  	$daytime='Evening';
  }

  return $daytime;
}
function time_elapsed_string($datetime, $full = false) 
{
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        "y" => "year",
        "m" => "month",
        "w" => "week",
        "d" => "day",
        "h" => "hour",
        "i" => "minute",
        "s" => "second",
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . " " . $v . ($diff->$k > 1 ? "s" : "");
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(", ", $string) . " ago" : "just now";
}

if (file_exists("./mosy_paginate.php")){
include("./mosy_paginate.php");
}

function pdf_url($current, $pdfurl)
{
  
  $filter_param=str_replace($current."", $pdfurl."", (magic_current_url()));

  if(strpos($filter_param, '?') !== false) 
  {
    $filter_param=str_replace($current."?", $pdfurl."?", (magic_current_url()));

  }

  if(strpos($filter_param, '.php?') !== false) 
  {
    $filter_param=str_replace($current.".php?", $pdfurl."?", (magic_current_url()));

  }

  return $filter_param;
  
}

function add_url_param( $key, $value, $passed_url) 
{
  $url=$passed_url;
  if($passed_url=='')
  {
    $url=magic_current_url();
  }
  
  $info = parse_url( $url );

  if(isset($info['query']))
  {
    parse_str( $info['query'], $query );
  }else{
    $query="";
  }
    return $info['scheme'] . '://' . $info['host'] . $info['path'] . '?' . http_build_query( $query ? array_merge( $query, array($key => $value ) ) : array( $key => $value ) );
}

//<--ncgh-->
?>