<?php 
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}


 $parent_path=[
'http://localhost/mosy/fernv2/',
//{{next_root_str}}
];

$active_parent_dir=date('dmyhisa');
if(isset($_SESSION['active_parent_dir'])){
 $active_parent_dir=$_SESSION['active_parent_dir'];
 ///echo $active_parent_dir;
}
$access_arr=[

    ///start access clearance array for $active_parent_dir.'indexsb.php
    $active_parent_dir.'indexsb.php'=>
      [
      'account_profiles'=>['select','{{next_indexsb.php_account_profiles}}'],
        
      'app_users'=>['qddata','select','{{next_indexsb.php_app_users}}'],
      //next_indexsb.php_access

      ],
      ///end access clearance array for $active_parent_dir.'indexsb.php

      //{{next_file_block}}

];
?>