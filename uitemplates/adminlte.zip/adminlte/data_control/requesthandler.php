<?php 
//===============Start DATA HANDLER QUERIES ===================
				
              ///========== Get server protocol
                
              if (isset($_SERVER['HTTPS']) &&
                  ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
                  isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
                  $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
                $http_protocol = 'https://';
              }
              else {
                $http_protocol = 'http://';
              }
              
              ///========== Get server protocol

              //table section account_profiles
  //************************************************* START  account_profiles OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize account_profiles edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['account_profiles_table_alert']))
              	{	
                  if(isset($account_profiles_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$account_profiles_uptoken="";

		if(isset($_GET["account_profiles_uptoken"]))
		{
		$account_profiles_uptoken=base64_decode($_GET["account_profiles_uptoken"]);
		}
        
        if(isset($_POST["account_profiles_uptoken"]))
		{
		$account_profiles_uptoken=base64_decode($_POST["account_profiles_uptoken"]);
		}
        //
        
          $account_profiles_alias_name="ACCOUNT PROFILES";

          if(isset($account_profiles_alias))
          {
             $account_profiles_alias_name=$account_profiles_alias;

          }
          
        //get single data record query with $account_profiles_uptoken
        
        ///$account_profiles_node=get_account_profiles("*", "WHERE primkey='$account_profiles_uptoken'", "r");
        
	
//************* START INSERT  account_profiles QUERY 
if(isset($_POST["account_profiles_insert_btn"])){
//------- begin account_profiles_arr_ins --> 
$account_profiles_arr_ins_=array(

"primkey"=>"NULL",
"account_id"=>magic_random_str(7),
"organization_name"=>"?",
"industry"=>"?",
"number_of_employees"=>"?",
"city"=>"?",
"town"=>"?",
"street"=>"?",
"organization_logo"=>"?",
"contact_header"=>"?",
"owner"=>"?"

);
//===-- End account_profiles_arr_ins -->


          
         $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "insert","");

         $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
         	
          //echo $gwauthenticate_account_profiles_;

         if($gwauthenticate_account_profiles_json["response"]=="ok")
         {

              $account_profiles_validated_ins_str=$account_profiles_arr_ins_;

              if(isset($account_profiles_ins_inputs))
              {
                $account_profiles_validated_ins_str=$account_profiles_ins_inputs;	
              }

              if(empty($account_profiles_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$account_profiles_alias_name." request cannot be empty. Record not added");
              }else{

                $account_profiles_return_key=add_account_profiles($account_profiles_validated_ins_str);
                
                mosy_sql_rollback("account_profiles", "primkey='$account_profiles_return_key'", "INSERT");
					
         
                if(!empty($_FILES['txt_account_profiles_organization_logo']['tmp_name']))
                {
                
                 upload_account_profiles_organization_logo('txt_account_profiles_organization_logo', "primkey='$account_profiles_return_key'");
                 
				}
                
         
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $account_profiles_return_key; 

                      } 

                    }else{ 

                                    
                $account_profiles_custom_redir1=add_url_param ("account_profiles_uptoken", base64_encode($account_profiles_return_key), "");
                $account_profiles_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$account_profiles_custom_redir1);
                $account_profiles_custom_redir3=add_url_param ("account_profiles_table_alert", "account_profiles_added",$account_profiles_custom_redir2);
                
                ///echo magic_message($account_profiles_custom_redir1." -- ".$account_profiles_custom_redir2."--".$account_profiles_custom_redir3);
                
                $account_profiles_custom_redir=$account_profiles_custom_redir3;
                
               header('location:'.$account_profiles_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_account_profiles_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_account_profiles_)."");
         
         }
      
}
//************* END  account_profiles INSERT QUERY 	
	

//************* START account_profiles  UPDATE QUERY 
if(isset($_POST["account_profiles_update_btn"])){
//------- begin account_profiles_arr_updt --> 
$account_profiles_arr_updt_=array(
"organization_name"=>"?",
"industry"=>"?",
"number_of_employees"=>"?",
"city"=>"?",
"town"=>"?",
"street"=>"?",
"organization_logo"=>"?",
"contact_header"=>"?",
"owner"=>"?"

);
//===-- End account_profiles_arr_updt -->
                     
         $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "update","");

         $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
         	
          //echo $gwauthenticate_account_profiles_;

         if($gwauthenticate_account_profiles_json["response"]=="ok")
         {
         
            $account_profiles_validated_updt_str=$account_profiles_arr_updt_;

            if(isset($account_profiles_updt_inputs))
            {
              $account_profiles_validated_updt_str=$account_profiles_updt_inputs;	
            }

            if(empty($account_profiles_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$account_profiles_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$account_profiles_key_salt=initialize_account_profiles()["account_id"];
            
              update_account_profiles($account_profiles_validated_updt_str, "primkey='$account_profiles_uptoken' and account_id='$account_profiles_key_salt'");
				
         
                if(!empty($_FILES['txt_account_profiles_organization_logo']['tmp_name']))
                {
                
                 upload_account_profiles_organization_logo('txt_account_profiles_organization_logo', "primkey='$account_profiles_uptoken'");
                 
				}

			 mosy_sql_rollback("account_profiles", "primkey='$account_profiles_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $account_profiles_uptoken; 

                    } 

                  }else{ 

                $account_profiles_custom_redir1=add_url_param ("account_profiles_uptoken", base64_encode($account_profiles_uptoken), "");
                $account_profiles_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$account_profiles_custom_redir1);
                $account_profiles_custom_redir3=add_url_param ("account_profiles_table_alert", "account_profiles_updated",$account_profiles_custom_redir2);
                
                ///echo magic_message($account_profiles_custom_redir1." -- ".$account_profiles_custom_redir2."--".$account_profiles_custom_redir3);
                
                $account_profiles_custom_redir=$account_profiles_custom_redir3;
                
               header('location:'.$account_profiles_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_account_profiles_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_account_profiles_)."");
         
         }

      

      
}
//************* END account_profiles  UPDATE QUERY 

    

          //===-====Start upload account_profiles_organization_logo 
          if(isset($_POST["btn_upload_account_profiles_organization_logo"]))
          {
         $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "upload_account_profiles_organization_logo","");

         $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
         	
          //echo $gwauthenticate_account_profiles_;

         if($gwauthenticate_account_profiles_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_account_profiles_organization_logo']['tmp_name'])){

				upload_account_profiles_organization_logo('txt_account_profiles_organization_logo', "primkey='$account_profiles_uptoken'");
                
                $account_profiles_custom_redir1=add_url_param ("account_profiles_uptoken", base64_encode($account_profiles_uptoken), "");
                $account_profiles_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$account_profiles_custom_redir1);
                $account_profiles_custom_redir3=add_url_param ("account_profiles_table_alert", "account_profiles_uploaded",$account_profiles_custom_redir2);
                
                ///echo magic_message($account_profiles_custom_redir1." -- ".$account_profiles_custom_redir2."--".$account_profiles_custom_redir3);
                
                $account_profiles_custom_redir=$account_profiles_custom_redir3;
                
               header('location:'.$account_profiles_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_account_profiles_);

          }
          }
          //===-====End upload account_profiles_organization_logo  

			//drop account_profiles_organization_logo image 
            
          if(isset($_GET["conf_deleteaccount_profiles"]))
          {
          	$account_profiles_node=initialize_account_profiles();
          	if($account_profiles_node["organization_logo"]!="")
            {
          	 unlink($account_profiles_node["organization_logo"]);
            }
          }
          
          
    
      //== Start account_profiles delete record

      if(isset($_GET["deleteaccount_profiles"]))
      {
         $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "super_delete_request","");

         $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
         	
          //echo $gwauthenticate_account_profiles_;

         if($gwauthenticate_account_profiles_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_account_profiles_btn=magic_button_link("./".$current_file_url."?account_profiles_uptoken=".$_GET["account_profiles_uptoken"]."&conf_deleteaccount_profiles&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_account_profiles_btn=magic_button_link("./".$current_file_url."?account_profiles_uptoken=".$_GET["account_profiles_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_account_profiles_btn." ".$cancel_del_account_profiles_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_account_profiles_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteaccount_profiles"]))
      {
         $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "super_delete_confirm","");

         $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
         	
          //echo $gwauthenticate_account_profiles_;

         if($gwauthenticate_account_profiles_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $account_profiles_del_key_salt=initialize_account_profiles()["account_id"];
      mosy_sql_rollback("account_profiles", "primkey='$account_profiles_uptoken'", "DELETE");
      drop_account_profiles("primkey='$account_profiles_uptoken' and account_id='$account_profiles_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_account_profiles_);

      }
      }

      //== End account_profiles delete record  
    
       ///SELECT STRING FOR account_profiles============================
              
       if(isset($_POST["qaccount_profiles_btn"])){
         $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "qaccount_profiles_btn","");

         $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
         	
          //echo $gwauthenticate_account_profiles_;

         if($gwauthenticate_account_profiles_json["response"]=="ok")
         {
            $current_account_profiles_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_account_profiles_current_url=$current_account_profiles_url_params.'?qaccount_profiles=';
            if (strpos($current_account_profiles_url_params, '?') !== false) {

                $clean_account_profiles_current_url=$current_account_profiles_url_params.'&qaccount_profiles=';

            }
            if (strpos($current_account_profiles_url_params, '?qaccount_profiles')) {

                $remove_account_profiles_old_token = substr($current_account_profiles_url_params, 0, strpos($current_account_profiles_url_params, "?qaccount_profiles"));

                $clean_account_profiles_current_url=$remove_account_profiles_old_token.'?qaccount_profiles=';

            }
            if(strpos($current_account_profiles_url_params, '&qaccount_profiles')) {

                $remove_account_profiles_old_token = substr($current_account_profiles_url_params, 0, strpos($current_account_profiles_url_params, "&qaccount_profiles"));

                $clean_account_profiles_current_url=$remove_account_profiles_old_token.'&qaccount_profiles=';

            }
        $qaccount_profiles_str=base64_encode($_POST["txt_account_profiles"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_account_profiles_current_url.($qaccount_profiles_str);
            } 

          }else{ 
             header('location:'.$clean_account_profiles_current_url.($qaccount_profiles_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_account_profiles_);

        }
        }
        $qaccount_profiles="";
		if(isset($_GET["account_profiles_mosyfilter"]) && isset($_GET["qaccount_profiles"])){
         $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "account_profiles_mosyfilter_n_query","");

         $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
         	
          //echo $gwauthenticate_account_profiles_;

         if($gwauthenticate_account_profiles_json["response"]=="ok")
         {
         $qaccount_profiles=mmres(base64_decode($_GET["qaccount_profiles"]));
         
         $gft_account_profiles_where_query="(`account_id` LIKE '%".$qaccount_profiles."%' OR  `organization_name` LIKE '%".$qaccount_profiles."%' OR  `industry` LIKE '%".$qaccount_profiles."%' OR  `number_of_employees` LIKE '%".$qaccount_profiles."%' OR  `city` LIKE '%".$qaccount_profiles."%' OR  `town` LIKE '%".$qaccount_profiles."%' OR  `street` LIKE '%".$qaccount_profiles."%' OR  `organization_logo` LIKE '%".$qaccount_profiles."%' OR  `contact_header` LIKE '%".$qaccount_profiles."%' OR  `owner` LIKE '%".$qaccount_profiles."%')";
         
         if($_GET["account_profiles_mosyfilter"]!=""){
         
         $mosyfilter_account_profiles_queries_str=(base64_decode($_GET["account_profiles_mosyfilter"]));
        
         $gft_account_profiles_where_query="(`account_id` LIKE '%".$qaccount_profiles."%' OR  `organization_name` LIKE '%".$qaccount_profiles."%' OR  `industry` LIKE '%".$qaccount_profiles."%' OR  `number_of_employees` LIKE '%".$qaccount_profiles."%' OR  `city` LIKE '%".$qaccount_profiles."%' OR  `town` LIKE '%".$qaccount_profiles."%' OR  `street` LIKE '%".$qaccount_profiles."%' OR  `organization_logo` LIKE '%".$qaccount_profiles."%' OR  `contact_header` LIKE '%".$qaccount_profiles."%' OR  `owner` LIKE '%".$qaccount_profiles."%') AND ".$mosyfilter_account_profiles_queries_str."";
         
         }
         
		 $gft_account_profiles="WHERE ".$gft_account_profiles_where_query;
         
         $gft_account_profiles_and=$gft_account_profiles_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_account_profiles_);
        }
        }elseif(isset($_GET["qaccount_profiles"])){
         $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "get_qaccount_profiles","");

         $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
         	
          //echo $gwauthenticate_account_profiles_;

         if($gwauthenticate_account_profiles_json["response"]=="ok")
         {
		 $qaccount_profiles=mmres(base64_decode($_GET["qaccount_profiles"]));
        
         $gft_account_profiles_where_query="(`account_id` LIKE '%".$qaccount_profiles."%' OR  `organization_name` LIKE '%".$qaccount_profiles."%' OR  `industry` LIKE '%".$qaccount_profiles."%' OR  `number_of_employees` LIKE '%".$qaccount_profiles."%' OR  `city` LIKE '%".$qaccount_profiles."%' OR  `town` LIKE '%".$qaccount_profiles."%' OR  `street` LIKE '%".$qaccount_profiles."%' OR  `organization_logo` LIKE '%".$qaccount_profiles."%' OR  `contact_header` LIKE '%".$qaccount_profiles."%' OR  `owner` LIKE '%".$qaccount_profiles."%')";
         
         $gft_account_profiles="WHERE ".$gft_account_profiles_where_query;
         
         $gft_account_profiles_and=$gft_account_profiles_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_account_profiles_);

        }
        }elseif(isset($_GET["account_profiles_mosyfilter"])){
         $gwauthenticate_account_profiles_=gw_oauth("table", magic_current_url(), "account_profiles", "account_profiles_mosyfilter","");

         $gwauthenticate_account_profiles_json=json_decode($gwauthenticate_account_profiles_, true);
         	
          //echo $gwauthenticate_account_profiles_;

         if($gwauthenticate_account_profiles_json["response"]=="ok")
         {
         $gft_account_profiles_where_query="";
         $gft_account_profiles="";

         if($_GET["account_profiles_mosyfilter"]!=""){
          $gft_account_profiles_where_query=(base64_decode($_GET["account_profiles_mosyfilter"]));
          $gft_account_profiles="WHERE ".$gft_account_profiles_where_query;
         }
         
         
         $gft_account_profiles_and=$gft_account_profiles_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_account_profiles_);

        }
        }else{
         $gft_account_profiles="";
         $gft_account_profiles_and="";
         $gft_account_profiles_where_query="";
        }
       
    //************************************************* END  account_profiles OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section advance_payments
  //************************************************* START  advance_payments OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize advance_payments edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['advance_payments_table_alert']))
              	{	
                  if(isset($advance_payments_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$advance_payments_uptoken="";

		if(isset($_GET["advance_payments_uptoken"]))
		{
		$advance_payments_uptoken=base64_decode($_GET["advance_payments_uptoken"]);
		}
        
        if(isset($_POST["advance_payments_uptoken"]))
		{
		$advance_payments_uptoken=base64_decode($_POST["advance_payments_uptoken"]);
		}
        //
        
          $advance_payments_alias_name="ADVANCE PAYMENTS";

          if(isset($advance_payments_alias))
          {
             $advance_payments_alias_name=$advance_payments_alias;

          }
          
        //get single data record query with $advance_payments_uptoken
        
        ///$advance_payments_node=get_advance_payments("*", "WHERE primkey='$advance_payments_uptoken'", "r");
        
	
//************* START INSERT  advance_payments QUERY 
if(isset($_POST["advance_payments_insert_btn"])){
//------- begin advance_payments_arr_ins --> 
$advance_payments_arr_ins_=array(

"primkey"=>"NULL",
"advance_key"=>magic_random_str(7),
"transaction_date"=>"?",
"amount"=>"?",
"amount_repaid"=>"?",
"balance_amt"=>"?",
"context"=>"?",
"ref_id"=>"?",
"staff_id"=>"?",
"remark"=>"?",
"installment_amount"=>"?",
"owner"=>"?",
"payment_key"=>"?"

);
//===-- End advance_payments_arr_ins -->


          
         $gwauthenticate_advance_payments_=gw_oauth("table", magic_current_url(), "advance_payments", "insert","");

         $gwauthenticate_advance_payments_json=json_decode($gwauthenticate_advance_payments_, true);
         	
          //echo $gwauthenticate_advance_payments_;

         if($gwauthenticate_advance_payments_json["response"]=="ok")
         {

              $advance_payments_validated_ins_str=$advance_payments_arr_ins_;

              if(isset($advance_payments_ins_inputs))
              {
                $advance_payments_validated_ins_str=$advance_payments_ins_inputs;	
              }

              if(empty($advance_payments_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$advance_payments_alias_name." request cannot be empty. Record not added");
              }else{

                $advance_payments_return_key=add_advance_payments($advance_payments_validated_ins_str);
                
                mosy_sql_rollback("advance_payments", "primkey='$advance_payments_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $advance_payments_return_key; 

                      } 

                    }else{ 

                                    
                $advance_payments_custom_redir1=add_url_param ("advance_payments_uptoken", base64_encode($advance_payments_return_key), "");
                $advance_payments_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$advance_payments_custom_redir1);
                $advance_payments_custom_redir3=add_url_param ("advance_payments_table_alert", "advance_payments_added",$advance_payments_custom_redir2);
                
                ///echo magic_message($advance_payments_custom_redir1." -- ".$advance_payments_custom_redir2."--".$advance_payments_custom_redir3);
                
                $advance_payments_custom_redir=$advance_payments_custom_redir3;
                
               header('location:'.$advance_payments_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_advance_payments_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_advance_payments_)."");
         
         }
      
}
//************* END  advance_payments INSERT QUERY 	
	

//************* START advance_payments  UPDATE QUERY 
if(isset($_POST["advance_payments_update_btn"])){
//------- begin advance_payments_arr_updt --> 
$advance_payments_arr_updt_=array(
"transaction_date"=>"?",
"amount"=>"?",
"amount_repaid"=>"?",
"balance_amt"=>"?",
"context"=>"?",
"ref_id"=>"?",
"staff_id"=>"?",
"remark"=>"?",
"installment_amount"=>"?",
"owner"=>"?",
"payment_key"=>"?"

);
//===-- End advance_payments_arr_updt -->
                     
         $gwauthenticate_advance_payments_=gw_oauth("table", magic_current_url(), "advance_payments", "update","");

         $gwauthenticate_advance_payments_json=json_decode($gwauthenticate_advance_payments_, true);
         	
          //echo $gwauthenticate_advance_payments_;

         if($gwauthenticate_advance_payments_json["response"]=="ok")
         {
         
            $advance_payments_validated_updt_str=$advance_payments_arr_updt_;

            if(isset($advance_payments_updt_inputs))
            {
              $advance_payments_validated_updt_str=$advance_payments_updt_inputs;	
            }

            if(empty($advance_payments_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$advance_payments_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$advance_payments_key_salt=initialize_advance_payments()["advance_key"];
            
              update_advance_payments($advance_payments_validated_updt_str, "primkey='$advance_payments_uptoken' and advance_key='$advance_payments_key_salt'");
				

			 mosy_sql_rollback("advance_payments", "primkey='$advance_payments_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $advance_payments_uptoken; 

                    } 

                  }else{ 

                $advance_payments_custom_redir1=add_url_param ("advance_payments_uptoken", base64_encode($advance_payments_uptoken), "");
                $advance_payments_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$advance_payments_custom_redir1);
                $advance_payments_custom_redir3=add_url_param ("advance_payments_table_alert", "advance_payments_updated",$advance_payments_custom_redir2);
                
                ///echo magic_message($advance_payments_custom_redir1." -- ".$advance_payments_custom_redir2."--".$advance_payments_custom_redir3);
                
                $advance_payments_custom_redir=$advance_payments_custom_redir3;
                
               header('location:'.$advance_payments_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_advance_payments_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_advance_payments_)."");
         
         }

      

      
}
//************* END advance_payments  UPDATE QUERY 

    
    
      //== Start advance_payments delete record

      if(isset($_GET["deleteadvance_payments"]))
      {
         $gwauthenticate_advance_payments_=gw_oauth("table", magic_current_url(), "advance_payments", "super_delete_request","");

         $gwauthenticate_advance_payments_json=json_decode($gwauthenticate_advance_payments_, true);
         	
          //echo $gwauthenticate_advance_payments_;

         if($gwauthenticate_advance_payments_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_advance_payments_btn=magic_button_link("./".$current_file_url."?advance_payments_uptoken=".$_GET["advance_payments_uptoken"]."&conf_deleteadvance_payments&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_advance_payments_btn=magic_button_link("./".$current_file_url."?advance_payments_uptoken=".$_GET["advance_payments_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_advance_payments_btn." ".$cancel_del_advance_payments_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_advance_payments_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteadvance_payments"]))
      {
         $gwauthenticate_advance_payments_=gw_oauth("table", magic_current_url(), "advance_payments", "super_delete_confirm","");

         $gwauthenticate_advance_payments_json=json_decode($gwauthenticate_advance_payments_, true);
         	
          //echo $gwauthenticate_advance_payments_;

         if($gwauthenticate_advance_payments_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $advance_payments_del_key_salt=initialize_advance_payments()["advance_key"];
      mosy_sql_rollback("advance_payments", "primkey='$advance_payments_uptoken'", "DELETE");
      drop_advance_payments("primkey='$advance_payments_uptoken' and advance_key='$advance_payments_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_advance_payments_);

      }
      }

      //== End advance_payments delete record  
    
       ///SELECT STRING FOR advance_payments============================
              
       if(isset($_POST["qadvance_payments_btn"])){
         $gwauthenticate_advance_payments_=gw_oauth("table", magic_current_url(), "advance_payments", "qadvance_payments_btn","");

         $gwauthenticate_advance_payments_json=json_decode($gwauthenticate_advance_payments_, true);
         	
          //echo $gwauthenticate_advance_payments_;

         if($gwauthenticate_advance_payments_json["response"]=="ok")
         {
            $current_advance_payments_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_advance_payments_current_url=$current_advance_payments_url_params.'?qadvance_payments=';
            if (strpos($current_advance_payments_url_params, '?') !== false) {

                $clean_advance_payments_current_url=$current_advance_payments_url_params.'&qadvance_payments=';

            }
            if (strpos($current_advance_payments_url_params, '?qadvance_payments')) {

                $remove_advance_payments_old_token = substr($current_advance_payments_url_params, 0, strpos($current_advance_payments_url_params, "?qadvance_payments"));

                $clean_advance_payments_current_url=$remove_advance_payments_old_token.'?qadvance_payments=';

            }
            if(strpos($current_advance_payments_url_params, '&qadvance_payments')) {

                $remove_advance_payments_old_token = substr($current_advance_payments_url_params, 0, strpos($current_advance_payments_url_params, "&qadvance_payments"));

                $clean_advance_payments_current_url=$remove_advance_payments_old_token.'&qadvance_payments=';

            }
        $qadvance_payments_str=base64_encode($_POST["txt_advance_payments"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_advance_payments_current_url.($qadvance_payments_str);
            } 

          }else{ 
             header('location:'.$clean_advance_payments_current_url.($qadvance_payments_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_advance_payments_);

        }
        }
        $qadvance_payments="";
		if(isset($_GET["advance_payments_mosyfilter"]) && isset($_GET["qadvance_payments"])){
         $gwauthenticate_advance_payments_=gw_oauth("table", magic_current_url(), "advance_payments", "advance_payments_mosyfilter_n_query","");

         $gwauthenticate_advance_payments_json=json_decode($gwauthenticate_advance_payments_, true);
         	
          //echo $gwauthenticate_advance_payments_;

         if($gwauthenticate_advance_payments_json["response"]=="ok")
         {
         $qadvance_payments=mmres(base64_decode($_GET["qadvance_payments"]));
         
         $gft_advance_payments_where_query="(`advance_key` LIKE '%".$qadvance_payments."%' OR  `transaction_date` LIKE '%".$qadvance_payments."%' OR  `amount` LIKE '%".$qadvance_payments."%' OR  `amount_repaid` LIKE '%".$qadvance_payments."%' OR  `balance_amt` LIKE '%".$qadvance_payments."%' OR  `context` LIKE '%".$qadvance_payments."%' OR  `ref_id` LIKE '%".$qadvance_payments."%' OR  `staff_id` LIKE '%".$qadvance_payments."%' OR  `remark` LIKE '%".$qadvance_payments."%' OR  `installment_amount` LIKE '%".$qadvance_payments."%' OR  `owner` LIKE '%".$qadvance_payments."%' OR  `payment_key` LIKE '%".$qadvance_payments."%')";
         
         if($_GET["advance_payments_mosyfilter"]!=""){
         
         $mosyfilter_advance_payments_queries_str=(base64_decode($_GET["advance_payments_mosyfilter"]));
        
         $gft_advance_payments_where_query="(`advance_key` LIKE '%".$qadvance_payments."%' OR  `transaction_date` LIKE '%".$qadvance_payments."%' OR  `amount` LIKE '%".$qadvance_payments."%' OR  `amount_repaid` LIKE '%".$qadvance_payments."%' OR  `balance_amt` LIKE '%".$qadvance_payments."%' OR  `context` LIKE '%".$qadvance_payments."%' OR  `ref_id` LIKE '%".$qadvance_payments."%' OR  `staff_id` LIKE '%".$qadvance_payments."%' OR  `remark` LIKE '%".$qadvance_payments."%' OR  `installment_amount` LIKE '%".$qadvance_payments."%' OR  `owner` LIKE '%".$qadvance_payments."%' OR  `payment_key` LIKE '%".$qadvance_payments."%') AND ".$mosyfilter_advance_payments_queries_str."";
         
         }
         
		 $gft_advance_payments="WHERE ".$gft_advance_payments_where_query;
         
         $gft_advance_payments_and=$gft_advance_payments_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_advance_payments_);
        }
        }elseif(isset($_GET["qadvance_payments"])){
         $gwauthenticate_advance_payments_=gw_oauth("table", magic_current_url(), "advance_payments", "get_qadvance_payments","");

         $gwauthenticate_advance_payments_json=json_decode($gwauthenticate_advance_payments_, true);
         	
          //echo $gwauthenticate_advance_payments_;

         if($gwauthenticate_advance_payments_json["response"]=="ok")
         {
		 $qadvance_payments=mmres(base64_decode($_GET["qadvance_payments"]));
        
         $gft_advance_payments_where_query="(`advance_key` LIKE '%".$qadvance_payments."%' OR  `transaction_date` LIKE '%".$qadvance_payments."%' OR  `amount` LIKE '%".$qadvance_payments."%' OR  `amount_repaid` LIKE '%".$qadvance_payments."%' OR  `balance_amt` LIKE '%".$qadvance_payments."%' OR  `context` LIKE '%".$qadvance_payments."%' OR  `ref_id` LIKE '%".$qadvance_payments."%' OR  `staff_id` LIKE '%".$qadvance_payments."%' OR  `remark` LIKE '%".$qadvance_payments."%' OR  `installment_amount` LIKE '%".$qadvance_payments."%' OR  `owner` LIKE '%".$qadvance_payments."%' OR  `payment_key` LIKE '%".$qadvance_payments."%')";
         
         $gft_advance_payments="WHERE ".$gft_advance_payments_where_query;
         
         $gft_advance_payments_and=$gft_advance_payments_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_advance_payments_);

        }
        }elseif(isset($_GET["advance_payments_mosyfilter"])){
         $gwauthenticate_advance_payments_=gw_oauth("table", magic_current_url(), "advance_payments", "advance_payments_mosyfilter","");

         $gwauthenticate_advance_payments_json=json_decode($gwauthenticate_advance_payments_, true);
         	
          //echo $gwauthenticate_advance_payments_;

         if($gwauthenticate_advance_payments_json["response"]=="ok")
         {
         $gft_advance_payments_where_query="";
         $gft_advance_payments="";

         if($_GET["advance_payments_mosyfilter"]!=""){
          $gft_advance_payments_where_query=(base64_decode($_GET["advance_payments_mosyfilter"]));
          $gft_advance_payments="WHERE ".$gft_advance_payments_where_query;
         }
         
         
         $gft_advance_payments_and=$gft_advance_payments_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_advance_payments_);

        }
        }else{
         $gft_advance_payments="";
         $gft_advance_payments_and="";
         $gft_advance_payments_where_query="";
        }
       
    //************************************************* END  advance_payments OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section allowances
  //************************************************* START  allowances OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize allowances edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['allowances_table_alert']))
              	{	
                  if(isset($allowances_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$allowances_uptoken="";

		if(isset($_GET["allowances_uptoken"]))
		{
		$allowances_uptoken=base64_decode($_GET["allowances_uptoken"]);
		}
        
        if(isset($_POST["allowances_uptoken"]))
		{
		$allowances_uptoken=base64_decode($_POST["allowances_uptoken"]);
		}
        //
        
          $allowances_alias_name="ALLOWANCES";

          if(isset($allowances_alias))
          {
             $allowances_alias_name=$allowances_alias;

          }
          
        //get single data record query with $allowances_uptoken
        
        ///$allowances_node=get_allowances("*", "WHERE primkey='$allowances_uptoken'", "r");
        
	
//************* START INSERT  allowances QUERY 
if(isset($_POST["allowances_insert_btn"])){
//------- begin allowances_arr_ins --> 
$allowances_arr_ins_=array(

"primkey"=>"NULL",
"allowance_id"=>magic_random_str(7),
"allowance_title"=>"?",
"amount"=>"?",
"staff_id"=>"?",
"remark"=>"?",
"owner"=>"?",
"active_state"=>"?"

);
//===-- End allowances_arr_ins -->


          
         $gwauthenticate_allowances_=gw_oauth("table", magic_current_url(), "allowances", "insert","");

         $gwauthenticate_allowances_json=json_decode($gwauthenticate_allowances_, true);
         	
          //echo $gwauthenticate_allowances_;

         if($gwauthenticate_allowances_json["response"]=="ok")
         {

              $allowances_validated_ins_str=$allowances_arr_ins_;

              if(isset($allowances_ins_inputs))
              {
                $allowances_validated_ins_str=$allowances_ins_inputs;	
              }

              if(empty($allowances_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$allowances_alias_name." request cannot be empty. Record not added");
              }else{

                $allowances_return_key=add_allowances($allowances_validated_ins_str);
                
                mosy_sql_rollback("allowances", "primkey='$allowances_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $allowances_return_key; 

                      } 

                    }else{ 

                                    
                $allowances_custom_redir1=add_url_param ("allowances_uptoken", base64_encode($allowances_return_key), "");
                $allowances_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$allowances_custom_redir1);
                $allowances_custom_redir3=add_url_param ("allowances_table_alert", "allowances_added",$allowances_custom_redir2);
                
                ///echo magic_message($allowances_custom_redir1." -- ".$allowances_custom_redir2."--".$allowances_custom_redir3);
                
                $allowances_custom_redir=$allowances_custom_redir3;
                
               header('location:'.$allowances_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_allowances_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_allowances_)."");
         
         }
      
}
//************* END  allowances INSERT QUERY 	
	

//************* START allowances  UPDATE QUERY 
if(isset($_POST["allowances_update_btn"])){
//------- begin allowances_arr_updt --> 
$allowances_arr_updt_=array(
"allowance_title"=>"?",
"amount"=>"?",
"staff_id"=>"?",
"remark"=>"?",
"owner"=>"?",
"active_state"=>"?"

);
//===-- End allowances_arr_updt -->
                     
         $gwauthenticate_allowances_=gw_oauth("table", magic_current_url(), "allowances", "update","");

         $gwauthenticate_allowances_json=json_decode($gwauthenticate_allowances_, true);
         	
          //echo $gwauthenticate_allowances_;

         if($gwauthenticate_allowances_json["response"]=="ok")
         {
         
            $allowances_validated_updt_str=$allowances_arr_updt_;

            if(isset($allowances_updt_inputs))
            {
              $allowances_validated_updt_str=$allowances_updt_inputs;	
            }

            if(empty($allowances_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$allowances_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$allowances_key_salt=initialize_allowances()["allowance_id"];
            
              update_allowances($allowances_validated_updt_str, "primkey='$allowances_uptoken' and allowance_id='$allowances_key_salt'");
				

			 mosy_sql_rollback("allowances", "primkey='$allowances_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $allowances_uptoken; 

                    } 

                  }else{ 

                $allowances_custom_redir1=add_url_param ("allowances_uptoken", base64_encode($allowances_uptoken), "");
                $allowances_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$allowances_custom_redir1);
                $allowances_custom_redir3=add_url_param ("allowances_table_alert", "allowances_updated",$allowances_custom_redir2);
                
                ///echo magic_message($allowances_custom_redir1." -- ".$allowances_custom_redir2."--".$allowances_custom_redir3);
                
                $allowances_custom_redir=$allowances_custom_redir3;
                
               header('location:'.$allowances_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_allowances_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_allowances_)."");
         
         }

      

      
}
//************* END allowances  UPDATE QUERY 

    
    
      //== Start allowances delete record

      if(isset($_GET["deleteallowances"]))
      {
         $gwauthenticate_allowances_=gw_oauth("table", magic_current_url(), "allowances", "super_delete_request","");

         $gwauthenticate_allowances_json=json_decode($gwauthenticate_allowances_, true);
         	
          //echo $gwauthenticate_allowances_;

         if($gwauthenticate_allowances_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_allowances_btn=magic_button_link("./".$current_file_url."?allowances_uptoken=".$_GET["allowances_uptoken"]."&conf_deleteallowances&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_allowances_btn=magic_button_link("./".$current_file_url."?allowances_uptoken=".$_GET["allowances_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_allowances_btn." ".$cancel_del_allowances_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_allowances_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteallowances"]))
      {
         $gwauthenticate_allowances_=gw_oauth("table", magic_current_url(), "allowances", "super_delete_confirm","");

         $gwauthenticate_allowances_json=json_decode($gwauthenticate_allowances_, true);
         	
          //echo $gwauthenticate_allowances_;

         if($gwauthenticate_allowances_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $allowances_del_key_salt=initialize_allowances()["allowance_id"];
      mosy_sql_rollback("allowances", "primkey='$allowances_uptoken'", "DELETE");
      drop_allowances("primkey='$allowances_uptoken' and allowance_id='$allowances_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_allowances_);

      }
      }

      //== End allowances delete record  
    
       ///SELECT STRING FOR allowances============================
              
       if(isset($_POST["qallowances_btn"])){
         $gwauthenticate_allowances_=gw_oauth("table", magic_current_url(), "allowances", "qallowances_btn","");

         $gwauthenticate_allowances_json=json_decode($gwauthenticate_allowances_, true);
         	
          //echo $gwauthenticate_allowances_;

         if($gwauthenticate_allowances_json["response"]=="ok")
         {
            $current_allowances_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_allowances_current_url=$current_allowances_url_params.'?qallowances=';
            if (strpos($current_allowances_url_params, '?') !== false) {

                $clean_allowances_current_url=$current_allowances_url_params.'&qallowances=';

            }
            if (strpos($current_allowances_url_params, '?qallowances')) {

                $remove_allowances_old_token = substr($current_allowances_url_params, 0, strpos($current_allowances_url_params, "?qallowances"));

                $clean_allowances_current_url=$remove_allowances_old_token.'?qallowances=';

            }
            if(strpos($current_allowances_url_params, '&qallowances')) {

                $remove_allowances_old_token = substr($current_allowances_url_params, 0, strpos($current_allowances_url_params, "&qallowances"));

                $clean_allowances_current_url=$remove_allowances_old_token.'&qallowances=';

            }
        $qallowances_str=base64_encode($_POST["txt_allowances"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_allowances_current_url.($qallowances_str);
            } 

          }else{ 
             header('location:'.$clean_allowances_current_url.($qallowances_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_allowances_);

        }
        }
        $qallowances="";
		if(isset($_GET["allowances_mosyfilter"]) && isset($_GET["qallowances"])){
         $gwauthenticate_allowances_=gw_oauth("table", magic_current_url(), "allowances", "allowances_mosyfilter_n_query","");

         $gwauthenticate_allowances_json=json_decode($gwauthenticate_allowances_, true);
         	
          //echo $gwauthenticate_allowances_;

         if($gwauthenticate_allowances_json["response"]=="ok")
         {
         $qallowances=mmres(base64_decode($_GET["qallowances"]));
         
         $gft_allowances_where_query="(`allowance_id` LIKE '%".$qallowances."%' OR  `allowance_title` LIKE '%".$qallowances."%' OR  `amount` LIKE '%".$qallowances."%' OR  `staff_id` LIKE '%".$qallowances."%' OR  `remark` LIKE '%".$qallowances."%' OR  `owner` LIKE '%".$qallowances."%' OR  `active_state` LIKE '%".$qallowances."%')";
         
         if($_GET["allowances_mosyfilter"]!=""){
         
         $mosyfilter_allowances_queries_str=(base64_decode($_GET["allowances_mosyfilter"]));
        
         $gft_allowances_where_query="(`allowance_id` LIKE '%".$qallowances."%' OR  `allowance_title` LIKE '%".$qallowances."%' OR  `amount` LIKE '%".$qallowances."%' OR  `staff_id` LIKE '%".$qallowances."%' OR  `remark` LIKE '%".$qallowances."%' OR  `owner` LIKE '%".$qallowances."%' OR  `active_state` LIKE '%".$qallowances."%') AND ".$mosyfilter_allowances_queries_str."";
         
         }
         
		 $gft_allowances="WHERE ".$gft_allowances_where_query;
         
         $gft_allowances_and=$gft_allowances_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_allowances_);
        }
        }elseif(isset($_GET["qallowances"])){
         $gwauthenticate_allowances_=gw_oauth("table", magic_current_url(), "allowances", "get_qallowances","");

         $gwauthenticate_allowances_json=json_decode($gwauthenticate_allowances_, true);
         	
          //echo $gwauthenticate_allowances_;

         if($gwauthenticate_allowances_json["response"]=="ok")
         {
		 $qallowances=mmres(base64_decode($_GET["qallowances"]));
        
         $gft_allowances_where_query="(`allowance_id` LIKE '%".$qallowances."%' OR  `allowance_title` LIKE '%".$qallowances."%' OR  `amount` LIKE '%".$qallowances."%' OR  `staff_id` LIKE '%".$qallowances."%' OR  `remark` LIKE '%".$qallowances."%' OR  `owner` LIKE '%".$qallowances."%' OR  `active_state` LIKE '%".$qallowances."%')";
         
         $gft_allowances="WHERE ".$gft_allowances_where_query;
         
         $gft_allowances_and=$gft_allowances_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_allowances_);

        }
        }elseif(isset($_GET["allowances_mosyfilter"])){
         $gwauthenticate_allowances_=gw_oauth("table", magic_current_url(), "allowances", "allowances_mosyfilter","");

         $gwauthenticate_allowances_json=json_decode($gwauthenticate_allowances_, true);
         	
          //echo $gwauthenticate_allowances_;

         if($gwauthenticate_allowances_json["response"]=="ok")
         {
         $gft_allowances_where_query="";
         $gft_allowances="";

         if($_GET["allowances_mosyfilter"]!=""){
          $gft_allowances_where_query=(base64_decode($_GET["allowances_mosyfilter"]));
          $gft_allowances="WHERE ".$gft_allowances_where_query;
         }
         
         
         $gft_allowances_and=$gft_allowances_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_allowances_);

        }
        }else{
         $gft_allowances="";
         $gft_allowances_and="";
         $gft_allowances_where_query="";
        }
       
    //************************************************* END  allowances OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section app_users
  //************************************************* START  app_users OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize app_users edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['app_users_table_alert']))
              	{	
                  if(isset($app_users_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$app_users_uptoken="";

		if(isset($_GET["app_users_uptoken"]))
		{
		$app_users_uptoken=base64_decode($_GET["app_users_uptoken"]);
		}
        
        if(isset($_POST["app_users_uptoken"]))
		{
		$app_users_uptoken=base64_decode($_POST["app_users_uptoken"]);
		}
        //
        
          $app_users_alias_name="APP USERS";

          if(isset($app_users_alias))
          {
             $app_users_alias_name=$app_users_alias;

          }
          
        //get single data record query with $app_users_uptoken
        
        ///$app_users_node=get_app_users("*", "WHERE primkey='$app_users_uptoken'", "r");
        
	
//************* START INSERT  app_users QUERY 
if(isset($_POST["app_users_insert_btn"])){
//------- begin app_users_arr_ins --> 
$app_users_arr_ins_=array(

"primkey"=>"NULL",
"user_id"=>magic_random_str(7),
"name"=>"?",
"email"=>"?",
"tel"=>"?",
"login_password"=>"?",
"account_no"=>"?",
"date_signed_up"=>"?",
"user_no"=>"?",
"user_pic"=>"?",
"user_gender"=>"?",
"last_seen"=>"?",
"about"=>"?"

);
//===-- End app_users_arr_ins -->


          
         $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "insert","");

         $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
         	
          //echo $gwauthenticate_app_users_;

         if($gwauthenticate_app_users_json["response"]=="ok")
         {

              $app_users_validated_ins_str=$app_users_arr_ins_;

              if(isset($app_users_ins_inputs))
              {
                $app_users_validated_ins_str=$app_users_ins_inputs;	
              }

              if(empty($app_users_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$app_users_alias_name." request cannot be empty. Record not added");
              }else{

                $app_users_return_key=add_app_users($app_users_validated_ins_str);
                
                mosy_sql_rollback("app_users", "primkey='$app_users_return_key'", "INSERT");
					
         
                if(!empty($_FILES['txt_app_users_user_pic']['tmp_name']))
                {
                
                 upload_app_users_user_pic('txt_app_users_user_pic', "primkey='$app_users_return_key'");
                 
				}
                
         
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $app_users_return_key; 

                      } 

                    }else{ 

                                    
                $app_users_custom_redir1=add_url_param ("app_users_uptoken", base64_encode($app_users_return_key), "");
                $app_users_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$app_users_custom_redir1);
                $app_users_custom_redir3=add_url_param ("app_users_table_alert", "app_users_added",$app_users_custom_redir2);
                
                ///echo magic_message($app_users_custom_redir1." -- ".$app_users_custom_redir2."--".$app_users_custom_redir3);
                
                $app_users_custom_redir=$app_users_custom_redir3;
                
               header('location:'.$app_users_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_app_users_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_users_)."");
         
         }
      
}
//************* END  app_users INSERT QUERY 	
	

//************* START app_users  UPDATE QUERY 
if(isset($_POST["app_users_update_btn"])){
//------- begin app_users_arr_updt --> 
$app_users_arr_updt_=array(
"name"=>"?",
"email"=>"?",
"tel"=>"?",
"login_password"=>"?",
"account_no"=>"?",
"date_signed_up"=>"?",
"user_no"=>"?",
"user_pic"=>"?",
"user_gender"=>"?",
"last_seen"=>"?",
"about"=>"?"

);
//===-- End app_users_arr_updt -->
                     
         $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "update","");

         $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
         	
          //echo $gwauthenticate_app_users_;

         if($gwauthenticate_app_users_json["response"]=="ok")
         {
         
            $app_users_validated_updt_str=$app_users_arr_updt_;

            if(isset($app_users_updt_inputs))
            {
              $app_users_validated_updt_str=$app_users_updt_inputs;	
            }

            if(empty($app_users_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$app_users_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$app_users_key_salt=initialize_app_users()["user_id"];
            
              update_app_users($app_users_validated_updt_str, "primkey='$app_users_uptoken' and user_id='$app_users_key_salt'");
				
         
                if(!empty($_FILES['txt_app_users_user_pic']['tmp_name']))
                {
                
                 upload_app_users_user_pic('txt_app_users_user_pic', "primkey='$app_users_uptoken'");
                 
				}

			 mosy_sql_rollback("app_users", "primkey='$app_users_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $app_users_uptoken; 

                    } 

                  }else{ 

                $app_users_custom_redir1=add_url_param ("app_users_uptoken", base64_encode($app_users_uptoken), "");
                $app_users_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$app_users_custom_redir1);
                $app_users_custom_redir3=add_url_param ("app_users_table_alert", "app_users_updated",$app_users_custom_redir2);
                
                ///echo magic_message($app_users_custom_redir1." -- ".$app_users_custom_redir2."--".$app_users_custom_redir3);
                
                $app_users_custom_redir=$app_users_custom_redir3;
                
               header('location:'.$app_users_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_app_users_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_app_users_)."");
         
         }

      

      
}
//************* END app_users  UPDATE QUERY 

    

          //===-====Start upload app_users_user_pic 
          if(isset($_POST["btn_upload_app_users_user_pic"]))
          {
         $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "upload_app_users_user_pic","");

         $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
         	
          //echo $gwauthenticate_app_users_;

         if($gwauthenticate_app_users_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_app_users_user_pic']['tmp_name'])){

				upload_app_users_user_pic('txt_app_users_user_pic', "primkey='$app_users_uptoken'");
                
                $app_users_custom_redir1=add_url_param ("app_users_uptoken", base64_encode($app_users_uptoken), "");
                $app_users_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$app_users_custom_redir1);
                $app_users_custom_redir3=add_url_param ("app_users_table_alert", "app_users_uploaded",$app_users_custom_redir2);
                
                ///echo magic_message($app_users_custom_redir1." -- ".$app_users_custom_redir2."--".$app_users_custom_redir3);
                
                $app_users_custom_redir=$app_users_custom_redir3;
                
               header('location:'.$app_users_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_app_users_);

          }
          }
          //===-====End upload app_users_user_pic  

			//drop app_users_user_pic image 
            
          if(isset($_GET["conf_deleteapp_users"]))
          {
          	$app_users_node=initialize_app_users();
          	if($app_users_node["user_pic"]!="")
            {
          	 unlink($app_users_node["user_pic"]);
            }
          }
          
          
    
      //== Start app_users delete record

      if(isset($_GET["deleteapp_users"]))
      {
         $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "super_delete_request","");

         $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
         	
          //echo $gwauthenticate_app_users_;

         if($gwauthenticate_app_users_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_app_users_btn=magic_button_link("./".$current_file_url."?app_users_uptoken=".$_GET["app_users_uptoken"]."&conf_deleteapp_users&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_app_users_btn=magic_button_link("./".$current_file_url."?app_users_uptoken=".$_GET["app_users_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_app_users_btn." ".$cancel_del_app_users_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_app_users_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteapp_users"]))
      {
         $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "super_delete_confirm","");

         $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
         	
          //echo $gwauthenticate_app_users_;

         if($gwauthenticate_app_users_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $app_users_del_key_salt=initialize_app_users()["user_id"];
      mosy_sql_rollback("app_users", "primkey='$app_users_uptoken'", "DELETE");
      drop_app_users("primkey='$app_users_uptoken' and user_id='$app_users_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_app_users_);

      }
      }

      //== End app_users delete record  
    
       ///SELECT STRING FOR app_users============================
              
       if(isset($_POST["qapp_users_btn"])){
         $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "qapp_users_btn","");

         $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
         	
          //echo $gwauthenticate_app_users_;

         if($gwauthenticate_app_users_json["response"]=="ok")
         {
            $current_app_users_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_app_users_current_url=$current_app_users_url_params.'?qapp_users=';
            if (strpos($current_app_users_url_params, '?') !== false) {

                $clean_app_users_current_url=$current_app_users_url_params.'&qapp_users=';

            }
            if (strpos($current_app_users_url_params, '?qapp_users')) {

                $remove_app_users_old_token = substr($current_app_users_url_params, 0, strpos($current_app_users_url_params, "?qapp_users"));

                $clean_app_users_current_url=$remove_app_users_old_token.'?qapp_users=';

            }
            if(strpos($current_app_users_url_params, '&qapp_users')) {

                $remove_app_users_old_token = substr($current_app_users_url_params, 0, strpos($current_app_users_url_params, "&qapp_users"));

                $clean_app_users_current_url=$remove_app_users_old_token.'&qapp_users=';

            }
        $qapp_users_str=base64_encode($_POST["txt_app_users"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_app_users_current_url.($qapp_users_str);
            } 

          }else{ 
             header('location:'.$clean_app_users_current_url.($qapp_users_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_app_users_);

        }
        }
        $qapp_users="";
		if(isset($_GET["app_users_mosyfilter"]) && isset($_GET["qapp_users"])){
         $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "app_users_mosyfilter_n_query","");

         $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
         	
          //echo $gwauthenticate_app_users_;

         if($gwauthenticate_app_users_json["response"]=="ok")
         {
         $qapp_users=mmres(base64_decode($_GET["qapp_users"]));
         
         $gft_app_users_where_query="(`user_id` LIKE '%".$qapp_users."%' OR  `name` LIKE '%".$qapp_users."%' OR  `email` LIKE '%".$qapp_users."%' OR  `tel` LIKE '%".$qapp_users."%' OR  `login_password` LIKE '%".$qapp_users."%' OR  `account_no` LIKE '%".$qapp_users."%' OR  `date_signed_up` LIKE '%".$qapp_users."%' OR  `user_no` LIKE '%".$qapp_users."%' OR  `user_pic` LIKE '%".$qapp_users."%' OR  `user_gender` LIKE '%".$qapp_users."%' OR  `last_seen` LIKE '%".$qapp_users."%' OR  `about` LIKE '%".$qapp_users."%')";
         
         if($_GET["app_users_mosyfilter"]!=""){
         
         $mosyfilter_app_users_queries_str=(base64_decode($_GET["app_users_mosyfilter"]));
        
         $gft_app_users_where_query="(`user_id` LIKE '%".$qapp_users."%' OR  `name` LIKE '%".$qapp_users."%' OR  `email` LIKE '%".$qapp_users."%' OR  `tel` LIKE '%".$qapp_users."%' OR  `login_password` LIKE '%".$qapp_users."%' OR  `account_no` LIKE '%".$qapp_users."%' OR  `date_signed_up` LIKE '%".$qapp_users."%' OR  `user_no` LIKE '%".$qapp_users."%' OR  `user_pic` LIKE '%".$qapp_users."%' OR  `user_gender` LIKE '%".$qapp_users."%' OR  `last_seen` LIKE '%".$qapp_users."%' OR  `about` LIKE '%".$qapp_users."%') AND ".$mosyfilter_app_users_queries_str."";
         
         }
         
		 $gft_app_users="WHERE ".$gft_app_users_where_query;
         
         $gft_app_users_and=$gft_app_users_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_app_users_);
        }
        }elseif(isset($_GET["qapp_users"])){
         $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "get_qapp_users","");

         $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
         	
          //echo $gwauthenticate_app_users_;

         if($gwauthenticate_app_users_json["response"]=="ok")
         {
		 $qapp_users=mmres(base64_decode($_GET["qapp_users"]));
        
         $gft_app_users_where_query="(`user_id` LIKE '%".$qapp_users."%' OR  `name` LIKE '%".$qapp_users."%' OR  `email` LIKE '%".$qapp_users."%' OR  `tel` LIKE '%".$qapp_users."%' OR  `login_password` LIKE '%".$qapp_users."%' OR  `account_no` LIKE '%".$qapp_users."%' OR  `date_signed_up` LIKE '%".$qapp_users."%' OR  `user_no` LIKE '%".$qapp_users."%' OR  `user_pic` LIKE '%".$qapp_users."%' OR  `user_gender` LIKE '%".$qapp_users."%' OR  `last_seen` LIKE '%".$qapp_users."%' OR  `about` LIKE '%".$qapp_users."%')";
         
         $gft_app_users="WHERE ".$gft_app_users_where_query;
         
         $gft_app_users_and=$gft_app_users_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_app_users_);

        }
        }elseif(isset($_GET["app_users_mosyfilter"])){
         $gwauthenticate_app_users_=gw_oauth("table", magic_current_url(), "app_users", "app_users_mosyfilter","");

         $gwauthenticate_app_users_json=json_decode($gwauthenticate_app_users_, true);
         	
          //echo $gwauthenticate_app_users_;

         if($gwauthenticate_app_users_json["response"]=="ok")
         {
         $gft_app_users_where_query="";
         $gft_app_users="";

         if($_GET["app_users_mosyfilter"]!=""){
          $gft_app_users_where_query=(base64_decode($_GET["app_users_mosyfilter"]));
          $gft_app_users="WHERE ".$gft_app_users_where_query;
         }
         
         
         $gft_app_users_and=$gft_app_users_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_app_users_);

        }
        }else{
         $gft_app_users="";
         $gft_app_users_and="";
         $gft_app_users_where_query="";
        }
       
    //************************************************* END  app_users OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section casuals_payroll
  //************************************************* START  casuals_payroll OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize casuals_payroll edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['casuals_payroll_table_alert']))
              	{	
                  if(isset($casuals_payroll_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$casuals_payroll_uptoken="";

		if(isset($_GET["casuals_payroll_uptoken"]))
		{
		$casuals_payroll_uptoken=base64_decode($_GET["casuals_payroll_uptoken"]);
		}
        
        if(isset($_POST["casuals_payroll_uptoken"]))
		{
		$casuals_payroll_uptoken=base64_decode($_POST["casuals_payroll_uptoken"]);
		}
        //
        
          $casuals_payroll_alias_name="CASUALS PAYROLL";

          if(isset($casuals_payroll_alias))
          {
             $casuals_payroll_alias_name=$casuals_payroll_alias;

          }
          
        //get single data record query with $casuals_payroll_uptoken
        
        ///$casuals_payroll_node=get_casuals_payroll("*", "WHERE primkey='$casuals_payroll_uptoken'", "r");
        
	
//************* START INSERT  casuals_payroll QUERY 
if(isset($_POST["casuals_payroll_insert_btn"])){
//------- begin casuals_payroll_arr_ins --> 
$casuals_payroll_arr_ins_=array(

"primkey"=>"NULL",
"payroll_id"=>magic_random_str(7),
"payroll_month_year"=>"?",
"payroll_date"=>"?",
"staff_id"=>"?",
"job_group"=>"?",
"basicsalary"=>"?",
"bonus_and_commissions"=>"?",
"deductions"=>"?",
"net_salary"=>"?",
"payroll_number"=>"?",
"payroll_notes"=>"?",
"days_worked"=>"?",
"owner"=>"?"

);
//===-- End casuals_payroll_arr_ins -->


          
         $gwauthenticate_casuals_payroll_=gw_oauth("table", magic_current_url(), "casuals_payroll", "insert","");

         $gwauthenticate_casuals_payroll_json=json_decode($gwauthenticate_casuals_payroll_, true);
         	
          //echo $gwauthenticate_casuals_payroll_;

         if($gwauthenticate_casuals_payroll_json["response"]=="ok")
         {

              $casuals_payroll_validated_ins_str=$casuals_payroll_arr_ins_;

              if(isset($casuals_payroll_ins_inputs))
              {
                $casuals_payroll_validated_ins_str=$casuals_payroll_ins_inputs;	
              }

              if(empty($casuals_payroll_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$casuals_payroll_alias_name." request cannot be empty. Record not added");
              }else{

                $casuals_payroll_return_key=add_casuals_payroll($casuals_payroll_validated_ins_str);
                
                mosy_sql_rollback("casuals_payroll", "primkey='$casuals_payroll_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $casuals_payroll_return_key; 

                      } 

                    }else{ 

                                    
                $casuals_payroll_custom_redir1=add_url_param ("casuals_payroll_uptoken", base64_encode($casuals_payroll_return_key), "");
                $casuals_payroll_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$casuals_payroll_custom_redir1);
                $casuals_payroll_custom_redir3=add_url_param ("casuals_payroll_table_alert", "casuals_payroll_added",$casuals_payroll_custom_redir2);
                
                ///echo magic_message($casuals_payroll_custom_redir1." -- ".$casuals_payroll_custom_redir2."--".$casuals_payroll_custom_redir3);
                
                $casuals_payroll_custom_redir=$casuals_payroll_custom_redir3;
                
               header('location:'.$casuals_payroll_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_casuals_payroll_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_casuals_payroll_)."");
         
         }
      
}
//************* END  casuals_payroll INSERT QUERY 	
	

//************* START casuals_payroll  UPDATE QUERY 
if(isset($_POST["casuals_payroll_update_btn"])){
//------- begin casuals_payroll_arr_updt --> 
$casuals_payroll_arr_updt_=array(
"payroll_month_year"=>"?",
"payroll_date"=>"?",
"staff_id"=>"?",
"job_group"=>"?",
"basicsalary"=>"?",
"bonus_and_commissions"=>"?",
"deductions"=>"?",
"net_salary"=>"?",
"payroll_number"=>"?",
"payroll_notes"=>"?",
"days_worked"=>"?",
"owner"=>"?"

);
//===-- End casuals_payroll_arr_updt -->
                     
         $gwauthenticate_casuals_payroll_=gw_oauth("table", magic_current_url(), "casuals_payroll", "update","");

         $gwauthenticate_casuals_payroll_json=json_decode($gwauthenticate_casuals_payroll_, true);
         	
          //echo $gwauthenticate_casuals_payroll_;

         if($gwauthenticate_casuals_payroll_json["response"]=="ok")
         {
         
            $casuals_payroll_validated_updt_str=$casuals_payroll_arr_updt_;

            if(isset($casuals_payroll_updt_inputs))
            {
              $casuals_payroll_validated_updt_str=$casuals_payroll_updt_inputs;	
            }

            if(empty($casuals_payroll_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$casuals_payroll_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$casuals_payroll_key_salt=initialize_casuals_payroll()["payroll_id"];
            
              update_casuals_payroll($casuals_payroll_validated_updt_str, "primkey='$casuals_payroll_uptoken' and payroll_id='$casuals_payroll_key_salt'");
				

			 mosy_sql_rollback("casuals_payroll", "primkey='$casuals_payroll_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $casuals_payroll_uptoken; 

                    } 

                  }else{ 

                $casuals_payroll_custom_redir1=add_url_param ("casuals_payroll_uptoken", base64_encode($casuals_payroll_uptoken), "");
                $casuals_payroll_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$casuals_payroll_custom_redir1);
                $casuals_payroll_custom_redir3=add_url_param ("casuals_payroll_table_alert", "casuals_payroll_updated",$casuals_payroll_custom_redir2);
                
                ///echo magic_message($casuals_payroll_custom_redir1." -- ".$casuals_payroll_custom_redir2."--".$casuals_payroll_custom_redir3);
                
                $casuals_payroll_custom_redir=$casuals_payroll_custom_redir3;
                
               header('location:'.$casuals_payroll_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_casuals_payroll_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_casuals_payroll_)."");
         
         }

      

      
}
//************* END casuals_payroll  UPDATE QUERY 

    
    
      //== Start casuals_payroll delete record

      if(isset($_GET["deletecasuals_payroll"]))
      {
         $gwauthenticate_casuals_payroll_=gw_oauth("table", magic_current_url(), "casuals_payroll", "super_delete_request","");

         $gwauthenticate_casuals_payroll_json=json_decode($gwauthenticate_casuals_payroll_, true);
         	
          //echo $gwauthenticate_casuals_payroll_;

         if($gwauthenticate_casuals_payroll_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_casuals_payroll_btn=magic_button_link("./".$current_file_url."?casuals_payroll_uptoken=".$_GET["casuals_payroll_uptoken"]."&conf_deletecasuals_payroll&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_casuals_payroll_btn=magic_button_link("./".$current_file_url."?casuals_payroll_uptoken=".$_GET["casuals_payroll_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_casuals_payroll_btn." ".$cancel_del_casuals_payroll_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_casuals_payroll_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletecasuals_payroll"]))
      {
         $gwauthenticate_casuals_payroll_=gw_oauth("table", magic_current_url(), "casuals_payroll", "super_delete_confirm","");

         $gwauthenticate_casuals_payroll_json=json_decode($gwauthenticate_casuals_payroll_, true);
         	
          //echo $gwauthenticate_casuals_payroll_;

         if($gwauthenticate_casuals_payroll_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $casuals_payroll_del_key_salt=initialize_casuals_payroll()["payroll_id"];
      mosy_sql_rollback("casuals_payroll", "primkey='$casuals_payroll_uptoken'", "DELETE");
      drop_casuals_payroll("primkey='$casuals_payroll_uptoken' and payroll_id='$casuals_payroll_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_casuals_payroll_);

      }
      }

      //== End casuals_payroll delete record  
    
       ///SELECT STRING FOR casuals_payroll============================
              
       if(isset($_POST["qcasuals_payroll_btn"])){
         $gwauthenticate_casuals_payroll_=gw_oauth("table", magic_current_url(), "casuals_payroll", "qcasuals_payroll_btn","");

         $gwauthenticate_casuals_payroll_json=json_decode($gwauthenticate_casuals_payroll_, true);
         	
          //echo $gwauthenticate_casuals_payroll_;

         if($gwauthenticate_casuals_payroll_json["response"]=="ok")
         {
            $current_casuals_payroll_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_casuals_payroll_current_url=$current_casuals_payroll_url_params.'?qcasuals_payroll=';
            if (strpos($current_casuals_payroll_url_params, '?') !== false) {

                $clean_casuals_payroll_current_url=$current_casuals_payroll_url_params.'&qcasuals_payroll=';

            }
            if (strpos($current_casuals_payroll_url_params, '?qcasuals_payroll')) {

                $remove_casuals_payroll_old_token = substr($current_casuals_payroll_url_params, 0, strpos($current_casuals_payroll_url_params, "?qcasuals_payroll"));

                $clean_casuals_payroll_current_url=$remove_casuals_payroll_old_token.'?qcasuals_payroll=';

            }
            if(strpos($current_casuals_payroll_url_params, '&qcasuals_payroll')) {

                $remove_casuals_payroll_old_token = substr($current_casuals_payroll_url_params, 0, strpos($current_casuals_payroll_url_params, "&qcasuals_payroll"));

                $clean_casuals_payroll_current_url=$remove_casuals_payroll_old_token.'&qcasuals_payroll=';

            }
        $qcasuals_payroll_str=base64_encode($_POST["txt_casuals_payroll"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_casuals_payroll_current_url.($qcasuals_payroll_str);
            } 

          }else{ 
             header('location:'.$clean_casuals_payroll_current_url.($qcasuals_payroll_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_casuals_payroll_);

        }
        }
        $qcasuals_payroll="";
		if(isset($_GET["casuals_payroll_mosyfilter"]) && isset($_GET["qcasuals_payroll"])){
         $gwauthenticate_casuals_payroll_=gw_oauth("table", magic_current_url(), "casuals_payroll", "casuals_payroll_mosyfilter_n_query","");

         $gwauthenticate_casuals_payroll_json=json_decode($gwauthenticate_casuals_payroll_, true);
         	
          //echo $gwauthenticate_casuals_payroll_;

         if($gwauthenticate_casuals_payroll_json["response"]=="ok")
         {
         $qcasuals_payroll=mmres(base64_decode($_GET["qcasuals_payroll"]));
         
         $gft_casuals_payroll_where_query="(`payroll_id` LIKE '%".$qcasuals_payroll."%' OR  `payroll_month_year` LIKE '%".$qcasuals_payroll."%' OR  `payroll_date` LIKE '%".$qcasuals_payroll."%' OR  `staff_id` LIKE '%".$qcasuals_payroll."%' OR  `job_group` LIKE '%".$qcasuals_payroll."%' OR  `basicsalary` LIKE '%".$qcasuals_payroll."%' OR  `bonus_and_commissions` LIKE '%".$qcasuals_payroll."%' OR  `deductions` LIKE '%".$qcasuals_payroll."%' OR  `net_salary` LIKE '%".$qcasuals_payroll."%' OR  `payroll_number` LIKE '%".$qcasuals_payroll."%' OR  `payroll_notes` LIKE '%".$qcasuals_payroll."%' OR  `days_worked` LIKE '%".$qcasuals_payroll."%' OR  `owner` LIKE '%".$qcasuals_payroll."%')";
         
         if($_GET["casuals_payroll_mosyfilter"]!=""){
         
         $mosyfilter_casuals_payroll_queries_str=(base64_decode($_GET["casuals_payroll_mosyfilter"]));
        
         $gft_casuals_payroll_where_query="(`payroll_id` LIKE '%".$qcasuals_payroll."%' OR  `payroll_month_year` LIKE '%".$qcasuals_payroll."%' OR  `payroll_date` LIKE '%".$qcasuals_payroll."%' OR  `staff_id` LIKE '%".$qcasuals_payroll."%' OR  `job_group` LIKE '%".$qcasuals_payroll."%' OR  `basicsalary` LIKE '%".$qcasuals_payroll."%' OR  `bonus_and_commissions` LIKE '%".$qcasuals_payroll."%' OR  `deductions` LIKE '%".$qcasuals_payroll."%' OR  `net_salary` LIKE '%".$qcasuals_payroll."%' OR  `payroll_number` LIKE '%".$qcasuals_payroll."%' OR  `payroll_notes` LIKE '%".$qcasuals_payroll."%' OR  `days_worked` LIKE '%".$qcasuals_payroll."%' OR  `owner` LIKE '%".$qcasuals_payroll."%') AND ".$mosyfilter_casuals_payroll_queries_str."";
         
         }
         
		 $gft_casuals_payroll="WHERE ".$gft_casuals_payroll_where_query;
         
         $gft_casuals_payroll_and=$gft_casuals_payroll_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_casuals_payroll_);
        }
        }elseif(isset($_GET["qcasuals_payroll"])){
         $gwauthenticate_casuals_payroll_=gw_oauth("table", magic_current_url(), "casuals_payroll", "get_qcasuals_payroll","");

         $gwauthenticate_casuals_payroll_json=json_decode($gwauthenticate_casuals_payroll_, true);
         	
          //echo $gwauthenticate_casuals_payroll_;

         if($gwauthenticate_casuals_payroll_json["response"]=="ok")
         {
		 $qcasuals_payroll=mmres(base64_decode($_GET["qcasuals_payroll"]));
        
         $gft_casuals_payroll_where_query="(`payroll_id` LIKE '%".$qcasuals_payroll."%' OR  `payroll_month_year` LIKE '%".$qcasuals_payroll."%' OR  `payroll_date` LIKE '%".$qcasuals_payroll."%' OR  `staff_id` LIKE '%".$qcasuals_payroll."%' OR  `job_group` LIKE '%".$qcasuals_payroll."%' OR  `basicsalary` LIKE '%".$qcasuals_payroll."%' OR  `bonus_and_commissions` LIKE '%".$qcasuals_payroll."%' OR  `deductions` LIKE '%".$qcasuals_payroll."%' OR  `net_salary` LIKE '%".$qcasuals_payroll."%' OR  `payroll_number` LIKE '%".$qcasuals_payroll."%' OR  `payroll_notes` LIKE '%".$qcasuals_payroll."%' OR  `days_worked` LIKE '%".$qcasuals_payroll."%' OR  `owner` LIKE '%".$qcasuals_payroll."%')";
         
         $gft_casuals_payroll="WHERE ".$gft_casuals_payroll_where_query;
         
         $gft_casuals_payroll_and=$gft_casuals_payroll_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_casuals_payroll_);

        }
        }elseif(isset($_GET["casuals_payroll_mosyfilter"])){
         $gwauthenticate_casuals_payroll_=gw_oauth("table", magic_current_url(), "casuals_payroll", "casuals_payroll_mosyfilter","");

         $gwauthenticate_casuals_payroll_json=json_decode($gwauthenticate_casuals_payroll_, true);
         	
          //echo $gwauthenticate_casuals_payroll_;

         if($gwauthenticate_casuals_payroll_json["response"]=="ok")
         {
         $gft_casuals_payroll_where_query="";
         $gft_casuals_payroll="";

         if($_GET["casuals_payroll_mosyfilter"]!=""){
          $gft_casuals_payroll_where_query=(base64_decode($_GET["casuals_payroll_mosyfilter"]));
          $gft_casuals_payroll="WHERE ".$gft_casuals_payroll_where_query;
         }
         
         
         $gft_casuals_payroll_and=$gft_casuals_payroll_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_casuals_payroll_);

        }
        }else{
         $gft_casuals_payroll="";
         $gft_casuals_payroll_and="";
         $gft_casuals_payroll_where_query="";
        }
       
    //************************************************* END  casuals_payroll OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section commissions
  //************************************************* START  commissions OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize commissions edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['commissions_table_alert']))
              	{	
                  if(isset($commissions_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$commissions_uptoken="";

		if(isset($_GET["commissions_uptoken"]))
		{
		$commissions_uptoken=base64_decode($_GET["commissions_uptoken"]);
		}
        
        if(isset($_POST["commissions_uptoken"]))
		{
		$commissions_uptoken=base64_decode($_POST["commissions_uptoken"]);
		}
        //
        
          $commissions_alias_name="COMMISSIONS";

          if(isset($commissions_alias))
          {
             $commissions_alias_name=$commissions_alias;

          }
          
        //get single data record query with $commissions_uptoken
        
        ///$commissions_node=get_commissions("*", "WHERE primkey='$commissions_uptoken'", "r");
        
	
//************* START INSERT  commissions QUERY 
if(isset($_POST["commissions_insert_btn"])){
//------- begin commissions_arr_ins --> 
$commissions_arr_ins_=array(

"primkey"=>"NULL",
"commission_id"=>magic_random_str(7),
"commission_name"=>"?",
"amount"=>"?",
"staff_id"=>"?",
"remark"=>"?",
"active_state"=>"?",
"owner"=>"?"

);
//===-- End commissions_arr_ins -->


          
         $gwauthenticate_commissions_=gw_oauth("table", magic_current_url(), "commissions", "insert","");

         $gwauthenticate_commissions_json=json_decode($gwauthenticate_commissions_, true);
         	
          //echo $gwauthenticate_commissions_;

         if($gwauthenticate_commissions_json["response"]=="ok")
         {

              $commissions_validated_ins_str=$commissions_arr_ins_;

              if(isset($commissions_ins_inputs))
              {
                $commissions_validated_ins_str=$commissions_ins_inputs;	
              }

              if(empty($commissions_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$commissions_alias_name." request cannot be empty. Record not added");
              }else{

                $commissions_return_key=add_commissions($commissions_validated_ins_str);
                
                mosy_sql_rollback("commissions", "primkey='$commissions_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $commissions_return_key; 

                      } 

                    }else{ 

                                    
                $commissions_custom_redir1=add_url_param ("commissions_uptoken", base64_encode($commissions_return_key), "");
                $commissions_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$commissions_custom_redir1);
                $commissions_custom_redir3=add_url_param ("commissions_table_alert", "commissions_added",$commissions_custom_redir2);
                
                ///echo magic_message($commissions_custom_redir1." -- ".$commissions_custom_redir2."--".$commissions_custom_redir3);
                
                $commissions_custom_redir=$commissions_custom_redir3;
                
               header('location:'.$commissions_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_commissions_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_commissions_)."");
         
         }
      
}
//************* END  commissions INSERT QUERY 	
	

//************* START commissions  UPDATE QUERY 
if(isset($_POST["commissions_update_btn"])){
//------- begin commissions_arr_updt --> 
$commissions_arr_updt_=array(
"commission_name"=>"?",
"amount"=>"?",
"staff_id"=>"?",
"remark"=>"?",
"active_state"=>"?",
"owner"=>"?"

);
//===-- End commissions_arr_updt -->
                     
         $gwauthenticate_commissions_=gw_oauth("table", magic_current_url(), "commissions", "update","");

         $gwauthenticate_commissions_json=json_decode($gwauthenticate_commissions_, true);
         	
          //echo $gwauthenticate_commissions_;

         if($gwauthenticate_commissions_json["response"]=="ok")
         {
         
            $commissions_validated_updt_str=$commissions_arr_updt_;

            if(isset($commissions_updt_inputs))
            {
              $commissions_validated_updt_str=$commissions_updt_inputs;	
            }

            if(empty($commissions_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$commissions_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$commissions_key_salt=initialize_commissions()["commission_id"];
            
              update_commissions($commissions_validated_updt_str, "primkey='$commissions_uptoken' and commission_id='$commissions_key_salt'");
				

			 mosy_sql_rollback("commissions", "primkey='$commissions_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $commissions_uptoken; 

                    } 

                  }else{ 

                $commissions_custom_redir1=add_url_param ("commissions_uptoken", base64_encode($commissions_uptoken), "");
                $commissions_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$commissions_custom_redir1);
                $commissions_custom_redir3=add_url_param ("commissions_table_alert", "commissions_updated",$commissions_custom_redir2);
                
                ///echo magic_message($commissions_custom_redir1." -- ".$commissions_custom_redir2."--".$commissions_custom_redir3);
                
                $commissions_custom_redir=$commissions_custom_redir3;
                
               header('location:'.$commissions_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_commissions_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_commissions_)."");
         
         }

      

      
}
//************* END commissions  UPDATE QUERY 

    
    
      //== Start commissions delete record

      if(isset($_GET["deletecommissions"]))
      {
         $gwauthenticate_commissions_=gw_oauth("table", magic_current_url(), "commissions", "super_delete_request","");

         $gwauthenticate_commissions_json=json_decode($gwauthenticate_commissions_, true);
         	
          //echo $gwauthenticate_commissions_;

         if($gwauthenticate_commissions_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_commissions_btn=magic_button_link("./".$current_file_url."?commissions_uptoken=".$_GET["commissions_uptoken"]."&conf_deletecommissions&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_commissions_btn=magic_button_link("./".$current_file_url."?commissions_uptoken=".$_GET["commissions_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_commissions_btn." ".$cancel_del_commissions_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_commissions_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletecommissions"]))
      {
         $gwauthenticate_commissions_=gw_oauth("table", magic_current_url(), "commissions", "super_delete_confirm","");

         $gwauthenticate_commissions_json=json_decode($gwauthenticate_commissions_, true);
         	
          //echo $gwauthenticate_commissions_;

         if($gwauthenticate_commissions_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $commissions_del_key_salt=initialize_commissions()["commission_id"];
      mosy_sql_rollback("commissions", "primkey='$commissions_uptoken'", "DELETE");
      drop_commissions("primkey='$commissions_uptoken' and commission_id='$commissions_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_commissions_);

      }
      }

      //== End commissions delete record  
    
       ///SELECT STRING FOR commissions============================
              
       if(isset($_POST["qcommissions_btn"])){
         $gwauthenticate_commissions_=gw_oauth("table", magic_current_url(), "commissions", "qcommissions_btn","");

         $gwauthenticate_commissions_json=json_decode($gwauthenticate_commissions_, true);
         	
          //echo $gwauthenticate_commissions_;

         if($gwauthenticate_commissions_json["response"]=="ok")
         {
            $current_commissions_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_commissions_current_url=$current_commissions_url_params.'?qcommissions=';
            if (strpos($current_commissions_url_params, '?') !== false) {

                $clean_commissions_current_url=$current_commissions_url_params.'&qcommissions=';

            }
            if (strpos($current_commissions_url_params, '?qcommissions')) {

                $remove_commissions_old_token = substr($current_commissions_url_params, 0, strpos($current_commissions_url_params, "?qcommissions"));

                $clean_commissions_current_url=$remove_commissions_old_token.'?qcommissions=';

            }
            if(strpos($current_commissions_url_params, '&qcommissions')) {

                $remove_commissions_old_token = substr($current_commissions_url_params, 0, strpos($current_commissions_url_params, "&qcommissions"));

                $clean_commissions_current_url=$remove_commissions_old_token.'&qcommissions=';

            }
        $qcommissions_str=base64_encode($_POST["txt_commissions"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_commissions_current_url.($qcommissions_str);
            } 

          }else{ 
             header('location:'.$clean_commissions_current_url.($qcommissions_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_commissions_);

        }
        }
        $qcommissions="";
		if(isset($_GET["commissions_mosyfilter"]) && isset($_GET["qcommissions"])){
         $gwauthenticate_commissions_=gw_oauth("table", magic_current_url(), "commissions", "commissions_mosyfilter_n_query","");

         $gwauthenticate_commissions_json=json_decode($gwauthenticate_commissions_, true);
         	
          //echo $gwauthenticate_commissions_;

         if($gwauthenticate_commissions_json["response"]=="ok")
         {
         $qcommissions=mmres(base64_decode($_GET["qcommissions"]));
         
         $gft_commissions_where_query="(`commission_id` LIKE '%".$qcommissions."%' OR  `commission_name` LIKE '%".$qcommissions."%' OR  `amount` LIKE '%".$qcommissions."%' OR  `staff_id` LIKE '%".$qcommissions."%' OR  `remark` LIKE '%".$qcommissions."%' OR  `active_state` LIKE '%".$qcommissions."%' OR  `owner` LIKE '%".$qcommissions."%')";
         
         if($_GET["commissions_mosyfilter"]!=""){
         
         $mosyfilter_commissions_queries_str=(base64_decode($_GET["commissions_mosyfilter"]));
        
         $gft_commissions_where_query="(`commission_id` LIKE '%".$qcommissions."%' OR  `commission_name` LIKE '%".$qcommissions."%' OR  `amount` LIKE '%".$qcommissions."%' OR  `staff_id` LIKE '%".$qcommissions."%' OR  `remark` LIKE '%".$qcommissions."%' OR  `active_state` LIKE '%".$qcommissions."%' OR  `owner` LIKE '%".$qcommissions."%') AND ".$mosyfilter_commissions_queries_str."";
         
         }
         
		 $gft_commissions="WHERE ".$gft_commissions_where_query;
         
         $gft_commissions_and=$gft_commissions_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_commissions_);
        }
        }elseif(isset($_GET["qcommissions"])){
         $gwauthenticate_commissions_=gw_oauth("table", magic_current_url(), "commissions", "get_qcommissions","");

         $gwauthenticate_commissions_json=json_decode($gwauthenticate_commissions_, true);
         	
          //echo $gwauthenticate_commissions_;

         if($gwauthenticate_commissions_json["response"]=="ok")
         {
		 $qcommissions=mmres(base64_decode($_GET["qcommissions"]));
        
         $gft_commissions_where_query="(`commission_id` LIKE '%".$qcommissions."%' OR  `commission_name` LIKE '%".$qcommissions."%' OR  `amount` LIKE '%".$qcommissions."%' OR  `staff_id` LIKE '%".$qcommissions."%' OR  `remark` LIKE '%".$qcommissions."%' OR  `active_state` LIKE '%".$qcommissions."%' OR  `owner` LIKE '%".$qcommissions."%')";
         
         $gft_commissions="WHERE ".$gft_commissions_where_query;
         
         $gft_commissions_and=$gft_commissions_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_commissions_);

        }
        }elseif(isset($_GET["commissions_mosyfilter"])){
         $gwauthenticate_commissions_=gw_oauth("table", magic_current_url(), "commissions", "commissions_mosyfilter","");

         $gwauthenticate_commissions_json=json_decode($gwauthenticate_commissions_, true);
         	
          //echo $gwauthenticate_commissions_;

         if($gwauthenticate_commissions_json["response"]=="ok")
         {
         $gft_commissions_where_query="";
         $gft_commissions="";

         if($_GET["commissions_mosyfilter"]!=""){
          $gft_commissions_where_query=(base64_decode($_GET["commissions_mosyfilter"]));
          $gft_commissions="WHERE ".$gft_commissions_where_query;
         }
         
         
         $gft_commissions_and=$gft_commissions_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_commissions_);

        }
        }else{
         $gft_commissions="";
         $gft_commissions_and="";
         $gft_commissions_where_query="";
        }
       
    //************************************************* END  commissions OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section deductions
  //************************************************* START  deductions OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize deductions edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['deductions_table_alert']))
              	{	
                  if(isset($deductions_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$deductions_uptoken="";

		if(isset($_GET["deductions_uptoken"]))
		{
		$deductions_uptoken=base64_decode($_GET["deductions_uptoken"]);
		}
        
        if(isset($_POST["deductions_uptoken"]))
		{
		$deductions_uptoken=base64_decode($_POST["deductions_uptoken"]);
		}
        //
        
          $deductions_alias_name="DEDUCTIONS";

          if(isset($deductions_alias))
          {
             $deductions_alias_name=$deductions_alias;

          }
          
        //get single data record query with $deductions_uptoken
        
        ///$deductions_node=get_deductions("*", "WHERE primkey='$deductions_uptoken'", "r");
        
	
//************* START INSERT  deductions QUERY 
if(isset($_POST["deductions_insert_btn"])){
//------- begin deductions_arr_ins --> 
$deductions_arr_ins_=array(

"primkey"=>"NULL",
"deduction_id"=>magic_random_str(7),
"deduction_title"=>"?",
"amount"=>"?",
"staff_id"=>"?",
"remark"=>"?",
"owner"=>"?",
"active_state"=>"?"

);
//===-- End deductions_arr_ins -->


          
         $gwauthenticate_deductions_=gw_oauth("table", magic_current_url(), "deductions", "insert","");

         $gwauthenticate_deductions_json=json_decode($gwauthenticate_deductions_, true);
         	
          //echo $gwauthenticate_deductions_;

         if($gwauthenticate_deductions_json["response"]=="ok")
         {

              $deductions_validated_ins_str=$deductions_arr_ins_;

              if(isset($deductions_ins_inputs))
              {
                $deductions_validated_ins_str=$deductions_ins_inputs;	
              }

              if(empty($deductions_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$deductions_alias_name." request cannot be empty. Record not added");
              }else{

                $deductions_return_key=add_deductions($deductions_validated_ins_str);
                
                mosy_sql_rollback("deductions", "primkey='$deductions_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $deductions_return_key; 

                      } 

                    }else{ 

                                    
                $deductions_custom_redir1=add_url_param ("deductions_uptoken", base64_encode($deductions_return_key), "");
                $deductions_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$deductions_custom_redir1);
                $deductions_custom_redir3=add_url_param ("deductions_table_alert", "deductions_added",$deductions_custom_redir2);
                
                ///echo magic_message($deductions_custom_redir1." -- ".$deductions_custom_redir2."--".$deductions_custom_redir3);
                
                $deductions_custom_redir=$deductions_custom_redir3;
                
               header('location:'.$deductions_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_deductions_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_deductions_)."");
         
         }
      
}
//************* END  deductions INSERT QUERY 	
	

//************* START deductions  UPDATE QUERY 
if(isset($_POST["deductions_update_btn"])){
//------- begin deductions_arr_updt --> 
$deductions_arr_updt_=array(
"deduction_title"=>"?",
"amount"=>"?",
"staff_id"=>"?",
"remark"=>"?",
"owner"=>"?",
"active_state"=>"?"

);
//===-- End deductions_arr_updt -->
                     
         $gwauthenticate_deductions_=gw_oauth("table", magic_current_url(), "deductions", "update","");

         $gwauthenticate_deductions_json=json_decode($gwauthenticate_deductions_, true);
         	
          //echo $gwauthenticate_deductions_;

         if($gwauthenticate_deductions_json["response"]=="ok")
         {
         
            $deductions_validated_updt_str=$deductions_arr_updt_;

            if(isset($deductions_updt_inputs))
            {
              $deductions_validated_updt_str=$deductions_updt_inputs;	
            }

            if(empty($deductions_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$deductions_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$deductions_key_salt=initialize_deductions()["deduction_id"];
            
              update_deductions($deductions_validated_updt_str, "primkey='$deductions_uptoken' and deduction_id='$deductions_key_salt'");
				

			 mosy_sql_rollback("deductions", "primkey='$deductions_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $deductions_uptoken; 

                    } 

                  }else{ 

                $deductions_custom_redir1=add_url_param ("deductions_uptoken", base64_encode($deductions_uptoken), "");
                $deductions_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$deductions_custom_redir1);
                $deductions_custom_redir3=add_url_param ("deductions_table_alert", "deductions_updated",$deductions_custom_redir2);
                
                ///echo magic_message($deductions_custom_redir1." -- ".$deductions_custom_redir2."--".$deductions_custom_redir3);
                
                $deductions_custom_redir=$deductions_custom_redir3;
                
               header('location:'.$deductions_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_deductions_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_deductions_)."");
         
         }

      

      
}
//************* END deductions  UPDATE QUERY 

    
    
      //== Start deductions delete record

      if(isset($_GET["deletedeductions"]))
      {
         $gwauthenticate_deductions_=gw_oauth("table", magic_current_url(), "deductions", "super_delete_request","");

         $gwauthenticate_deductions_json=json_decode($gwauthenticate_deductions_, true);
         	
          //echo $gwauthenticate_deductions_;

         if($gwauthenticate_deductions_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_deductions_btn=magic_button_link("./".$current_file_url."?deductions_uptoken=".$_GET["deductions_uptoken"]."&conf_deletedeductions&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_deductions_btn=magic_button_link("./".$current_file_url."?deductions_uptoken=".$_GET["deductions_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_deductions_btn." ".$cancel_del_deductions_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_deductions_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletedeductions"]))
      {
         $gwauthenticate_deductions_=gw_oauth("table", magic_current_url(), "deductions", "super_delete_confirm","");

         $gwauthenticate_deductions_json=json_decode($gwauthenticate_deductions_, true);
         	
          //echo $gwauthenticate_deductions_;

         if($gwauthenticate_deductions_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $deductions_del_key_salt=initialize_deductions()["deduction_id"];
      mosy_sql_rollback("deductions", "primkey='$deductions_uptoken'", "DELETE");
      drop_deductions("primkey='$deductions_uptoken' and deduction_id='$deductions_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_deductions_);

      }
      }

      //== End deductions delete record  
    
       ///SELECT STRING FOR deductions============================
              
       if(isset($_POST["qdeductions_btn"])){
         $gwauthenticate_deductions_=gw_oauth("table", magic_current_url(), "deductions", "qdeductions_btn","");

         $gwauthenticate_deductions_json=json_decode($gwauthenticate_deductions_, true);
         	
          //echo $gwauthenticate_deductions_;

         if($gwauthenticate_deductions_json["response"]=="ok")
         {
            $current_deductions_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_deductions_current_url=$current_deductions_url_params.'?qdeductions=';
            if (strpos($current_deductions_url_params, '?') !== false) {

                $clean_deductions_current_url=$current_deductions_url_params.'&qdeductions=';

            }
            if (strpos($current_deductions_url_params, '?qdeductions')) {

                $remove_deductions_old_token = substr($current_deductions_url_params, 0, strpos($current_deductions_url_params, "?qdeductions"));

                $clean_deductions_current_url=$remove_deductions_old_token.'?qdeductions=';

            }
            if(strpos($current_deductions_url_params, '&qdeductions')) {

                $remove_deductions_old_token = substr($current_deductions_url_params, 0, strpos($current_deductions_url_params, "&qdeductions"));

                $clean_deductions_current_url=$remove_deductions_old_token.'&qdeductions=';

            }
        $qdeductions_str=base64_encode($_POST["txt_deductions"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_deductions_current_url.($qdeductions_str);
            } 

          }else{ 
             header('location:'.$clean_deductions_current_url.($qdeductions_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_deductions_);

        }
        }
        $qdeductions="";
		if(isset($_GET["deductions_mosyfilter"]) && isset($_GET["qdeductions"])){
         $gwauthenticate_deductions_=gw_oauth("table", magic_current_url(), "deductions", "deductions_mosyfilter_n_query","");

         $gwauthenticate_deductions_json=json_decode($gwauthenticate_deductions_, true);
         	
          //echo $gwauthenticate_deductions_;

         if($gwauthenticate_deductions_json["response"]=="ok")
         {
         $qdeductions=mmres(base64_decode($_GET["qdeductions"]));
         
         $gft_deductions_where_query="(`deduction_id` LIKE '%".$qdeductions."%' OR  `deduction_title` LIKE '%".$qdeductions."%' OR  `amount` LIKE '%".$qdeductions."%' OR  `staff_id` LIKE '%".$qdeductions."%' OR  `remark` LIKE '%".$qdeductions."%' OR  `owner` LIKE '%".$qdeductions."%' OR  `active_state` LIKE '%".$qdeductions."%')";
         
         if($_GET["deductions_mosyfilter"]!=""){
         
         $mosyfilter_deductions_queries_str=(base64_decode($_GET["deductions_mosyfilter"]));
        
         $gft_deductions_where_query="(`deduction_id` LIKE '%".$qdeductions."%' OR  `deduction_title` LIKE '%".$qdeductions."%' OR  `amount` LIKE '%".$qdeductions."%' OR  `staff_id` LIKE '%".$qdeductions."%' OR  `remark` LIKE '%".$qdeductions."%' OR  `owner` LIKE '%".$qdeductions."%' OR  `active_state` LIKE '%".$qdeductions."%') AND ".$mosyfilter_deductions_queries_str."";
         
         }
         
		 $gft_deductions="WHERE ".$gft_deductions_where_query;
         
         $gft_deductions_and=$gft_deductions_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_deductions_);
        }
        }elseif(isset($_GET["qdeductions"])){
         $gwauthenticate_deductions_=gw_oauth("table", magic_current_url(), "deductions", "get_qdeductions","");

         $gwauthenticate_deductions_json=json_decode($gwauthenticate_deductions_, true);
         	
          //echo $gwauthenticate_deductions_;

         if($gwauthenticate_deductions_json["response"]=="ok")
         {
		 $qdeductions=mmres(base64_decode($_GET["qdeductions"]));
        
         $gft_deductions_where_query="(`deduction_id` LIKE '%".$qdeductions."%' OR  `deduction_title` LIKE '%".$qdeductions."%' OR  `amount` LIKE '%".$qdeductions."%' OR  `staff_id` LIKE '%".$qdeductions."%' OR  `remark` LIKE '%".$qdeductions."%' OR  `owner` LIKE '%".$qdeductions."%' OR  `active_state` LIKE '%".$qdeductions."%')";
         
         $gft_deductions="WHERE ".$gft_deductions_where_query;
         
         $gft_deductions_and=$gft_deductions_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_deductions_);

        }
        }elseif(isset($_GET["deductions_mosyfilter"])){
         $gwauthenticate_deductions_=gw_oauth("table", magic_current_url(), "deductions", "deductions_mosyfilter","");

         $gwauthenticate_deductions_json=json_decode($gwauthenticate_deductions_, true);
         	
          //echo $gwauthenticate_deductions_;

         if($gwauthenticate_deductions_json["response"]=="ok")
         {
         $gft_deductions_where_query="";
         $gft_deductions="";

         if($_GET["deductions_mosyfilter"]!=""){
          $gft_deductions_where_query=(base64_decode($_GET["deductions_mosyfilter"]));
          $gft_deductions="WHERE ".$gft_deductions_where_query;
         }
         
         
         $gft_deductions_and=$gft_deductions_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_deductions_);

        }
        }else{
         $gft_deductions="";
         $gft_deductions_and="";
         $gft_deductions_where_query="";
        }
       
    //************************************************* END  deductions OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section employee_loans
  //************************************************* START  employee_loans OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize employee_loans edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['employee_loans_table_alert']))
              	{	
                  if(isset($employee_loans_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$employee_loans_uptoken="";

		if(isset($_GET["employee_loans_uptoken"]))
		{
		$employee_loans_uptoken=base64_decode($_GET["employee_loans_uptoken"]);
		}
        
        if(isset($_POST["employee_loans_uptoken"]))
		{
		$employee_loans_uptoken=base64_decode($_POST["employee_loans_uptoken"]);
		}
        //
        
          $employee_loans_alias_name="EMPLOYEE LOANS";

          if(isset($employee_loans_alias))
          {
             $employee_loans_alias_name=$employee_loans_alias;

          }
          
        //get single data record query with $employee_loans_uptoken
        
        ///$employee_loans_node=get_employee_loans("*", "WHERE primkey='$employee_loans_uptoken'", "r");
        
	
//************* START INSERT  employee_loans QUERY 
if(isset($_POST["employee_loans_insert_btn"])){
//------- begin employee_loans_arr_ins --> 
$employee_loans_arr_ins_=array(

"primkey"=>"NULL",
"loan_id"=>magic_random_str(7),
"loan_name"=>"?",
"loan_number"=>"?",
"date_applied"=>"?",
"date_issued"=>"?",
"principal_amount"=>"?",
"interest_amount"=>"?",
"princ_plus_int"=>"?",
"monthly_installment"=>"?",
"interest_formulae"=>"?",
"active_status"=>"?",
"staff_id"=>"?",
"owner"=>"?",
"remark"=>"?"

);
//===-- End employee_loans_arr_ins -->


          
         $gwauthenticate_employee_loans_=gw_oauth("table", magic_current_url(), "employee_loans", "insert","");

         $gwauthenticate_employee_loans_json=json_decode($gwauthenticate_employee_loans_, true);
         	
          //echo $gwauthenticate_employee_loans_;

         if($gwauthenticate_employee_loans_json["response"]=="ok")
         {

              $employee_loans_validated_ins_str=$employee_loans_arr_ins_;

              if(isset($employee_loans_ins_inputs))
              {
                $employee_loans_validated_ins_str=$employee_loans_ins_inputs;	
              }

              if(empty($employee_loans_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$employee_loans_alias_name." request cannot be empty. Record not added");
              }else{

                $employee_loans_return_key=add_employee_loans($employee_loans_validated_ins_str);
                
                mosy_sql_rollback("employee_loans", "primkey='$employee_loans_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $employee_loans_return_key; 

                      } 

                    }else{ 

                                    
                $employee_loans_custom_redir1=add_url_param ("employee_loans_uptoken", base64_encode($employee_loans_return_key), "");
                $employee_loans_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$employee_loans_custom_redir1);
                $employee_loans_custom_redir3=add_url_param ("employee_loans_table_alert", "employee_loans_added",$employee_loans_custom_redir2);
                
                ///echo magic_message($employee_loans_custom_redir1." -- ".$employee_loans_custom_redir2."--".$employee_loans_custom_redir3);
                
                $employee_loans_custom_redir=$employee_loans_custom_redir3;
                
               header('location:'.$employee_loans_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_employee_loans_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employee_loans_)."");
         
         }
      
}
//************* END  employee_loans INSERT QUERY 	
	

//************* START employee_loans  UPDATE QUERY 
if(isset($_POST["employee_loans_update_btn"])){
//------- begin employee_loans_arr_updt --> 
$employee_loans_arr_updt_=array(
"loan_name"=>"?",
"loan_number"=>"?",
"date_applied"=>"?",
"date_issued"=>"?",
"principal_amount"=>"?",
"interest_amount"=>"?",
"princ_plus_int"=>"?",
"monthly_installment"=>"?",
"interest_formulae"=>"?",
"active_status"=>"?",
"staff_id"=>"?",
"owner"=>"?",
"remark"=>"?"

);
//===-- End employee_loans_arr_updt -->
                     
         $gwauthenticate_employee_loans_=gw_oauth("table", magic_current_url(), "employee_loans", "update","");

         $gwauthenticate_employee_loans_json=json_decode($gwauthenticate_employee_loans_, true);
         	
          //echo $gwauthenticate_employee_loans_;

         if($gwauthenticate_employee_loans_json["response"]=="ok")
         {
         
            $employee_loans_validated_updt_str=$employee_loans_arr_updt_;

            if(isset($employee_loans_updt_inputs))
            {
              $employee_loans_validated_updt_str=$employee_loans_updt_inputs;	
            }

            if(empty($employee_loans_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$employee_loans_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$employee_loans_key_salt=initialize_employee_loans()["loan_id"];
            
              update_employee_loans($employee_loans_validated_updt_str, "primkey='$employee_loans_uptoken' and loan_id='$employee_loans_key_salt'");
				

			 mosy_sql_rollback("employee_loans", "primkey='$employee_loans_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $employee_loans_uptoken; 

                    } 

                  }else{ 

                $employee_loans_custom_redir1=add_url_param ("employee_loans_uptoken", base64_encode($employee_loans_uptoken), "");
                $employee_loans_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$employee_loans_custom_redir1);
                $employee_loans_custom_redir3=add_url_param ("employee_loans_table_alert", "employee_loans_updated",$employee_loans_custom_redir2);
                
                ///echo magic_message($employee_loans_custom_redir1." -- ".$employee_loans_custom_redir2."--".$employee_loans_custom_redir3);
                
                $employee_loans_custom_redir=$employee_loans_custom_redir3;
                
               header('location:'.$employee_loans_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_employee_loans_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employee_loans_)."");
         
         }

      

      
}
//************* END employee_loans  UPDATE QUERY 

    
    
      //== Start employee_loans delete record

      if(isset($_GET["deleteemployee_loans"]))
      {
         $gwauthenticate_employee_loans_=gw_oauth("table", magic_current_url(), "employee_loans", "super_delete_request","");

         $gwauthenticate_employee_loans_json=json_decode($gwauthenticate_employee_loans_, true);
         	
          //echo $gwauthenticate_employee_loans_;

         if($gwauthenticate_employee_loans_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_employee_loans_btn=magic_button_link("./".$current_file_url."?employee_loans_uptoken=".$_GET["employee_loans_uptoken"]."&conf_deleteemployee_loans&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_employee_loans_btn=magic_button_link("./".$current_file_url."?employee_loans_uptoken=".$_GET["employee_loans_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_employee_loans_btn." ".$cancel_del_employee_loans_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_employee_loans_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteemployee_loans"]))
      {
         $gwauthenticate_employee_loans_=gw_oauth("table", magic_current_url(), "employee_loans", "super_delete_confirm","");

         $gwauthenticate_employee_loans_json=json_decode($gwauthenticate_employee_loans_, true);
         	
          //echo $gwauthenticate_employee_loans_;

         if($gwauthenticate_employee_loans_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $employee_loans_del_key_salt=initialize_employee_loans()["loan_id"];
      mosy_sql_rollback("employee_loans", "primkey='$employee_loans_uptoken'", "DELETE");
      drop_employee_loans("primkey='$employee_loans_uptoken' and loan_id='$employee_loans_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_employee_loans_);

      }
      }

      //== End employee_loans delete record  
    
       ///SELECT STRING FOR employee_loans============================
              
       if(isset($_POST["qemployee_loans_btn"])){
         $gwauthenticate_employee_loans_=gw_oauth("table", magic_current_url(), "employee_loans", "qemployee_loans_btn","");

         $gwauthenticate_employee_loans_json=json_decode($gwauthenticate_employee_loans_, true);
         	
          //echo $gwauthenticate_employee_loans_;

         if($gwauthenticate_employee_loans_json["response"]=="ok")
         {
            $current_employee_loans_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_employee_loans_current_url=$current_employee_loans_url_params.'?qemployee_loans=';
            if (strpos($current_employee_loans_url_params, '?') !== false) {

                $clean_employee_loans_current_url=$current_employee_loans_url_params.'&qemployee_loans=';

            }
            if (strpos($current_employee_loans_url_params, '?qemployee_loans')) {

                $remove_employee_loans_old_token = substr($current_employee_loans_url_params, 0, strpos($current_employee_loans_url_params, "?qemployee_loans"));

                $clean_employee_loans_current_url=$remove_employee_loans_old_token.'?qemployee_loans=';

            }
            if(strpos($current_employee_loans_url_params, '&qemployee_loans')) {

                $remove_employee_loans_old_token = substr($current_employee_loans_url_params, 0, strpos($current_employee_loans_url_params, "&qemployee_loans"));

                $clean_employee_loans_current_url=$remove_employee_loans_old_token.'&qemployee_loans=';

            }
        $qemployee_loans_str=base64_encode($_POST["txt_employee_loans"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_employee_loans_current_url.($qemployee_loans_str);
            } 

          }else{ 
             header('location:'.$clean_employee_loans_current_url.($qemployee_loans_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_employee_loans_);

        }
        }
        $qemployee_loans="";
		if(isset($_GET["employee_loans_mosyfilter"]) && isset($_GET["qemployee_loans"])){
         $gwauthenticate_employee_loans_=gw_oauth("table", magic_current_url(), "employee_loans", "employee_loans_mosyfilter_n_query","");

         $gwauthenticate_employee_loans_json=json_decode($gwauthenticate_employee_loans_, true);
         	
          //echo $gwauthenticate_employee_loans_;

         if($gwauthenticate_employee_loans_json["response"]=="ok")
         {
         $qemployee_loans=mmres(base64_decode($_GET["qemployee_loans"]));
         
         $gft_employee_loans_where_query="(`loan_id` LIKE '%".$qemployee_loans."%' OR  `loan_name` LIKE '%".$qemployee_loans."%' OR  `loan_number` LIKE '%".$qemployee_loans."%' OR  `date_applied` LIKE '%".$qemployee_loans."%' OR  `date_issued` LIKE '%".$qemployee_loans."%' OR  `principal_amount` LIKE '%".$qemployee_loans."%' OR  `interest_amount` LIKE '%".$qemployee_loans."%' OR  `princ_plus_int` LIKE '%".$qemployee_loans."%' OR  `monthly_installment` LIKE '%".$qemployee_loans."%' OR  `interest_formulae` LIKE '%".$qemployee_loans."%' OR  `active_status` LIKE '%".$qemployee_loans."%' OR  `staff_id` LIKE '%".$qemployee_loans."%' OR  `owner` LIKE '%".$qemployee_loans."%' OR  `remark` LIKE '%".$qemployee_loans."%')";
         
         if($_GET["employee_loans_mosyfilter"]!=""){
         
         $mosyfilter_employee_loans_queries_str=(base64_decode($_GET["employee_loans_mosyfilter"]));
        
         $gft_employee_loans_where_query="(`loan_id` LIKE '%".$qemployee_loans."%' OR  `loan_name` LIKE '%".$qemployee_loans."%' OR  `loan_number` LIKE '%".$qemployee_loans."%' OR  `date_applied` LIKE '%".$qemployee_loans."%' OR  `date_issued` LIKE '%".$qemployee_loans."%' OR  `principal_amount` LIKE '%".$qemployee_loans."%' OR  `interest_amount` LIKE '%".$qemployee_loans."%' OR  `princ_plus_int` LIKE '%".$qemployee_loans."%' OR  `monthly_installment` LIKE '%".$qemployee_loans."%' OR  `interest_formulae` LIKE '%".$qemployee_loans."%' OR  `active_status` LIKE '%".$qemployee_loans."%' OR  `staff_id` LIKE '%".$qemployee_loans."%' OR  `owner` LIKE '%".$qemployee_loans."%' OR  `remark` LIKE '%".$qemployee_loans."%') AND ".$mosyfilter_employee_loans_queries_str."";
         
         }
         
		 $gft_employee_loans="WHERE ".$gft_employee_loans_where_query;
         
         $gft_employee_loans_and=$gft_employee_loans_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_employee_loans_);
        }
        }elseif(isset($_GET["qemployee_loans"])){
         $gwauthenticate_employee_loans_=gw_oauth("table", magic_current_url(), "employee_loans", "get_qemployee_loans","");

         $gwauthenticate_employee_loans_json=json_decode($gwauthenticate_employee_loans_, true);
         	
          //echo $gwauthenticate_employee_loans_;

         if($gwauthenticate_employee_loans_json["response"]=="ok")
         {
		 $qemployee_loans=mmres(base64_decode($_GET["qemployee_loans"]));
        
         $gft_employee_loans_where_query="(`loan_id` LIKE '%".$qemployee_loans."%' OR  `loan_name` LIKE '%".$qemployee_loans."%' OR  `loan_number` LIKE '%".$qemployee_loans."%' OR  `date_applied` LIKE '%".$qemployee_loans."%' OR  `date_issued` LIKE '%".$qemployee_loans."%' OR  `principal_amount` LIKE '%".$qemployee_loans."%' OR  `interest_amount` LIKE '%".$qemployee_loans."%' OR  `princ_plus_int` LIKE '%".$qemployee_loans."%' OR  `monthly_installment` LIKE '%".$qemployee_loans."%' OR  `interest_formulae` LIKE '%".$qemployee_loans."%' OR  `active_status` LIKE '%".$qemployee_loans."%' OR  `staff_id` LIKE '%".$qemployee_loans."%' OR  `owner` LIKE '%".$qemployee_loans."%' OR  `remark` LIKE '%".$qemployee_loans."%')";
         
         $gft_employee_loans="WHERE ".$gft_employee_loans_where_query;
         
         $gft_employee_loans_and=$gft_employee_loans_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_employee_loans_);

        }
        }elseif(isset($_GET["employee_loans_mosyfilter"])){
         $gwauthenticate_employee_loans_=gw_oauth("table", magic_current_url(), "employee_loans", "employee_loans_mosyfilter","");

         $gwauthenticate_employee_loans_json=json_decode($gwauthenticate_employee_loans_, true);
         	
          //echo $gwauthenticate_employee_loans_;

         if($gwauthenticate_employee_loans_json["response"]=="ok")
         {
         $gft_employee_loans_where_query="";
         $gft_employee_loans="";

         if($_GET["employee_loans_mosyfilter"]!=""){
          $gft_employee_loans_where_query=(base64_decode($_GET["employee_loans_mosyfilter"]));
          $gft_employee_loans="WHERE ".$gft_employee_loans_where_query;
         }
         
         
         $gft_employee_loans_and=$gft_employee_loans_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_employee_loans_);

        }
        }else{
         $gft_employee_loans="";
         $gft_employee_loans_and="";
         $gft_employee_loans_where_query="";
        }
       
    //************************************************* END  employee_loans OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section employees
  //************************************************* START  employees OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize employees edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['employees_table_alert']))
              	{	
                  if(isset($employees_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$employees_uptoken="";

		if(isset($_GET["employees_uptoken"]))
		{
		$employees_uptoken=base64_decode($_GET["employees_uptoken"]);
		}
        
        if(isset($_POST["employees_uptoken"]))
		{
		$employees_uptoken=base64_decode($_POST["employees_uptoken"]);
		}
        //
        
          $employees_alias_name="EMPLOYEES";

          if(isset($employees_alias))
          {
             $employees_alias_name=$employees_alias;

          }
          
        //get single data record query with $employees_uptoken
        
        ///$employees_node=get_employees("*", "WHERE primkey='$employees_uptoken'", "r");
        
	
//************* START INSERT  employees QUERY 
if(isset($_POST["employees_insert_btn"])){
//------- begin employees_arr_ins --> 
$employees_arr_ins_=array(

"primkey"=>"NULL",
"user_id"=>magic_random_str(7),
"name"=>"?",
"email"=>"?",
"tel"=>"?",
"job_group"=>"?",
"nssf_no"=>"?",
"nhif_no"=>"?",
"pin_no"=>"?",
"national_id"=>"?",
"contract_start_date"=>"?",
"contract_end_date"=>"?",
"staff_number"=>"?",
"passport_photo"=>"?",
"gender"=>"?",
"job_title"=>"?",
"departments"=>"?",
"head_of"=>"?",
"reports_to"=>"?",
"about"=>"?",
"owner"=>"?",
"employement_date"=>"?",
"country"=>"?",
"city"=>"?",
"town"=>"?",
"date_of_birth"=>"?",
"job_group_letter"=>"?",
"job_group_salary"=>"?",
"job_group_type"=>"?"

);
//===-- End employees_arr_ins -->


          
         $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "insert","");

         $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
         	
          //echo $gwauthenticate_employees_;

         if($gwauthenticate_employees_json["response"]=="ok")
         {

              $employees_validated_ins_str=$employees_arr_ins_;

              if(isset($employees_ins_inputs))
              {
                $employees_validated_ins_str=$employees_ins_inputs;	
              }

              if(empty($employees_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$employees_alias_name." request cannot be empty. Record not added");
              }else{

                $employees_return_key=add_employees($employees_validated_ins_str);
                
                mosy_sql_rollback("employees", "primkey='$employees_return_key'", "INSERT");
					
         
                if(!empty($_FILES['txt_employees_passport_photo']['tmp_name']))
                {
                
                 upload_employees_passport_photo('txt_employees_passport_photo', "primkey='$employees_return_key'");
                 
				}
                
         
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $employees_return_key; 

                      } 

                    }else{ 

                                    
                $employees_custom_redir1=add_url_param ("employees_uptoken", base64_encode($employees_return_key), "");
                $employees_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$employees_custom_redir1);
                $employees_custom_redir3=add_url_param ("employees_table_alert", "employees_added",$employees_custom_redir2);
                
                ///echo magic_message($employees_custom_redir1." -- ".$employees_custom_redir2."--".$employees_custom_redir3);
                
                $employees_custom_redir=$employees_custom_redir3;
                
               header('location:'.$employees_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_employees_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_)."");
         
         }
      
}
//************* END  employees INSERT QUERY 	
	

//************* START employees  UPDATE QUERY 
if(isset($_POST["employees_update_btn"])){
//------- begin employees_arr_updt --> 
$employees_arr_updt_=array(
"name"=>"?",
"email"=>"?",
"tel"=>"?",
"job_group"=>"?",
"nssf_no"=>"?",
"nhif_no"=>"?",
"pin_no"=>"?",
"national_id"=>"?",
"contract_start_date"=>"?",
"contract_end_date"=>"?",
"staff_number"=>"?",
"passport_photo"=>"?",
"gender"=>"?",
"job_title"=>"?",
"departments"=>"?",
"head_of"=>"?",
"reports_to"=>"?",
"about"=>"?",
"owner"=>"?",
"employement_date"=>"?",
"country"=>"?",
"city"=>"?",
"town"=>"?",
"date_of_birth"=>"?",
"job_group_letter"=>"?",
"job_group_salary"=>"?",
"job_group_type"=>"?"

);
//===-- End employees_arr_updt -->
                     
         $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "update","");

         $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
         	
          //echo $gwauthenticate_employees_;

         if($gwauthenticate_employees_json["response"]=="ok")
         {
         
            $employees_validated_updt_str=$employees_arr_updt_;

            if(isset($employees_updt_inputs))
            {
              $employees_validated_updt_str=$employees_updt_inputs;	
            }

            if(empty($employees_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$employees_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$employees_key_salt=initialize_employees()["user_id"];
            
              update_employees($employees_validated_updt_str, "primkey='$employees_uptoken' and user_id='$employees_key_salt'");
				
         
                if(!empty($_FILES['txt_employees_passport_photo']['tmp_name']))
                {
                
                 upload_employees_passport_photo('txt_employees_passport_photo', "primkey='$employees_uptoken'");
                 
				}

			 mosy_sql_rollback("employees", "primkey='$employees_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $employees_uptoken; 

                    } 

                  }else{ 

                $employees_custom_redir1=add_url_param ("employees_uptoken", base64_encode($employees_uptoken), "");
                $employees_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$employees_custom_redir1);
                $employees_custom_redir3=add_url_param ("employees_table_alert", "employees_updated",$employees_custom_redir2);
                
                ///echo magic_message($employees_custom_redir1." -- ".$employees_custom_redir2."--".$employees_custom_redir3);
                
                $employees_custom_redir=$employees_custom_redir3;
                
               header('location:'.$employees_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_employees_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_)."");
         
         }

      

      
}
//************* END employees  UPDATE QUERY 

    

          //===-====Start upload employees_passport_photo 
          if(isset($_POST["btn_upload_employees_passport_photo"]))
          {
         $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "upload_employees_passport_photo","");

         $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
         	
          //echo $gwauthenticate_employees_;

         if($gwauthenticate_employees_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_employees_passport_photo']['tmp_name'])){

				upload_employees_passport_photo('txt_employees_passport_photo', "primkey='$employees_uptoken'");
                
                $employees_custom_redir1=add_url_param ("employees_uptoken", base64_encode($employees_uptoken), "");
                $employees_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$employees_custom_redir1);
                $employees_custom_redir3=add_url_param ("employees_table_alert", "employees_uploaded",$employees_custom_redir2);
                
                ///echo magic_message($employees_custom_redir1." -- ".$employees_custom_redir2."--".$employees_custom_redir3);
                
                $employees_custom_redir=$employees_custom_redir3;
                
               header('location:'.$employees_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_employees_);

          }
          }
          //===-====End upload employees_passport_photo  

			//drop employees_passport_photo image 
            
          if(isset($_GET["conf_deleteemployees"]))
          {
          	$employees_node=initialize_employees();
          	if($employees_node["passport_photo"]!="")
            {
          	 unlink($employees_node["passport_photo"]);
            }
          }
          
          
    
      //== Start employees delete record

      if(isset($_GET["deleteemployees"]))
      {
         $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "super_delete_request","");

         $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
         	
          //echo $gwauthenticate_employees_;

         if($gwauthenticate_employees_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_employees_btn=magic_button_link("./".$current_file_url."?employees_uptoken=".$_GET["employees_uptoken"]."&conf_deleteemployees&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_employees_btn=magic_button_link("./".$current_file_url."?employees_uptoken=".$_GET["employees_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_employees_btn." ".$cancel_del_employees_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_employees_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteemployees"]))
      {
         $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "super_delete_confirm","");

         $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
         	
          //echo $gwauthenticate_employees_;

         if($gwauthenticate_employees_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $employees_del_key_salt=initialize_employees()["user_id"];
      mosy_sql_rollback("employees", "primkey='$employees_uptoken'", "DELETE");
      drop_employees("primkey='$employees_uptoken' and user_id='$employees_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_employees_);

      }
      }

      //== End employees delete record  
    
       ///SELECT STRING FOR employees============================
              
       if(isset($_POST["qemployees_btn"])){
         $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "qemployees_btn","");

         $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
         	
          //echo $gwauthenticate_employees_;

         if($gwauthenticate_employees_json["response"]=="ok")
         {
            $current_employees_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_employees_current_url=$current_employees_url_params.'?qemployees=';
            if (strpos($current_employees_url_params, '?') !== false) {

                $clean_employees_current_url=$current_employees_url_params.'&qemployees=';

            }
            if (strpos($current_employees_url_params, '?qemployees')) {

                $remove_employees_old_token = substr($current_employees_url_params, 0, strpos($current_employees_url_params, "?qemployees"));

                $clean_employees_current_url=$remove_employees_old_token.'?qemployees=';

            }
            if(strpos($current_employees_url_params, '&qemployees')) {

                $remove_employees_old_token = substr($current_employees_url_params, 0, strpos($current_employees_url_params, "&qemployees"));

                $clean_employees_current_url=$remove_employees_old_token.'&qemployees=';

            }
        $qemployees_str=base64_encode($_POST["txt_employees"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_employees_current_url.($qemployees_str);
            } 

          }else{ 
             header('location:'.$clean_employees_current_url.($qemployees_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_employees_);

        }
        }
        $qemployees="";
		if(isset($_GET["employees_mosyfilter"]) && isset($_GET["qemployees"])){
         $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "employees_mosyfilter_n_query","");

         $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
         	
          //echo $gwauthenticate_employees_;

         if($gwauthenticate_employees_json["response"]=="ok")
         {
         $qemployees=mmres(base64_decode($_GET["qemployees"]));
         
         $gft_employees_where_query="(`user_id` LIKE '%".$qemployees."%' OR  `name` LIKE '%".$qemployees."%' OR  `email` LIKE '%".$qemployees."%' OR  `tel` LIKE '%".$qemployees."%' OR  `job_group` LIKE '%".$qemployees."%' OR  `nssf_no` LIKE '%".$qemployees."%' OR  `nhif_no` LIKE '%".$qemployees."%' OR  `pin_no` LIKE '%".$qemployees."%' OR  `national_id` LIKE '%".$qemployees."%' OR  `contract_start_date` LIKE '%".$qemployees."%' OR  `contract_end_date` LIKE '%".$qemployees."%' OR  `staff_number` LIKE '%".$qemployees."%' OR  `passport_photo` LIKE '%".$qemployees."%' OR  `gender` LIKE '%".$qemployees."%' OR  `job_title` LIKE '%".$qemployees."%' OR  `departments` LIKE '%".$qemployees."%' OR  `head_of` LIKE '%".$qemployees."%' OR  `reports_to` LIKE '%".$qemployees."%' OR  `about` LIKE '%".$qemployees."%' OR  `owner` LIKE '%".$qemployees."%' OR  `employement_date` LIKE '%".$qemployees."%' OR  `country` LIKE '%".$qemployees."%' OR  `city` LIKE '%".$qemployees."%' OR  `town` LIKE '%".$qemployees."%' OR  `date_of_birth` LIKE '%".$qemployees."%' OR  `job_group_letter` LIKE '%".$qemployees."%' OR  `job_group_salary` LIKE '%".$qemployees."%' OR  `job_group_type` LIKE '%".$qemployees."%')";
         
         if($_GET["employees_mosyfilter"]!=""){
         
         $mosyfilter_employees_queries_str=(base64_decode($_GET["employees_mosyfilter"]));
        
         $gft_employees_where_query="(`user_id` LIKE '%".$qemployees."%' OR  `name` LIKE '%".$qemployees."%' OR  `email` LIKE '%".$qemployees."%' OR  `tel` LIKE '%".$qemployees."%' OR  `job_group` LIKE '%".$qemployees."%' OR  `nssf_no` LIKE '%".$qemployees."%' OR  `nhif_no` LIKE '%".$qemployees."%' OR  `pin_no` LIKE '%".$qemployees."%' OR  `national_id` LIKE '%".$qemployees."%' OR  `contract_start_date` LIKE '%".$qemployees."%' OR  `contract_end_date` LIKE '%".$qemployees."%' OR  `staff_number` LIKE '%".$qemployees."%' OR  `passport_photo` LIKE '%".$qemployees."%' OR  `gender` LIKE '%".$qemployees."%' OR  `job_title` LIKE '%".$qemployees."%' OR  `departments` LIKE '%".$qemployees."%' OR  `head_of` LIKE '%".$qemployees."%' OR  `reports_to` LIKE '%".$qemployees."%' OR  `about` LIKE '%".$qemployees."%' OR  `owner` LIKE '%".$qemployees."%' OR  `employement_date` LIKE '%".$qemployees."%' OR  `country` LIKE '%".$qemployees."%' OR  `city` LIKE '%".$qemployees."%' OR  `town` LIKE '%".$qemployees."%' OR  `date_of_birth` LIKE '%".$qemployees."%' OR  `job_group_letter` LIKE '%".$qemployees."%' OR  `job_group_salary` LIKE '%".$qemployees."%' OR  `job_group_type` LIKE '%".$qemployees."%') AND ".$mosyfilter_employees_queries_str."";
         
         }
         
		 $gft_employees="WHERE ".$gft_employees_where_query;
         
         $gft_employees_and=$gft_employees_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_employees_);
        }
        }elseif(isset($_GET["qemployees"])){
         $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "get_qemployees","");

         $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
         	
          //echo $gwauthenticate_employees_;

         if($gwauthenticate_employees_json["response"]=="ok")
         {
		 $qemployees=mmres(base64_decode($_GET["qemployees"]));
        
         $gft_employees_where_query="(`user_id` LIKE '%".$qemployees."%' OR  `name` LIKE '%".$qemployees."%' OR  `email` LIKE '%".$qemployees."%' OR  `tel` LIKE '%".$qemployees."%' OR  `job_group` LIKE '%".$qemployees."%' OR  `nssf_no` LIKE '%".$qemployees."%' OR  `nhif_no` LIKE '%".$qemployees."%' OR  `pin_no` LIKE '%".$qemployees."%' OR  `national_id` LIKE '%".$qemployees."%' OR  `contract_start_date` LIKE '%".$qemployees."%' OR  `contract_end_date` LIKE '%".$qemployees."%' OR  `staff_number` LIKE '%".$qemployees."%' OR  `passport_photo` LIKE '%".$qemployees."%' OR  `gender` LIKE '%".$qemployees."%' OR  `job_title` LIKE '%".$qemployees."%' OR  `departments` LIKE '%".$qemployees."%' OR  `head_of` LIKE '%".$qemployees."%' OR  `reports_to` LIKE '%".$qemployees."%' OR  `about` LIKE '%".$qemployees."%' OR  `owner` LIKE '%".$qemployees."%' OR  `employement_date` LIKE '%".$qemployees."%' OR  `country` LIKE '%".$qemployees."%' OR  `city` LIKE '%".$qemployees."%' OR  `town` LIKE '%".$qemployees."%' OR  `date_of_birth` LIKE '%".$qemployees."%' OR  `job_group_letter` LIKE '%".$qemployees."%' OR  `job_group_salary` LIKE '%".$qemployees."%' OR  `job_group_type` LIKE '%".$qemployees."%')";
         
         $gft_employees="WHERE ".$gft_employees_where_query;
         
         $gft_employees_and=$gft_employees_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_employees_);

        }
        }elseif(isset($_GET["employees_mosyfilter"])){
         $gwauthenticate_employees_=gw_oauth("table", magic_current_url(), "employees", "employees_mosyfilter","");

         $gwauthenticate_employees_json=json_decode($gwauthenticate_employees_, true);
         	
          //echo $gwauthenticate_employees_;

         if($gwauthenticate_employees_json["response"]=="ok")
         {
         $gft_employees_where_query="";
         $gft_employees="";

         if($_GET["employees_mosyfilter"]!=""){
          $gft_employees_where_query=(base64_decode($_GET["employees_mosyfilter"]));
          $gft_employees="WHERE ".$gft_employees_where_query;
         }
         
         
         $gft_employees_and=$gft_employees_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_employees_);

        }
        }else{
         $gft_employees="";
         $gft_employees_and="";
         $gft_employees_where_query="";
        }
       
    //************************************************* END  employees OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section employees_next_of_kin
  //************************************************* START  employees_next_of_kin OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize employees_next_of_kin edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['employees_next_of_kin_table_alert']))
              	{	
                  if(isset($employees_next_of_kin_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$employees_next_of_kin_uptoken="";

		if(isset($_GET["employees_next_of_kin_uptoken"]))
		{
		$employees_next_of_kin_uptoken=base64_decode($_GET["employees_next_of_kin_uptoken"]);
		}
        
        if(isset($_POST["employees_next_of_kin_uptoken"]))
		{
		$employees_next_of_kin_uptoken=base64_decode($_POST["employees_next_of_kin_uptoken"]);
		}
        //
        
          $employees_next_of_kin_alias_name="EMPLOYEES NEXT OF KIN";

          if(isset($employees_next_of_kin_alias))
          {
             $employees_next_of_kin_alias_name=$employees_next_of_kin_alias;

          }
          
        //get single data record query with $employees_next_of_kin_uptoken
        
        ///$employees_next_of_kin_node=get_employees_next_of_kin("*", "WHERE primkey='$employees_next_of_kin_uptoken'", "r");
        
	
//************* START INSERT  employees_next_of_kin QUERY 
if(isset($_POST["employees_next_of_kin_insert_btn"])){
//------- begin employees_next_of_kin_arr_ins --> 
$employees_next_of_kin_arr_ins_=array(

"primkey"=>"NULL",
"kin_id"=>magic_random_str(7),
"owner"=>"?",
"employee_id"=>"?",
"next_of_kin_name"=>"?",
"next_of_kin_telephone"=>"?",
"next_of_kin_email"=>"?",
"relation"=>"?",
"assigned_on"=>"?"

);
//===-- End employees_next_of_kin_arr_ins -->


          
         $gwauthenticate_employees_next_of_kin_=gw_oauth("table", magic_current_url(), "employees_next_of_kin", "insert","");

         $gwauthenticate_employees_next_of_kin_json=json_decode($gwauthenticate_employees_next_of_kin_, true);
         	
          //echo $gwauthenticate_employees_next_of_kin_;

         if($gwauthenticate_employees_next_of_kin_json["response"]=="ok")
         {

              $employees_next_of_kin_validated_ins_str=$employees_next_of_kin_arr_ins_;

              if(isset($employees_next_of_kin_ins_inputs))
              {
                $employees_next_of_kin_validated_ins_str=$employees_next_of_kin_ins_inputs;	
              }

              if(empty($employees_next_of_kin_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$employees_next_of_kin_alias_name." request cannot be empty. Record not added");
              }else{

                $employees_next_of_kin_return_key=add_employees_next_of_kin($employees_next_of_kin_validated_ins_str);
                
                mosy_sql_rollback("employees_next_of_kin", "primkey='$employees_next_of_kin_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $employees_next_of_kin_return_key; 

                      } 

                    }else{ 

                                    
                $employees_next_of_kin_custom_redir1=add_url_param ("employees_next_of_kin_uptoken", base64_encode($employees_next_of_kin_return_key), "");
                $employees_next_of_kin_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$employees_next_of_kin_custom_redir1);
                $employees_next_of_kin_custom_redir3=add_url_param ("employees_next_of_kin_table_alert", "employees_next_of_kin_added",$employees_next_of_kin_custom_redir2);
                
                ///echo magic_message($employees_next_of_kin_custom_redir1." -- ".$employees_next_of_kin_custom_redir2."--".$employees_next_of_kin_custom_redir3);
                
                $employees_next_of_kin_custom_redir=$employees_next_of_kin_custom_redir3;
                
               header('location:'.$employees_next_of_kin_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_employees_next_of_kin_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_next_of_kin_)."");
         
         }
      
}
//************* END  employees_next_of_kin INSERT QUERY 	
	

//************* START employees_next_of_kin  UPDATE QUERY 
if(isset($_POST["employees_next_of_kin_update_btn"])){
//------- begin employees_next_of_kin_arr_updt --> 
$employees_next_of_kin_arr_updt_=array(
"owner"=>"?",
"employee_id"=>"?",
"next_of_kin_name"=>"?",
"next_of_kin_telephone"=>"?",
"next_of_kin_email"=>"?",
"relation"=>"?",
"assigned_on"=>"?"

);
//===-- End employees_next_of_kin_arr_updt -->
                     
         $gwauthenticate_employees_next_of_kin_=gw_oauth("table", magic_current_url(), "employees_next_of_kin", "update","");

         $gwauthenticate_employees_next_of_kin_json=json_decode($gwauthenticate_employees_next_of_kin_, true);
         	
          //echo $gwauthenticate_employees_next_of_kin_;

         if($gwauthenticate_employees_next_of_kin_json["response"]=="ok")
         {
         
            $employees_next_of_kin_validated_updt_str=$employees_next_of_kin_arr_updt_;

            if(isset($employees_next_of_kin_updt_inputs))
            {
              $employees_next_of_kin_validated_updt_str=$employees_next_of_kin_updt_inputs;	
            }

            if(empty($employees_next_of_kin_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$employees_next_of_kin_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$employees_next_of_kin_key_salt=initialize_employees_next_of_kin()["kin_id"];
            
              update_employees_next_of_kin($employees_next_of_kin_validated_updt_str, "primkey='$employees_next_of_kin_uptoken' and kin_id='$employees_next_of_kin_key_salt'");
				

			 mosy_sql_rollback("employees_next_of_kin", "primkey='$employees_next_of_kin_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $employees_next_of_kin_uptoken; 

                    } 

                  }else{ 

                $employees_next_of_kin_custom_redir1=add_url_param ("employees_next_of_kin_uptoken", base64_encode($employees_next_of_kin_uptoken), "");
                $employees_next_of_kin_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$employees_next_of_kin_custom_redir1);
                $employees_next_of_kin_custom_redir3=add_url_param ("employees_next_of_kin_table_alert", "employees_next_of_kin_updated",$employees_next_of_kin_custom_redir2);
                
                ///echo magic_message($employees_next_of_kin_custom_redir1." -- ".$employees_next_of_kin_custom_redir2."--".$employees_next_of_kin_custom_redir3);
                
                $employees_next_of_kin_custom_redir=$employees_next_of_kin_custom_redir3;
                
               header('location:'.$employees_next_of_kin_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_employees_next_of_kin_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_employees_next_of_kin_)."");
         
         }

      

      
}
//************* END employees_next_of_kin  UPDATE QUERY 

    
    
      //== Start employees_next_of_kin delete record

      if(isset($_GET["deleteemployees_next_of_kin"]))
      {
         $gwauthenticate_employees_next_of_kin_=gw_oauth("table", magic_current_url(), "employees_next_of_kin", "super_delete_request","");

         $gwauthenticate_employees_next_of_kin_json=json_decode($gwauthenticate_employees_next_of_kin_, true);
         	
          //echo $gwauthenticate_employees_next_of_kin_;

         if($gwauthenticate_employees_next_of_kin_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_employees_next_of_kin_btn=magic_button_link("./".$current_file_url."?employees_next_of_kin_uptoken=".$_GET["employees_next_of_kin_uptoken"]."&conf_deleteemployees_next_of_kin&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_employees_next_of_kin_btn=magic_button_link("./".$current_file_url."?employees_next_of_kin_uptoken=".$_GET["employees_next_of_kin_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_employees_next_of_kin_btn." ".$cancel_del_employees_next_of_kin_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_employees_next_of_kin_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteemployees_next_of_kin"]))
      {
         $gwauthenticate_employees_next_of_kin_=gw_oauth("table", magic_current_url(), "employees_next_of_kin", "super_delete_confirm","");

         $gwauthenticate_employees_next_of_kin_json=json_decode($gwauthenticate_employees_next_of_kin_, true);
         	
          //echo $gwauthenticate_employees_next_of_kin_;

         if($gwauthenticate_employees_next_of_kin_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $employees_next_of_kin_del_key_salt=initialize_employees_next_of_kin()["kin_id"];
      mosy_sql_rollback("employees_next_of_kin", "primkey='$employees_next_of_kin_uptoken'", "DELETE");
      drop_employees_next_of_kin("primkey='$employees_next_of_kin_uptoken' and kin_id='$employees_next_of_kin_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_employees_next_of_kin_);

      }
      }

      //== End employees_next_of_kin delete record  
    
       ///SELECT STRING FOR employees_next_of_kin============================
              
       if(isset($_POST["qemployees_next_of_kin_btn"])){
         $gwauthenticate_employees_next_of_kin_=gw_oauth("table", magic_current_url(), "employees_next_of_kin", "qemployees_next_of_kin_btn","");

         $gwauthenticate_employees_next_of_kin_json=json_decode($gwauthenticate_employees_next_of_kin_, true);
         	
          //echo $gwauthenticate_employees_next_of_kin_;

         if($gwauthenticate_employees_next_of_kin_json["response"]=="ok")
         {
            $current_employees_next_of_kin_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_employees_next_of_kin_current_url=$current_employees_next_of_kin_url_params.'?qemployees_next_of_kin=';
            if (strpos($current_employees_next_of_kin_url_params, '?') !== false) {

                $clean_employees_next_of_kin_current_url=$current_employees_next_of_kin_url_params.'&qemployees_next_of_kin=';

            }
            if (strpos($current_employees_next_of_kin_url_params, '?qemployees_next_of_kin')) {

                $remove_employees_next_of_kin_old_token = substr($current_employees_next_of_kin_url_params, 0, strpos($current_employees_next_of_kin_url_params, "?qemployees_next_of_kin"));

                $clean_employees_next_of_kin_current_url=$remove_employees_next_of_kin_old_token.'?qemployees_next_of_kin=';

            }
            if(strpos($current_employees_next_of_kin_url_params, '&qemployees_next_of_kin')) {

                $remove_employees_next_of_kin_old_token = substr($current_employees_next_of_kin_url_params, 0, strpos($current_employees_next_of_kin_url_params, "&qemployees_next_of_kin"));

                $clean_employees_next_of_kin_current_url=$remove_employees_next_of_kin_old_token.'&qemployees_next_of_kin=';

            }
        $qemployees_next_of_kin_str=base64_encode($_POST["txt_employees_next_of_kin"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_employees_next_of_kin_current_url.($qemployees_next_of_kin_str);
            } 

          }else{ 
             header('location:'.$clean_employees_next_of_kin_current_url.($qemployees_next_of_kin_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_employees_next_of_kin_);

        }
        }
        $qemployees_next_of_kin="";
		if(isset($_GET["employees_next_of_kin_mosyfilter"]) && isset($_GET["qemployees_next_of_kin"])){
         $gwauthenticate_employees_next_of_kin_=gw_oauth("table", magic_current_url(), "employees_next_of_kin", "employees_next_of_kin_mosyfilter_n_query","");

         $gwauthenticate_employees_next_of_kin_json=json_decode($gwauthenticate_employees_next_of_kin_, true);
         	
          //echo $gwauthenticate_employees_next_of_kin_;

         if($gwauthenticate_employees_next_of_kin_json["response"]=="ok")
         {
         $qemployees_next_of_kin=mmres(base64_decode($_GET["qemployees_next_of_kin"]));
         
         $gft_employees_next_of_kin_where_query="(`kin_id` LIKE '%".$qemployees_next_of_kin."%' OR  `owner` LIKE '%".$qemployees_next_of_kin."%' OR  `employee_id` LIKE '%".$qemployees_next_of_kin."%' OR  `next_of_kin_name` LIKE '%".$qemployees_next_of_kin."%' OR  `next_of_kin_telephone` LIKE '%".$qemployees_next_of_kin."%' OR  `next_of_kin_email` LIKE '%".$qemployees_next_of_kin."%' OR  `relation` LIKE '%".$qemployees_next_of_kin."%' OR  `assigned_on` LIKE '%".$qemployees_next_of_kin."%')";
         
         if($_GET["employees_next_of_kin_mosyfilter"]!=""){
         
         $mosyfilter_employees_next_of_kin_queries_str=(base64_decode($_GET["employees_next_of_kin_mosyfilter"]));
        
         $gft_employees_next_of_kin_where_query="(`kin_id` LIKE '%".$qemployees_next_of_kin."%' OR  `owner` LIKE '%".$qemployees_next_of_kin."%' OR  `employee_id` LIKE '%".$qemployees_next_of_kin."%' OR  `next_of_kin_name` LIKE '%".$qemployees_next_of_kin."%' OR  `next_of_kin_telephone` LIKE '%".$qemployees_next_of_kin."%' OR  `next_of_kin_email` LIKE '%".$qemployees_next_of_kin."%' OR  `relation` LIKE '%".$qemployees_next_of_kin."%' OR  `assigned_on` LIKE '%".$qemployees_next_of_kin."%') AND ".$mosyfilter_employees_next_of_kin_queries_str."";
         
         }
         
		 $gft_employees_next_of_kin="WHERE ".$gft_employees_next_of_kin_where_query;
         
         $gft_employees_next_of_kin_and=$gft_employees_next_of_kin_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_employees_next_of_kin_);
        }
        }elseif(isset($_GET["qemployees_next_of_kin"])){
         $gwauthenticate_employees_next_of_kin_=gw_oauth("table", magic_current_url(), "employees_next_of_kin", "get_qemployees_next_of_kin","");

         $gwauthenticate_employees_next_of_kin_json=json_decode($gwauthenticate_employees_next_of_kin_, true);
         	
          //echo $gwauthenticate_employees_next_of_kin_;

         if($gwauthenticate_employees_next_of_kin_json["response"]=="ok")
         {
		 $qemployees_next_of_kin=mmres(base64_decode($_GET["qemployees_next_of_kin"]));
        
         $gft_employees_next_of_kin_where_query="(`kin_id` LIKE '%".$qemployees_next_of_kin."%' OR  `owner` LIKE '%".$qemployees_next_of_kin."%' OR  `employee_id` LIKE '%".$qemployees_next_of_kin."%' OR  `next_of_kin_name` LIKE '%".$qemployees_next_of_kin."%' OR  `next_of_kin_telephone` LIKE '%".$qemployees_next_of_kin."%' OR  `next_of_kin_email` LIKE '%".$qemployees_next_of_kin."%' OR  `relation` LIKE '%".$qemployees_next_of_kin."%' OR  `assigned_on` LIKE '%".$qemployees_next_of_kin."%')";
         
         $gft_employees_next_of_kin="WHERE ".$gft_employees_next_of_kin_where_query;
         
         $gft_employees_next_of_kin_and=$gft_employees_next_of_kin_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_employees_next_of_kin_);

        }
        }elseif(isset($_GET["employees_next_of_kin_mosyfilter"])){
         $gwauthenticate_employees_next_of_kin_=gw_oauth("table", magic_current_url(), "employees_next_of_kin", "employees_next_of_kin_mosyfilter","");

         $gwauthenticate_employees_next_of_kin_json=json_decode($gwauthenticate_employees_next_of_kin_, true);
         	
          //echo $gwauthenticate_employees_next_of_kin_;

         if($gwauthenticate_employees_next_of_kin_json["response"]=="ok")
         {
         $gft_employees_next_of_kin_where_query="";
         $gft_employees_next_of_kin="";

         if($_GET["employees_next_of_kin_mosyfilter"]!=""){
          $gft_employees_next_of_kin_where_query=(base64_decode($_GET["employees_next_of_kin_mosyfilter"]));
          $gft_employees_next_of_kin="WHERE ".$gft_employees_next_of_kin_where_query;
         }
         
         
         $gft_employees_next_of_kin_and=$gft_employees_next_of_kin_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_employees_next_of_kin_);

        }
        }else{
         $gft_employees_next_of_kin="";
         $gft_employees_next_of_kin_and="";
         $gft_employees_next_of_kin_where_query="";
        }
       
    //************************************************* END  employees_next_of_kin OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section expense_claims
  //************************************************* START  expense_claims OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize expense_claims edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['expense_claims_table_alert']))
              	{	
                  if(isset($expense_claims_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$expense_claims_uptoken="";

		if(isset($_GET["expense_claims_uptoken"]))
		{
		$expense_claims_uptoken=base64_decode($_GET["expense_claims_uptoken"]);
		}
        
        if(isset($_POST["expense_claims_uptoken"]))
		{
		$expense_claims_uptoken=base64_decode($_POST["expense_claims_uptoken"]);
		}
        //
        
          $expense_claims_alias_name="EXPENSE CLAIMS";

          if(isset($expense_claims_alias))
          {
             $expense_claims_alias_name=$expense_claims_alias;

          }
          
        //get single data record query with $expense_claims_uptoken
        
        ///$expense_claims_node=get_expense_claims("*", "WHERE primkey='$expense_claims_uptoken'", "r");
        
	
//************* START INSERT  expense_claims QUERY 
if(isset($_POST["expense_claims_insert_btn"])){
//------- begin expense_claims_arr_ins --> 
$expense_claims_arr_ins_=array(

"primkey"=>"NULL",
"claim_key"=>magic_random_str(7),
"transaction_date"=>"?",
"amount_paid"=>"?",
"ref_id"=>"?",
"staff_id"=>"?",
"remark"=>"?"

);
//===-- End expense_claims_arr_ins -->


          
         $gwauthenticate_expense_claims_=gw_oauth("table", magic_current_url(), "expense_claims", "insert","");

         $gwauthenticate_expense_claims_json=json_decode($gwauthenticate_expense_claims_, true);
         	
          //echo $gwauthenticate_expense_claims_;

         if($gwauthenticate_expense_claims_json["response"]=="ok")
         {

              $expense_claims_validated_ins_str=$expense_claims_arr_ins_;

              if(isset($expense_claims_ins_inputs))
              {
                $expense_claims_validated_ins_str=$expense_claims_ins_inputs;	
              }

              if(empty($expense_claims_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$expense_claims_alias_name." request cannot be empty. Record not added");
              }else{

                $expense_claims_return_key=add_expense_claims($expense_claims_validated_ins_str);
                
                mosy_sql_rollback("expense_claims", "primkey='$expense_claims_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $expense_claims_return_key; 

                      } 

                    }else{ 

                                    
                $expense_claims_custom_redir1=add_url_param ("expense_claims_uptoken", base64_encode($expense_claims_return_key), "");
                $expense_claims_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$expense_claims_custom_redir1);
                $expense_claims_custom_redir3=add_url_param ("expense_claims_table_alert", "expense_claims_added",$expense_claims_custom_redir2);
                
                ///echo magic_message($expense_claims_custom_redir1." -- ".$expense_claims_custom_redir2."--".$expense_claims_custom_redir3);
                
                $expense_claims_custom_redir=$expense_claims_custom_redir3;
                
               header('location:'.$expense_claims_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_expense_claims_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expense_claims_)."");
         
         }
      
}
//************* END  expense_claims INSERT QUERY 	
	

//************* START expense_claims  UPDATE QUERY 
if(isset($_POST["expense_claims_update_btn"])){
//------- begin expense_claims_arr_updt --> 
$expense_claims_arr_updt_=array(
"transaction_date"=>"?",
"amount_paid"=>"?",
"ref_id"=>"?",
"staff_id"=>"?",
"remark"=>"?"

);
//===-- End expense_claims_arr_updt -->
                     
         $gwauthenticate_expense_claims_=gw_oauth("table", magic_current_url(), "expense_claims", "update","");

         $gwauthenticate_expense_claims_json=json_decode($gwauthenticate_expense_claims_, true);
         	
          //echo $gwauthenticate_expense_claims_;

         if($gwauthenticate_expense_claims_json["response"]=="ok")
         {
         
            $expense_claims_validated_updt_str=$expense_claims_arr_updt_;

            if(isset($expense_claims_updt_inputs))
            {
              $expense_claims_validated_updt_str=$expense_claims_updt_inputs;	
            }

            if(empty($expense_claims_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$expense_claims_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$expense_claims_key_salt=initialize_expense_claims()["claim_key"];
            
              update_expense_claims($expense_claims_validated_updt_str, "primkey='$expense_claims_uptoken' and claim_key='$expense_claims_key_salt'");
				

			 mosy_sql_rollback("expense_claims", "primkey='$expense_claims_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $expense_claims_uptoken; 

                    } 

                  }else{ 

                $expense_claims_custom_redir1=add_url_param ("expense_claims_uptoken", base64_encode($expense_claims_uptoken), "");
                $expense_claims_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$expense_claims_custom_redir1);
                $expense_claims_custom_redir3=add_url_param ("expense_claims_table_alert", "expense_claims_updated",$expense_claims_custom_redir2);
                
                ///echo magic_message($expense_claims_custom_redir1." -- ".$expense_claims_custom_redir2."--".$expense_claims_custom_redir3);
                
                $expense_claims_custom_redir=$expense_claims_custom_redir3;
                
               header('location:'.$expense_claims_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_expense_claims_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_expense_claims_)."");
         
         }

      

      
}
//************* END expense_claims  UPDATE QUERY 

    
    
      //== Start expense_claims delete record

      if(isset($_GET["deleteexpense_claims"]))
      {
         $gwauthenticate_expense_claims_=gw_oauth("table", magic_current_url(), "expense_claims", "super_delete_request","");

         $gwauthenticate_expense_claims_json=json_decode($gwauthenticate_expense_claims_, true);
         	
          //echo $gwauthenticate_expense_claims_;

         if($gwauthenticate_expense_claims_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_expense_claims_btn=magic_button_link("./".$current_file_url."?expense_claims_uptoken=".$_GET["expense_claims_uptoken"]."&conf_deleteexpense_claims&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_expense_claims_btn=magic_button_link("./".$current_file_url."?expense_claims_uptoken=".$_GET["expense_claims_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_expense_claims_btn." ".$cancel_del_expense_claims_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_expense_claims_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteexpense_claims"]))
      {
         $gwauthenticate_expense_claims_=gw_oauth("table", magic_current_url(), "expense_claims", "super_delete_confirm","");

         $gwauthenticate_expense_claims_json=json_decode($gwauthenticate_expense_claims_, true);
         	
          //echo $gwauthenticate_expense_claims_;

         if($gwauthenticate_expense_claims_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $expense_claims_del_key_salt=initialize_expense_claims()["claim_key"];
      mosy_sql_rollback("expense_claims", "primkey='$expense_claims_uptoken'", "DELETE");
      drop_expense_claims("primkey='$expense_claims_uptoken' and claim_key='$expense_claims_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_expense_claims_);

      }
      }

      //== End expense_claims delete record  
    
       ///SELECT STRING FOR expense_claims============================
              
       if(isset($_POST["qexpense_claims_btn"])){
         $gwauthenticate_expense_claims_=gw_oauth("table", magic_current_url(), "expense_claims", "qexpense_claims_btn","");

         $gwauthenticate_expense_claims_json=json_decode($gwauthenticate_expense_claims_, true);
         	
          //echo $gwauthenticate_expense_claims_;

         if($gwauthenticate_expense_claims_json["response"]=="ok")
         {
            $current_expense_claims_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_expense_claims_current_url=$current_expense_claims_url_params.'?qexpense_claims=';
            if (strpos($current_expense_claims_url_params, '?') !== false) {

                $clean_expense_claims_current_url=$current_expense_claims_url_params.'&qexpense_claims=';

            }
            if (strpos($current_expense_claims_url_params, '?qexpense_claims')) {

                $remove_expense_claims_old_token = substr($current_expense_claims_url_params, 0, strpos($current_expense_claims_url_params, "?qexpense_claims"));

                $clean_expense_claims_current_url=$remove_expense_claims_old_token.'?qexpense_claims=';

            }
            if(strpos($current_expense_claims_url_params, '&qexpense_claims')) {

                $remove_expense_claims_old_token = substr($current_expense_claims_url_params, 0, strpos($current_expense_claims_url_params, "&qexpense_claims"));

                $clean_expense_claims_current_url=$remove_expense_claims_old_token.'&qexpense_claims=';

            }
        $qexpense_claims_str=base64_encode($_POST["txt_expense_claims"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_expense_claims_current_url.($qexpense_claims_str);
            } 

          }else{ 
             header('location:'.$clean_expense_claims_current_url.($qexpense_claims_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_expense_claims_);

        }
        }
        $qexpense_claims="";
		if(isset($_GET["expense_claims_mosyfilter"]) && isset($_GET["qexpense_claims"])){
         $gwauthenticate_expense_claims_=gw_oauth("table", magic_current_url(), "expense_claims", "expense_claims_mosyfilter_n_query","");

         $gwauthenticate_expense_claims_json=json_decode($gwauthenticate_expense_claims_, true);
         	
          //echo $gwauthenticate_expense_claims_;

         if($gwauthenticate_expense_claims_json["response"]=="ok")
         {
         $qexpense_claims=mmres(base64_decode($_GET["qexpense_claims"]));
         
         $gft_expense_claims_where_query="(`claim_key` LIKE '%".$qexpense_claims."%' OR  `transaction_date` LIKE '%".$qexpense_claims."%' OR  `amount_paid` LIKE '%".$qexpense_claims."%' OR  `ref_id` LIKE '%".$qexpense_claims."%' OR  `staff_id` LIKE '%".$qexpense_claims."%' OR  `remark` LIKE '%".$qexpense_claims."%')";
         
         if($_GET["expense_claims_mosyfilter"]!=""){
         
         $mosyfilter_expense_claims_queries_str=(base64_decode($_GET["expense_claims_mosyfilter"]));
        
         $gft_expense_claims_where_query="(`claim_key` LIKE '%".$qexpense_claims."%' OR  `transaction_date` LIKE '%".$qexpense_claims."%' OR  `amount_paid` LIKE '%".$qexpense_claims."%' OR  `ref_id` LIKE '%".$qexpense_claims."%' OR  `staff_id` LIKE '%".$qexpense_claims."%' OR  `remark` LIKE '%".$qexpense_claims."%') AND ".$mosyfilter_expense_claims_queries_str."";
         
         }
         
		 $gft_expense_claims="WHERE ".$gft_expense_claims_where_query;
         
         $gft_expense_claims_and=$gft_expense_claims_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_expense_claims_);
        }
        }elseif(isset($_GET["qexpense_claims"])){
         $gwauthenticate_expense_claims_=gw_oauth("table", magic_current_url(), "expense_claims", "get_qexpense_claims","");

         $gwauthenticate_expense_claims_json=json_decode($gwauthenticate_expense_claims_, true);
         	
          //echo $gwauthenticate_expense_claims_;

         if($gwauthenticate_expense_claims_json["response"]=="ok")
         {
		 $qexpense_claims=mmres(base64_decode($_GET["qexpense_claims"]));
        
         $gft_expense_claims_where_query="(`claim_key` LIKE '%".$qexpense_claims."%' OR  `transaction_date` LIKE '%".$qexpense_claims."%' OR  `amount_paid` LIKE '%".$qexpense_claims."%' OR  `ref_id` LIKE '%".$qexpense_claims."%' OR  `staff_id` LIKE '%".$qexpense_claims."%' OR  `remark` LIKE '%".$qexpense_claims."%')";
         
         $gft_expense_claims="WHERE ".$gft_expense_claims_where_query;
         
         $gft_expense_claims_and=$gft_expense_claims_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_expense_claims_);

        }
        }elseif(isset($_GET["expense_claims_mosyfilter"])){
         $gwauthenticate_expense_claims_=gw_oauth("table", magic_current_url(), "expense_claims", "expense_claims_mosyfilter","");

         $gwauthenticate_expense_claims_json=json_decode($gwauthenticate_expense_claims_, true);
         	
          //echo $gwauthenticate_expense_claims_;

         if($gwauthenticate_expense_claims_json["response"]=="ok")
         {
         $gft_expense_claims_where_query="";
         $gft_expense_claims="";

         if($_GET["expense_claims_mosyfilter"]!=""){
          $gft_expense_claims_where_query=(base64_decode($_GET["expense_claims_mosyfilter"]));
          $gft_expense_claims="WHERE ".$gft_expense_claims_where_query;
         }
         
         
         $gft_expense_claims_and=$gft_expense_claims_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_expense_claims_);

        }
        }else{
         $gft_expense_claims="";
         $gft_expense_claims_and="";
         $gft_expense_claims_where_query="";
        }
       
    //************************************************* END  expense_claims OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section job_groups
  //************************************************* START  job_groups OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize job_groups edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['job_groups_table_alert']))
              	{	
                  if(isset($job_groups_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$job_groups_uptoken="";

		if(isset($_GET["job_groups_uptoken"]))
		{
		$job_groups_uptoken=base64_decode($_GET["job_groups_uptoken"]);
		}
        
        if(isset($_POST["job_groups_uptoken"]))
		{
		$job_groups_uptoken=base64_decode($_POST["job_groups_uptoken"]);
		}
        //
        
          $job_groups_alias_name="JOB GROUPS";

          if(isset($job_groups_alias))
          {
             $job_groups_alias_name=$job_groups_alias;

          }
          
        //get single data record query with $job_groups_uptoken
        
        ///$job_groups_node=get_job_groups("*", "WHERE primkey='$job_groups_uptoken'", "r");
        
	
//************* START INSERT  job_groups QUERY 
if(isset($_POST["job_groups_insert_btn"])){
//------- begin job_groups_arr_ins --> 
$job_groups_arr_ins_=array(

"primkey"=>"NULL",
"job_group_id"=>magic_random_str(7),
"Job_group_name"=>"?",
"basic_salary"=>"?",
"employment_type"=>"?",
"remark"=>"?",
"owner"=>"?"

);
//===-- End job_groups_arr_ins -->


          
         $gwauthenticate_job_groups_=gw_oauth("table", magic_current_url(), "job_groups", "insert","");

         $gwauthenticate_job_groups_json=json_decode($gwauthenticate_job_groups_, true);
         	
          //echo $gwauthenticate_job_groups_;

         if($gwauthenticate_job_groups_json["response"]=="ok")
         {

              $job_groups_validated_ins_str=$job_groups_arr_ins_;

              if(isset($job_groups_ins_inputs))
              {
                $job_groups_validated_ins_str=$job_groups_ins_inputs;	
              }

              if(empty($job_groups_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$job_groups_alias_name." request cannot be empty. Record not added");
              }else{

                $job_groups_return_key=add_job_groups($job_groups_validated_ins_str);
                
                mosy_sql_rollback("job_groups", "primkey='$job_groups_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $job_groups_return_key; 

                      } 

                    }else{ 

                                    
                $job_groups_custom_redir1=add_url_param ("job_groups_uptoken", base64_encode($job_groups_return_key), "");
                $job_groups_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$job_groups_custom_redir1);
                $job_groups_custom_redir3=add_url_param ("job_groups_table_alert", "job_groups_added",$job_groups_custom_redir2);
                
                ///echo magic_message($job_groups_custom_redir1." -- ".$job_groups_custom_redir2."--".$job_groups_custom_redir3);
                
                $job_groups_custom_redir=$job_groups_custom_redir3;
                
               header('location:'.$job_groups_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_job_groups_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_job_groups_)."");
         
         }
      
}
//************* END  job_groups INSERT QUERY 	
	

//************* START job_groups  UPDATE QUERY 
if(isset($_POST["job_groups_update_btn"])){
//------- begin job_groups_arr_updt --> 
$job_groups_arr_updt_=array(
"Job_group_name"=>"?",
"basic_salary"=>"?",
"employment_type"=>"?",
"remark"=>"?",
"owner"=>"?"

);
//===-- End job_groups_arr_updt -->
                     
         $gwauthenticate_job_groups_=gw_oauth("table", magic_current_url(), "job_groups", "update","");

         $gwauthenticate_job_groups_json=json_decode($gwauthenticate_job_groups_, true);
         	
          //echo $gwauthenticate_job_groups_;

         if($gwauthenticate_job_groups_json["response"]=="ok")
         {
         
            $job_groups_validated_updt_str=$job_groups_arr_updt_;

            if(isset($job_groups_updt_inputs))
            {
              $job_groups_validated_updt_str=$job_groups_updt_inputs;	
            }

            if(empty($job_groups_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$job_groups_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$job_groups_key_salt=initialize_job_groups()["job_group_id"];
            
              update_job_groups($job_groups_validated_updt_str, "primkey='$job_groups_uptoken' and job_group_id='$job_groups_key_salt'");
				

			 mosy_sql_rollback("job_groups", "primkey='$job_groups_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $job_groups_uptoken; 

                    } 

                  }else{ 

                $job_groups_custom_redir1=add_url_param ("job_groups_uptoken", base64_encode($job_groups_uptoken), "");
                $job_groups_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$job_groups_custom_redir1);
                $job_groups_custom_redir3=add_url_param ("job_groups_table_alert", "job_groups_updated",$job_groups_custom_redir2);
                
                ///echo magic_message($job_groups_custom_redir1." -- ".$job_groups_custom_redir2."--".$job_groups_custom_redir3);
                
                $job_groups_custom_redir=$job_groups_custom_redir3;
                
               header('location:'.$job_groups_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_job_groups_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_job_groups_)."");
         
         }

      

      
}
//************* END job_groups  UPDATE QUERY 

    
    
      //== Start job_groups delete record

      if(isset($_GET["deletejob_groups"]))
      {
         $gwauthenticate_job_groups_=gw_oauth("table", magic_current_url(), "job_groups", "super_delete_request","");

         $gwauthenticate_job_groups_json=json_decode($gwauthenticate_job_groups_, true);
         	
          //echo $gwauthenticate_job_groups_;

         if($gwauthenticate_job_groups_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_job_groups_btn=magic_button_link("./".$current_file_url."?job_groups_uptoken=".$_GET["job_groups_uptoken"]."&conf_deletejob_groups&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_job_groups_btn=magic_button_link("./".$current_file_url."?job_groups_uptoken=".$_GET["job_groups_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_job_groups_btn." ".$cancel_del_job_groups_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_job_groups_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletejob_groups"]))
      {
         $gwauthenticate_job_groups_=gw_oauth("table", magic_current_url(), "job_groups", "super_delete_confirm","");

         $gwauthenticate_job_groups_json=json_decode($gwauthenticate_job_groups_, true);
         	
          //echo $gwauthenticate_job_groups_;

         if($gwauthenticate_job_groups_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $job_groups_del_key_salt=initialize_job_groups()["job_group_id"];
      mosy_sql_rollback("job_groups", "primkey='$job_groups_uptoken'", "DELETE");
      drop_job_groups("primkey='$job_groups_uptoken' and job_group_id='$job_groups_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_job_groups_);

      }
      }

      //== End job_groups delete record  
    
       ///SELECT STRING FOR job_groups============================
              
       if(isset($_POST["qjob_groups_btn"])){
         $gwauthenticate_job_groups_=gw_oauth("table", magic_current_url(), "job_groups", "qjob_groups_btn","");

         $gwauthenticate_job_groups_json=json_decode($gwauthenticate_job_groups_, true);
         	
          //echo $gwauthenticate_job_groups_;

         if($gwauthenticate_job_groups_json["response"]=="ok")
         {
            $current_job_groups_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_job_groups_current_url=$current_job_groups_url_params.'?qjob_groups=';
            if (strpos($current_job_groups_url_params, '?') !== false) {

                $clean_job_groups_current_url=$current_job_groups_url_params.'&qjob_groups=';

            }
            if (strpos($current_job_groups_url_params, '?qjob_groups')) {

                $remove_job_groups_old_token = substr($current_job_groups_url_params, 0, strpos($current_job_groups_url_params, "?qjob_groups"));

                $clean_job_groups_current_url=$remove_job_groups_old_token.'?qjob_groups=';

            }
            if(strpos($current_job_groups_url_params, '&qjob_groups')) {

                $remove_job_groups_old_token = substr($current_job_groups_url_params, 0, strpos($current_job_groups_url_params, "&qjob_groups"));

                $clean_job_groups_current_url=$remove_job_groups_old_token.'&qjob_groups=';

            }
        $qjob_groups_str=base64_encode($_POST["txt_job_groups"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_job_groups_current_url.($qjob_groups_str);
            } 

          }else{ 
             header('location:'.$clean_job_groups_current_url.($qjob_groups_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_job_groups_);

        }
        }
        $qjob_groups="";
		if(isset($_GET["job_groups_mosyfilter"]) && isset($_GET["qjob_groups"])){
         $gwauthenticate_job_groups_=gw_oauth("table", magic_current_url(), "job_groups", "job_groups_mosyfilter_n_query","");

         $gwauthenticate_job_groups_json=json_decode($gwauthenticate_job_groups_, true);
         	
          //echo $gwauthenticate_job_groups_;

         if($gwauthenticate_job_groups_json["response"]=="ok")
         {
         $qjob_groups=mmres(base64_decode($_GET["qjob_groups"]));
         
         $gft_job_groups_where_query="(`job_group_id` LIKE '%".$qjob_groups."%' OR  `Job_group_name` LIKE '%".$qjob_groups."%' OR  `basic_salary` LIKE '%".$qjob_groups."%' OR  `employment_type` LIKE '%".$qjob_groups."%' OR  `remark` LIKE '%".$qjob_groups."%' OR  `owner` LIKE '%".$qjob_groups."%')";
         
         if($_GET["job_groups_mosyfilter"]!=""){
         
         $mosyfilter_job_groups_queries_str=(base64_decode($_GET["job_groups_mosyfilter"]));
        
         $gft_job_groups_where_query="(`job_group_id` LIKE '%".$qjob_groups."%' OR  `Job_group_name` LIKE '%".$qjob_groups."%' OR  `basic_salary` LIKE '%".$qjob_groups."%' OR  `employment_type` LIKE '%".$qjob_groups."%' OR  `remark` LIKE '%".$qjob_groups."%' OR  `owner` LIKE '%".$qjob_groups."%') AND ".$mosyfilter_job_groups_queries_str."";
         
         }
         
		 $gft_job_groups="WHERE ".$gft_job_groups_where_query;
         
         $gft_job_groups_and=$gft_job_groups_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_job_groups_);
        }
        }elseif(isset($_GET["qjob_groups"])){
         $gwauthenticate_job_groups_=gw_oauth("table", magic_current_url(), "job_groups", "get_qjob_groups","");

         $gwauthenticate_job_groups_json=json_decode($gwauthenticate_job_groups_, true);
         	
          //echo $gwauthenticate_job_groups_;

         if($gwauthenticate_job_groups_json["response"]=="ok")
         {
		 $qjob_groups=mmres(base64_decode($_GET["qjob_groups"]));
        
         $gft_job_groups_where_query="(`job_group_id` LIKE '%".$qjob_groups."%' OR  `Job_group_name` LIKE '%".$qjob_groups."%' OR  `basic_salary` LIKE '%".$qjob_groups."%' OR  `employment_type` LIKE '%".$qjob_groups."%' OR  `remark` LIKE '%".$qjob_groups."%' OR  `owner` LIKE '%".$qjob_groups."%')";
         
         $gft_job_groups="WHERE ".$gft_job_groups_where_query;
         
         $gft_job_groups_and=$gft_job_groups_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_job_groups_);

        }
        }elseif(isset($_GET["job_groups_mosyfilter"])){
         $gwauthenticate_job_groups_=gw_oauth("table", magic_current_url(), "job_groups", "job_groups_mosyfilter","");

         $gwauthenticate_job_groups_json=json_decode($gwauthenticate_job_groups_, true);
         	
          //echo $gwauthenticate_job_groups_;

         if($gwauthenticate_job_groups_json["response"]=="ok")
         {
         $gft_job_groups_where_query="";
         $gft_job_groups="";

         if($_GET["job_groups_mosyfilter"]!=""){
          $gft_job_groups_where_query=(base64_decode($_GET["job_groups_mosyfilter"]));
          $gft_job_groups="WHERE ".$gft_job_groups_where_query;
         }
         
         
         $gft_job_groups_and=$gft_job_groups_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_job_groups_);

        }
        }else{
         $gft_job_groups="";
         $gft_job_groups_and="";
         $gft_job_groups_where_query="";
        }
       
    //************************************************* END  job_groups OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section leave_entitlement
  //************************************************* START  leave_entitlement OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize leave_entitlement edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['leave_entitlement_table_alert']))
              	{	
                  if(isset($leave_entitlement_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$leave_entitlement_uptoken="";

		if(isset($_GET["leave_entitlement_uptoken"]))
		{
		$leave_entitlement_uptoken=base64_decode($_GET["leave_entitlement_uptoken"]);
		}
        
        if(isset($_POST["leave_entitlement_uptoken"]))
		{
		$leave_entitlement_uptoken=base64_decode($_POST["leave_entitlement_uptoken"]);
		}
        //
        
          $leave_entitlement_alias_name="LEAVE ENTITLEMENT";

          if(isset($leave_entitlement_alias))
          {
             $leave_entitlement_alias_name=$leave_entitlement_alias;

          }
          
        //get single data record query with $leave_entitlement_uptoken
        
        ///$leave_entitlement_node=get_leave_entitlement("*", "WHERE primkey='$leave_entitlement_uptoken'", "r");
        
	
//************* START INSERT  leave_entitlement QUERY 
if(isset($_POST["leave_entitlement_insert_btn"])){
//------- begin leave_entitlement_arr_ins --> 
$leave_entitlement_arr_ins_=array(

"primkey"=>"NULL",
"leave_cart_id"=>magic_random_str(7),
"leave_code"=>"?",
"leave_title"=>"?",
"gender"=>"?",
"max_days_in_year"=>"?",
"leave_day"=>"?",
"leave_year_starts"=>"?",
"max_days_carried_fwd"=>"?",
"max_negative_bal"=>"?",
"eligible_employement_type"=>"?",
"mandatory_attatchment"=>"?",
"leave_pay"=>"?",
"remark"=>"?",
"owner"=>"?"

);
//===-- End leave_entitlement_arr_ins -->


          
         $gwauthenticate_leave_entitlement_=gw_oauth("table", magic_current_url(), "leave_entitlement", "insert","");

         $gwauthenticate_leave_entitlement_json=json_decode($gwauthenticate_leave_entitlement_, true);
         	
          //echo $gwauthenticate_leave_entitlement_;

         if($gwauthenticate_leave_entitlement_json["response"]=="ok")
         {

              $leave_entitlement_validated_ins_str=$leave_entitlement_arr_ins_;

              if(isset($leave_entitlement_ins_inputs))
              {
                $leave_entitlement_validated_ins_str=$leave_entitlement_ins_inputs;	
              }

              if(empty($leave_entitlement_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$leave_entitlement_alias_name." request cannot be empty. Record not added");
              }else{

                $leave_entitlement_return_key=add_leave_entitlement($leave_entitlement_validated_ins_str);
                
                mosy_sql_rollback("leave_entitlement", "primkey='$leave_entitlement_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $leave_entitlement_return_key; 

                      } 

                    }else{ 

                                    
                $leave_entitlement_custom_redir1=add_url_param ("leave_entitlement_uptoken", base64_encode($leave_entitlement_return_key), "");
                $leave_entitlement_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$leave_entitlement_custom_redir1);
                $leave_entitlement_custom_redir3=add_url_param ("leave_entitlement_table_alert", "leave_entitlement_added",$leave_entitlement_custom_redir2);
                
                ///echo magic_message($leave_entitlement_custom_redir1." -- ".$leave_entitlement_custom_redir2."--".$leave_entitlement_custom_redir3);
                
                $leave_entitlement_custom_redir=$leave_entitlement_custom_redir3;
                
               header('location:'.$leave_entitlement_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_leave_entitlement_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_leave_entitlement_)."");
         
         }
      
}
//************* END  leave_entitlement INSERT QUERY 	
	

//************* START leave_entitlement  UPDATE QUERY 
if(isset($_POST["leave_entitlement_update_btn"])){
//------- begin leave_entitlement_arr_updt --> 
$leave_entitlement_arr_updt_=array(
"leave_code"=>"?",
"leave_title"=>"?",
"gender"=>"?",
"max_days_in_year"=>"?",
"leave_day"=>"?",
"leave_year_starts"=>"?",
"max_days_carried_fwd"=>"?",
"max_negative_bal"=>"?",
"eligible_employement_type"=>"?",
"mandatory_attatchment"=>"?",
"leave_pay"=>"?",
"remark"=>"?",
"owner"=>"?"

);
//===-- End leave_entitlement_arr_updt -->
                     
         $gwauthenticate_leave_entitlement_=gw_oauth("table", magic_current_url(), "leave_entitlement", "update","");

         $gwauthenticate_leave_entitlement_json=json_decode($gwauthenticate_leave_entitlement_, true);
         	
          //echo $gwauthenticate_leave_entitlement_;

         if($gwauthenticate_leave_entitlement_json["response"]=="ok")
         {
         
            $leave_entitlement_validated_updt_str=$leave_entitlement_arr_updt_;

            if(isset($leave_entitlement_updt_inputs))
            {
              $leave_entitlement_validated_updt_str=$leave_entitlement_updt_inputs;	
            }

            if(empty($leave_entitlement_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$leave_entitlement_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$leave_entitlement_key_salt=initialize_leave_entitlement()["leave_cart_id"];
            
              update_leave_entitlement($leave_entitlement_validated_updt_str, "primkey='$leave_entitlement_uptoken' and leave_cart_id='$leave_entitlement_key_salt'");
				

			 mosy_sql_rollback("leave_entitlement", "primkey='$leave_entitlement_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $leave_entitlement_uptoken; 

                    } 

                  }else{ 

                $leave_entitlement_custom_redir1=add_url_param ("leave_entitlement_uptoken", base64_encode($leave_entitlement_uptoken), "");
                $leave_entitlement_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$leave_entitlement_custom_redir1);
                $leave_entitlement_custom_redir3=add_url_param ("leave_entitlement_table_alert", "leave_entitlement_updated",$leave_entitlement_custom_redir2);
                
                ///echo magic_message($leave_entitlement_custom_redir1." -- ".$leave_entitlement_custom_redir2."--".$leave_entitlement_custom_redir3);
                
                $leave_entitlement_custom_redir=$leave_entitlement_custom_redir3;
                
               header('location:'.$leave_entitlement_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_leave_entitlement_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_leave_entitlement_)."");
         
         }

      

      
}
//************* END leave_entitlement  UPDATE QUERY 

    
    
      //== Start leave_entitlement delete record

      if(isset($_GET["deleteleave_entitlement"]))
      {
         $gwauthenticate_leave_entitlement_=gw_oauth("table", magic_current_url(), "leave_entitlement", "super_delete_request","");

         $gwauthenticate_leave_entitlement_json=json_decode($gwauthenticate_leave_entitlement_, true);
         	
          //echo $gwauthenticate_leave_entitlement_;

         if($gwauthenticate_leave_entitlement_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_leave_entitlement_btn=magic_button_link("./".$current_file_url."?leave_entitlement_uptoken=".$_GET["leave_entitlement_uptoken"]."&conf_deleteleave_entitlement&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_leave_entitlement_btn=magic_button_link("./".$current_file_url."?leave_entitlement_uptoken=".$_GET["leave_entitlement_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_leave_entitlement_btn." ".$cancel_del_leave_entitlement_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_leave_entitlement_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteleave_entitlement"]))
      {
         $gwauthenticate_leave_entitlement_=gw_oauth("table", magic_current_url(), "leave_entitlement", "super_delete_confirm","");

         $gwauthenticate_leave_entitlement_json=json_decode($gwauthenticate_leave_entitlement_, true);
         	
          //echo $gwauthenticate_leave_entitlement_;

         if($gwauthenticate_leave_entitlement_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $leave_entitlement_del_key_salt=initialize_leave_entitlement()["leave_cart_id"];
      mosy_sql_rollback("leave_entitlement", "primkey='$leave_entitlement_uptoken'", "DELETE");
      drop_leave_entitlement("primkey='$leave_entitlement_uptoken' and leave_cart_id='$leave_entitlement_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_leave_entitlement_);

      }
      }

      //== End leave_entitlement delete record  
    
       ///SELECT STRING FOR leave_entitlement============================
              
       if(isset($_POST["qleave_entitlement_btn"])){
         $gwauthenticate_leave_entitlement_=gw_oauth("table", magic_current_url(), "leave_entitlement", "qleave_entitlement_btn","");

         $gwauthenticate_leave_entitlement_json=json_decode($gwauthenticate_leave_entitlement_, true);
         	
          //echo $gwauthenticate_leave_entitlement_;

         if($gwauthenticate_leave_entitlement_json["response"]=="ok")
         {
            $current_leave_entitlement_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_leave_entitlement_current_url=$current_leave_entitlement_url_params.'?qleave_entitlement=';
            if (strpos($current_leave_entitlement_url_params, '?') !== false) {

                $clean_leave_entitlement_current_url=$current_leave_entitlement_url_params.'&qleave_entitlement=';

            }
            if (strpos($current_leave_entitlement_url_params, '?qleave_entitlement')) {

                $remove_leave_entitlement_old_token = substr($current_leave_entitlement_url_params, 0, strpos($current_leave_entitlement_url_params, "?qleave_entitlement"));

                $clean_leave_entitlement_current_url=$remove_leave_entitlement_old_token.'?qleave_entitlement=';

            }
            if(strpos($current_leave_entitlement_url_params, '&qleave_entitlement')) {

                $remove_leave_entitlement_old_token = substr($current_leave_entitlement_url_params, 0, strpos($current_leave_entitlement_url_params, "&qleave_entitlement"));

                $clean_leave_entitlement_current_url=$remove_leave_entitlement_old_token.'&qleave_entitlement=';

            }
        $qleave_entitlement_str=base64_encode($_POST["txt_leave_entitlement"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_leave_entitlement_current_url.($qleave_entitlement_str);
            } 

          }else{ 
             header('location:'.$clean_leave_entitlement_current_url.($qleave_entitlement_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_leave_entitlement_);

        }
        }
        $qleave_entitlement="";
		if(isset($_GET["leave_entitlement_mosyfilter"]) && isset($_GET["qleave_entitlement"])){
         $gwauthenticate_leave_entitlement_=gw_oauth("table", magic_current_url(), "leave_entitlement", "leave_entitlement_mosyfilter_n_query","");

         $gwauthenticate_leave_entitlement_json=json_decode($gwauthenticate_leave_entitlement_, true);
         	
          //echo $gwauthenticate_leave_entitlement_;

         if($gwauthenticate_leave_entitlement_json["response"]=="ok")
         {
         $qleave_entitlement=mmres(base64_decode($_GET["qleave_entitlement"]));
         
         $gft_leave_entitlement_where_query="(`leave_cart_id` LIKE '%".$qleave_entitlement."%' OR  `leave_code` LIKE '%".$qleave_entitlement."%' OR  `leave_title` LIKE '%".$qleave_entitlement."%' OR  `gender` LIKE '%".$qleave_entitlement."%' OR  `max_days_in_year` LIKE '%".$qleave_entitlement."%' OR  `leave_day` LIKE '%".$qleave_entitlement."%' OR  `leave_year_starts` LIKE '%".$qleave_entitlement."%' OR  `max_days_carried_fwd` LIKE '%".$qleave_entitlement."%' OR  `max_negative_bal` LIKE '%".$qleave_entitlement."%' OR  `eligible_employement_type` LIKE '%".$qleave_entitlement."%' OR  `mandatory_attatchment` LIKE '%".$qleave_entitlement."%' OR  `leave_pay` LIKE '%".$qleave_entitlement."%' OR  `remark` LIKE '%".$qleave_entitlement."%' OR  `owner` LIKE '%".$qleave_entitlement."%')";
         
         if($_GET["leave_entitlement_mosyfilter"]!=""){
         
         $mosyfilter_leave_entitlement_queries_str=(base64_decode($_GET["leave_entitlement_mosyfilter"]));
        
         $gft_leave_entitlement_where_query="(`leave_cart_id` LIKE '%".$qleave_entitlement."%' OR  `leave_code` LIKE '%".$qleave_entitlement."%' OR  `leave_title` LIKE '%".$qleave_entitlement."%' OR  `gender` LIKE '%".$qleave_entitlement."%' OR  `max_days_in_year` LIKE '%".$qleave_entitlement."%' OR  `leave_day` LIKE '%".$qleave_entitlement."%' OR  `leave_year_starts` LIKE '%".$qleave_entitlement."%' OR  `max_days_carried_fwd` LIKE '%".$qleave_entitlement."%' OR  `max_negative_bal` LIKE '%".$qleave_entitlement."%' OR  `eligible_employement_type` LIKE '%".$qleave_entitlement."%' OR  `mandatory_attatchment` LIKE '%".$qleave_entitlement."%' OR  `leave_pay` LIKE '%".$qleave_entitlement."%' OR  `remark` LIKE '%".$qleave_entitlement."%' OR  `owner` LIKE '%".$qleave_entitlement."%') AND ".$mosyfilter_leave_entitlement_queries_str."";
         
         }
         
		 $gft_leave_entitlement="WHERE ".$gft_leave_entitlement_where_query;
         
         $gft_leave_entitlement_and=$gft_leave_entitlement_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_leave_entitlement_);
        }
        }elseif(isset($_GET["qleave_entitlement"])){
         $gwauthenticate_leave_entitlement_=gw_oauth("table", magic_current_url(), "leave_entitlement", "get_qleave_entitlement","");

         $gwauthenticate_leave_entitlement_json=json_decode($gwauthenticate_leave_entitlement_, true);
         	
          //echo $gwauthenticate_leave_entitlement_;

         if($gwauthenticate_leave_entitlement_json["response"]=="ok")
         {
		 $qleave_entitlement=mmres(base64_decode($_GET["qleave_entitlement"]));
        
         $gft_leave_entitlement_where_query="(`leave_cart_id` LIKE '%".$qleave_entitlement."%' OR  `leave_code` LIKE '%".$qleave_entitlement."%' OR  `leave_title` LIKE '%".$qleave_entitlement."%' OR  `gender` LIKE '%".$qleave_entitlement."%' OR  `max_days_in_year` LIKE '%".$qleave_entitlement."%' OR  `leave_day` LIKE '%".$qleave_entitlement."%' OR  `leave_year_starts` LIKE '%".$qleave_entitlement."%' OR  `max_days_carried_fwd` LIKE '%".$qleave_entitlement."%' OR  `max_negative_bal` LIKE '%".$qleave_entitlement."%' OR  `eligible_employement_type` LIKE '%".$qleave_entitlement."%' OR  `mandatory_attatchment` LIKE '%".$qleave_entitlement."%' OR  `leave_pay` LIKE '%".$qleave_entitlement."%' OR  `remark` LIKE '%".$qleave_entitlement."%' OR  `owner` LIKE '%".$qleave_entitlement."%')";
         
         $gft_leave_entitlement="WHERE ".$gft_leave_entitlement_where_query;
         
         $gft_leave_entitlement_and=$gft_leave_entitlement_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_leave_entitlement_);

        }
        }elseif(isset($_GET["leave_entitlement_mosyfilter"])){
         $gwauthenticate_leave_entitlement_=gw_oauth("table", magic_current_url(), "leave_entitlement", "leave_entitlement_mosyfilter","");

         $gwauthenticate_leave_entitlement_json=json_decode($gwauthenticate_leave_entitlement_, true);
         	
          //echo $gwauthenticate_leave_entitlement_;

         if($gwauthenticate_leave_entitlement_json["response"]=="ok")
         {
         $gft_leave_entitlement_where_query="";
         $gft_leave_entitlement="";

         if($_GET["leave_entitlement_mosyfilter"]!=""){
          $gft_leave_entitlement_where_query=(base64_decode($_GET["leave_entitlement_mosyfilter"]));
          $gft_leave_entitlement="WHERE ".$gft_leave_entitlement_where_query;
         }
         
         
         $gft_leave_entitlement_and=$gft_leave_entitlement_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_leave_entitlement_);

        }
        }else{
         $gft_leave_entitlement="";
         $gft_leave_entitlement_and="";
         $gft_leave_entitlement_where_query="";
        }
       
    //************************************************* END  leave_entitlement OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section loan_repayment
  //************************************************* START  loan_repayment OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize loan_repayment edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['loan_repayment_table_alert']))
              	{	
                  if(isset($loan_repayment_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$loan_repayment_uptoken="";

		if(isset($_GET["loan_repayment_uptoken"]))
		{
		$loan_repayment_uptoken=base64_decode($_GET["loan_repayment_uptoken"]);
		}
        
        if(isset($_POST["loan_repayment_uptoken"]))
		{
		$loan_repayment_uptoken=base64_decode($_POST["loan_repayment_uptoken"]);
		}
        //
        
          $loan_repayment_alias_name="LOAN REPAYMENT";

          if(isset($loan_repayment_alias))
          {
             $loan_repayment_alias_name=$loan_repayment_alias;

          }
          
        //get single data record query with $loan_repayment_uptoken
        
        ///$loan_repayment_node=get_loan_repayment("*", "WHERE primkey='$loan_repayment_uptoken'", "r");
        
	
//************* START INSERT  loan_repayment QUERY 
if(isset($_POST["loan_repayment_insert_btn"])){
//------- begin loan_repayment_arr_ins --> 
$loan_repayment_arr_ins_=array(

"primkey"=>"NULL",
"payment_id"=>magic_random_str(7),
"loan_id"=>"?",
"loan_number"=>"?",
"date_paid"=>"?",
"princ_plus_int"=>"?",
"amount_repaid"=>"?",
"loan_balance"=>"?",
"staff_id"=>"?",
"owner"=>"?",
"remark"=>"?"

);
//===-- End loan_repayment_arr_ins -->


          
         $gwauthenticate_loan_repayment_=gw_oauth("table", magic_current_url(), "loan_repayment", "insert","");

         $gwauthenticate_loan_repayment_json=json_decode($gwauthenticate_loan_repayment_, true);
         	
          //echo $gwauthenticate_loan_repayment_;

         if($gwauthenticate_loan_repayment_json["response"]=="ok")
         {

              $loan_repayment_validated_ins_str=$loan_repayment_arr_ins_;

              if(isset($loan_repayment_ins_inputs))
              {
                $loan_repayment_validated_ins_str=$loan_repayment_ins_inputs;	
              }

              if(empty($loan_repayment_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$loan_repayment_alias_name." request cannot be empty. Record not added");
              }else{

                $loan_repayment_return_key=add_loan_repayment($loan_repayment_validated_ins_str);
                
                mosy_sql_rollback("loan_repayment", "primkey='$loan_repayment_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $loan_repayment_return_key; 

                      } 

                    }else{ 

                                    
                $loan_repayment_custom_redir1=add_url_param ("loan_repayment_uptoken", base64_encode($loan_repayment_return_key), "");
                $loan_repayment_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$loan_repayment_custom_redir1);
                $loan_repayment_custom_redir3=add_url_param ("loan_repayment_table_alert", "loan_repayment_added",$loan_repayment_custom_redir2);
                
                ///echo magic_message($loan_repayment_custom_redir1." -- ".$loan_repayment_custom_redir2."--".$loan_repayment_custom_redir3);
                
                $loan_repayment_custom_redir=$loan_repayment_custom_redir3;
                
               header('location:'.$loan_repayment_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_loan_repayment_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_loan_repayment_)."");
         
         }
      
}
//************* END  loan_repayment INSERT QUERY 	
	

//************* START loan_repayment  UPDATE QUERY 
if(isset($_POST["loan_repayment_update_btn"])){
//------- begin loan_repayment_arr_updt --> 
$loan_repayment_arr_updt_=array(
"loan_id"=>"?",
"loan_number"=>"?",
"date_paid"=>"?",
"princ_plus_int"=>"?",
"amount_repaid"=>"?",
"loan_balance"=>"?",
"staff_id"=>"?",
"owner"=>"?",
"remark"=>"?"

);
//===-- End loan_repayment_arr_updt -->
                     
         $gwauthenticate_loan_repayment_=gw_oauth("table", magic_current_url(), "loan_repayment", "update","");

         $gwauthenticate_loan_repayment_json=json_decode($gwauthenticate_loan_repayment_, true);
         	
          //echo $gwauthenticate_loan_repayment_;

         if($gwauthenticate_loan_repayment_json["response"]=="ok")
         {
         
            $loan_repayment_validated_updt_str=$loan_repayment_arr_updt_;

            if(isset($loan_repayment_updt_inputs))
            {
              $loan_repayment_validated_updt_str=$loan_repayment_updt_inputs;	
            }

            if(empty($loan_repayment_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$loan_repayment_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$loan_repayment_key_salt=initialize_loan_repayment()["payment_id"];
            
              update_loan_repayment($loan_repayment_validated_updt_str, "primkey='$loan_repayment_uptoken' and payment_id='$loan_repayment_key_salt'");
				

			 mosy_sql_rollback("loan_repayment", "primkey='$loan_repayment_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $loan_repayment_uptoken; 

                    } 

                  }else{ 

                $loan_repayment_custom_redir1=add_url_param ("loan_repayment_uptoken", base64_encode($loan_repayment_uptoken), "");
                $loan_repayment_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$loan_repayment_custom_redir1);
                $loan_repayment_custom_redir3=add_url_param ("loan_repayment_table_alert", "loan_repayment_updated",$loan_repayment_custom_redir2);
                
                ///echo magic_message($loan_repayment_custom_redir1." -- ".$loan_repayment_custom_redir2."--".$loan_repayment_custom_redir3);
                
                $loan_repayment_custom_redir=$loan_repayment_custom_redir3;
                
               header('location:'.$loan_repayment_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_loan_repayment_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_loan_repayment_)."");
         
         }

      

      
}
//************* END loan_repayment  UPDATE QUERY 

    
    
      //== Start loan_repayment delete record

      if(isset($_GET["deleteloan_repayment"]))
      {
         $gwauthenticate_loan_repayment_=gw_oauth("table", magic_current_url(), "loan_repayment", "super_delete_request","");

         $gwauthenticate_loan_repayment_json=json_decode($gwauthenticate_loan_repayment_, true);
         	
          //echo $gwauthenticate_loan_repayment_;

         if($gwauthenticate_loan_repayment_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_loan_repayment_btn=magic_button_link("./".$current_file_url."?loan_repayment_uptoken=".$_GET["loan_repayment_uptoken"]."&conf_deleteloan_repayment&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_loan_repayment_btn=magic_button_link("./".$current_file_url."?loan_repayment_uptoken=".$_GET["loan_repayment_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_loan_repayment_btn." ".$cancel_del_loan_repayment_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_loan_repayment_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteloan_repayment"]))
      {
         $gwauthenticate_loan_repayment_=gw_oauth("table", magic_current_url(), "loan_repayment", "super_delete_confirm","");

         $gwauthenticate_loan_repayment_json=json_decode($gwauthenticate_loan_repayment_, true);
         	
          //echo $gwauthenticate_loan_repayment_;

         if($gwauthenticate_loan_repayment_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $loan_repayment_del_key_salt=initialize_loan_repayment()["payment_id"];
      mosy_sql_rollback("loan_repayment", "primkey='$loan_repayment_uptoken'", "DELETE");
      drop_loan_repayment("primkey='$loan_repayment_uptoken' and payment_id='$loan_repayment_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_loan_repayment_);

      }
      }

      //== End loan_repayment delete record  
    
       ///SELECT STRING FOR loan_repayment============================
              
       if(isset($_POST["qloan_repayment_btn"])){
         $gwauthenticate_loan_repayment_=gw_oauth("table", magic_current_url(), "loan_repayment", "qloan_repayment_btn","");

         $gwauthenticate_loan_repayment_json=json_decode($gwauthenticate_loan_repayment_, true);
         	
          //echo $gwauthenticate_loan_repayment_;

         if($gwauthenticate_loan_repayment_json["response"]=="ok")
         {
            $current_loan_repayment_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_loan_repayment_current_url=$current_loan_repayment_url_params.'?qloan_repayment=';
            if (strpos($current_loan_repayment_url_params, '?') !== false) {

                $clean_loan_repayment_current_url=$current_loan_repayment_url_params.'&qloan_repayment=';

            }
            if (strpos($current_loan_repayment_url_params, '?qloan_repayment')) {

                $remove_loan_repayment_old_token = substr($current_loan_repayment_url_params, 0, strpos($current_loan_repayment_url_params, "?qloan_repayment"));

                $clean_loan_repayment_current_url=$remove_loan_repayment_old_token.'?qloan_repayment=';

            }
            if(strpos($current_loan_repayment_url_params, '&qloan_repayment')) {

                $remove_loan_repayment_old_token = substr($current_loan_repayment_url_params, 0, strpos($current_loan_repayment_url_params, "&qloan_repayment"));

                $clean_loan_repayment_current_url=$remove_loan_repayment_old_token.'&qloan_repayment=';

            }
        $qloan_repayment_str=base64_encode($_POST["txt_loan_repayment"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_loan_repayment_current_url.($qloan_repayment_str);
            } 

          }else{ 
             header('location:'.$clean_loan_repayment_current_url.($qloan_repayment_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_loan_repayment_);

        }
        }
        $qloan_repayment="";
		if(isset($_GET["loan_repayment_mosyfilter"]) && isset($_GET["qloan_repayment"])){
         $gwauthenticate_loan_repayment_=gw_oauth("table", magic_current_url(), "loan_repayment", "loan_repayment_mosyfilter_n_query","");

         $gwauthenticate_loan_repayment_json=json_decode($gwauthenticate_loan_repayment_, true);
         	
          //echo $gwauthenticate_loan_repayment_;

         if($gwauthenticate_loan_repayment_json["response"]=="ok")
         {
         $qloan_repayment=mmres(base64_decode($_GET["qloan_repayment"]));
         
         $gft_loan_repayment_where_query="(`payment_id` LIKE '%".$qloan_repayment."%' OR  `loan_id` LIKE '%".$qloan_repayment."%' OR  `loan_number` LIKE '%".$qloan_repayment."%' OR  `date_paid` LIKE '%".$qloan_repayment."%' OR  `princ_plus_int` LIKE '%".$qloan_repayment."%' OR  `amount_repaid` LIKE '%".$qloan_repayment."%' OR  `loan_balance` LIKE '%".$qloan_repayment."%' OR  `staff_id` LIKE '%".$qloan_repayment."%' OR  `owner` LIKE '%".$qloan_repayment."%' OR  `remark` LIKE '%".$qloan_repayment."%')";
         
         if($_GET["loan_repayment_mosyfilter"]!=""){
         
         $mosyfilter_loan_repayment_queries_str=(base64_decode($_GET["loan_repayment_mosyfilter"]));
        
         $gft_loan_repayment_where_query="(`payment_id` LIKE '%".$qloan_repayment."%' OR  `loan_id` LIKE '%".$qloan_repayment."%' OR  `loan_number` LIKE '%".$qloan_repayment."%' OR  `date_paid` LIKE '%".$qloan_repayment."%' OR  `princ_plus_int` LIKE '%".$qloan_repayment."%' OR  `amount_repaid` LIKE '%".$qloan_repayment."%' OR  `loan_balance` LIKE '%".$qloan_repayment."%' OR  `staff_id` LIKE '%".$qloan_repayment."%' OR  `owner` LIKE '%".$qloan_repayment."%' OR  `remark` LIKE '%".$qloan_repayment."%') AND ".$mosyfilter_loan_repayment_queries_str."";
         
         }
         
		 $gft_loan_repayment="WHERE ".$gft_loan_repayment_where_query;
         
         $gft_loan_repayment_and=$gft_loan_repayment_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_loan_repayment_);
        }
        }elseif(isset($_GET["qloan_repayment"])){
         $gwauthenticate_loan_repayment_=gw_oauth("table", magic_current_url(), "loan_repayment", "get_qloan_repayment","");

         $gwauthenticate_loan_repayment_json=json_decode($gwauthenticate_loan_repayment_, true);
         	
          //echo $gwauthenticate_loan_repayment_;

         if($gwauthenticate_loan_repayment_json["response"]=="ok")
         {
		 $qloan_repayment=mmres(base64_decode($_GET["qloan_repayment"]));
        
         $gft_loan_repayment_where_query="(`payment_id` LIKE '%".$qloan_repayment."%' OR  `loan_id` LIKE '%".$qloan_repayment."%' OR  `loan_number` LIKE '%".$qloan_repayment."%' OR  `date_paid` LIKE '%".$qloan_repayment."%' OR  `princ_plus_int` LIKE '%".$qloan_repayment."%' OR  `amount_repaid` LIKE '%".$qloan_repayment."%' OR  `loan_balance` LIKE '%".$qloan_repayment."%' OR  `staff_id` LIKE '%".$qloan_repayment."%' OR  `owner` LIKE '%".$qloan_repayment."%' OR  `remark` LIKE '%".$qloan_repayment."%')";
         
         $gft_loan_repayment="WHERE ".$gft_loan_repayment_where_query;
         
         $gft_loan_repayment_and=$gft_loan_repayment_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_loan_repayment_);

        }
        }elseif(isset($_GET["loan_repayment_mosyfilter"])){
         $gwauthenticate_loan_repayment_=gw_oauth("table", magic_current_url(), "loan_repayment", "loan_repayment_mosyfilter","");

         $gwauthenticate_loan_repayment_json=json_decode($gwauthenticate_loan_repayment_, true);
         	
          //echo $gwauthenticate_loan_repayment_;

         if($gwauthenticate_loan_repayment_json["response"]=="ok")
         {
         $gft_loan_repayment_where_query="";
         $gft_loan_repayment="";

         if($_GET["loan_repayment_mosyfilter"]!=""){
          $gft_loan_repayment_where_query=(base64_decode($_GET["loan_repayment_mosyfilter"]));
          $gft_loan_repayment="WHERE ".$gft_loan_repayment_where_query;
         }
         
         
         $gft_loan_repayment_and=$gft_loan_repayment_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_loan_repayment_);

        }
        }else{
         $gft_loan_repayment="";
         $gft_loan_repayment_and="";
         $gft_loan_repayment_where_query="";
        }
       
    //************************************************* END  loan_repayment OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section mosy_sql_roll_back
  //************************************************* START  mosy_sql_roll_back OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize mosy_sql_roll_back edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['mosy_sql_roll_back_table_alert']))
              	{	
                  if(isset($mosy_sql_roll_back_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$mosy_sql_roll_back_uptoken="";

		if(isset($_GET["mosy_sql_roll_back_uptoken"]))
		{
		$mosy_sql_roll_back_uptoken=base64_decode($_GET["mosy_sql_roll_back_uptoken"]);
		}
        
        if(isset($_POST["mosy_sql_roll_back_uptoken"]))
		{
		$mosy_sql_roll_back_uptoken=base64_decode($_POST["mosy_sql_roll_back_uptoken"]);
		}
        //
        
          $mosy_sql_roll_back_alias_name="MOSY SQL ROLL BACK";

          if(isset($mosy_sql_roll_back_alias))
          {
             $mosy_sql_roll_back_alias_name=$mosy_sql_roll_back_alias;

          }
          
        //get single data record query with $mosy_sql_roll_back_uptoken
        
        ///$mosy_sql_roll_back_node=get_mosy_sql_roll_back("*", "WHERE primkey='$mosy_sql_roll_back_uptoken'", "r");
        
	
//************* START INSERT  mosy_sql_roll_back QUERY 
if(isset($_POST["mosy_sql_roll_back_insert_btn"])){
//------- begin mosy_sql_roll_back_arr_ins --> 
$mosy_sql_roll_back_arr_ins_=array(

"primkey"=>"NULL",
"roll_bk_key"=>magic_random_str(7),
"table_name"=>"?",
"roll_type"=>"?",
"where_str"=>"?",
"roll_timestamp"=>"?",
"value_entries"=>"?"

);
//===-- End mosy_sql_roll_back_arr_ins -->


          
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "insert","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {

              $mosy_sql_roll_back_validated_ins_str=$mosy_sql_roll_back_arr_ins_;

              if(isset($mosy_sql_roll_back_ins_inputs))
              {
                $mosy_sql_roll_back_validated_ins_str=$mosy_sql_roll_back_ins_inputs;	
              }

              if(empty($mosy_sql_roll_back_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$mosy_sql_roll_back_alias_name." request cannot be empty. Record not added");
              }else{

                $mosy_sql_roll_back_return_key=add_mosy_sql_roll_back($mosy_sql_roll_back_validated_ins_str);
                
                mosy_sql_rollback("mosy_sql_roll_back", "primkey='$mosy_sql_roll_back_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $mosy_sql_roll_back_return_key; 

                      } 

                    }else{ 

                                    
                $mosy_sql_roll_back_custom_redir1=add_url_param ("mosy_sql_roll_back_uptoken", base64_encode($mosy_sql_roll_back_return_key), "");
                $mosy_sql_roll_back_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$mosy_sql_roll_back_custom_redir1);
                $mosy_sql_roll_back_custom_redir3=add_url_param ("mosy_sql_roll_back_table_alert", "mosy_sql_roll_back_added",$mosy_sql_roll_back_custom_redir2);
                
                ///echo magic_message($mosy_sql_roll_back_custom_redir1." -- ".$mosy_sql_roll_back_custom_redir2."--".$mosy_sql_roll_back_custom_redir3);
                
                $mosy_sql_roll_back_custom_redir=$mosy_sql_roll_back_custom_redir3;
                
               header('location:'.$mosy_sql_roll_back_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_mosy_sql_roll_back_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
         
         }
      
}
//************* END  mosy_sql_roll_back INSERT QUERY 	
	

//************* START mosy_sql_roll_back  UPDATE QUERY 
if(isset($_POST["mosy_sql_roll_back_update_btn"])){
//------- begin mosy_sql_roll_back_arr_updt --> 
$mosy_sql_roll_back_arr_updt_=array(
"table_name"=>"?",
"roll_type"=>"?",
"where_str"=>"?",
"roll_timestamp"=>"?",
"value_entries"=>"?"

);
//===-- End mosy_sql_roll_back_arr_updt -->
                     
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "update","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         
            $mosy_sql_roll_back_validated_updt_str=$mosy_sql_roll_back_arr_updt_;

            if(isset($mosy_sql_roll_back_updt_inputs))
            {
              $mosy_sql_roll_back_validated_updt_str=$mosy_sql_roll_back_updt_inputs;	
            }

            if(empty($mosy_sql_roll_back_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$mosy_sql_roll_back_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$mosy_sql_roll_back_key_salt=initialize_mosy_sql_roll_back()["roll_bk_key"];
            
              update_mosy_sql_roll_back($mosy_sql_roll_back_validated_updt_str, "primkey='$mosy_sql_roll_back_uptoken' and roll_bk_key='$mosy_sql_roll_back_key_salt'");
				

			 mosy_sql_rollback("mosy_sql_roll_back", "primkey='$mosy_sql_roll_back_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $mosy_sql_roll_back_uptoken; 

                    } 

                  }else{ 

                $mosy_sql_roll_back_custom_redir1=add_url_param ("mosy_sql_roll_back_uptoken", base64_encode($mosy_sql_roll_back_uptoken), "");
                $mosy_sql_roll_back_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$mosy_sql_roll_back_custom_redir1);
                $mosy_sql_roll_back_custom_redir3=add_url_param ("mosy_sql_roll_back_table_alert", "mosy_sql_roll_back_updated",$mosy_sql_roll_back_custom_redir2);
                
                ///echo magic_message($mosy_sql_roll_back_custom_redir1." -- ".$mosy_sql_roll_back_custom_redir2."--".$mosy_sql_roll_back_custom_redir3);
                
                $mosy_sql_roll_back_custom_redir=$mosy_sql_roll_back_custom_redir3;
                
               header('location:'.$mosy_sql_roll_back_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_mosy_sql_roll_back_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_mosy_sql_roll_back_)."");
         
         }

      

      
}
//************* END mosy_sql_roll_back  UPDATE QUERY 

    
    
      //== Start mosy_sql_roll_back delete record

      if(isset($_GET["deletemosy_sql_roll_back"]))
      {
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "super_delete_request","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_mosy_sql_roll_back_btn=magic_button_link("./".$current_file_url."?mosy_sql_roll_back_uptoken=".$_GET["mosy_sql_roll_back_uptoken"]."&conf_deletemosy_sql_roll_back&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_mosy_sql_roll_back_btn=magic_button_link("./".$current_file_url."?mosy_sql_roll_back_uptoken=".$_GET["mosy_sql_roll_back_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_mosy_sql_roll_back_btn." ".$cancel_del_mosy_sql_roll_back_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletemosy_sql_roll_back"]))
      {
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "super_delete_confirm","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $mosy_sql_roll_back_del_key_salt=initialize_mosy_sql_roll_back()["roll_bk_key"];
      mosy_sql_rollback("mosy_sql_roll_back", "primkey='$mosy_sql_roll_back_uptoken'", "DELETE");
      drop_mosy_sql_roll_back("primkey='$mosy_sql_roll_back_uptoken' and roll_bk_key='$mosy_sql_roll_back_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

      }
      }

      //== End mosy_sql_roll_back delete record  
    
       ///SELECT STRING FOR mosy_sql_roll_back============================
              
       if(isset($_POST["qmosy_sql_roll_back_btn"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "qmosy_sql_roll_back_btn","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
            $current_mosy_sql_roll_back_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_mosy_sql_roll_back_current_url=$current_mosy_sql_roll_back_url_params.'?qmosy_sql_roll_back=';
            if (strpos($current_mosy_sql_roll_back_url_params, '?') !== false) {

                $clean_mosy_sql_roll_back_current_url=$current_mosy_sql_roll_back_url_params.'&qmosy_sql_roll_back=';

            }
            if (strpos($current_mosy_sql_roll_back_url_params, '?qmosy_sql_roll_back')) {

                $remove_mosy_sql_roll_back_old_token = substr($current_mosy_sql_roll_back_url_params, 0, strpos($current_mosy_sql_roll_back_url_params, "?qmosy_sql_roll_back"));

                $clean_mosy_sql_roll_back_current_url=$remove_mosy_sql_roll_back_old_token.'?qmosy_sql_roll_back=';

            }
            if(strpos($current_mosy_sql_roll_back_url_params, '&qmosy_sql_roll_back')) {

                $remove_mosy_sql_roll_back_old_token = substr($current_mosy_sql_roll_back_url_params, 0, strpos($current_mosy_sql_roll_back_url_params, "&qmosy_sql_roll_back"));

                $clean_mosy_sql_roll_back_current_url=$remove_mosy_sql_roll_back_old_token.'&qmosy_sql_roll_back=';

            }
        $qmosy_sql_roll_back_str=base64_encode($_POST["txt_mosy_sql_roll_back"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_mosy_sql_roll_back_current_url.($qmosy_sql_roll_back_str);
            } 

          }else{ 
             header('location:'.$clean_mosy_sql_roll_back_current_url.($qmosy_sql_roll_back_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

        }
        }
        $qmosy_sql_roll_back="";
		if(isset($_GET["mosy_sql_roll_back_mosyfilter"]) && isset($_GET["qmosy_sql_roll_back"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "mosy_sql_roll_back_mosyfilter_n_query","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         $qmosy_sql_roll_back=mmres(base64_decode($_GET["qmosy_sql_roll_back"]));
         
         $gft_mosy_sql_roll_back_where_query="(`roll_bk_key` LIKE '%".$qmosy_sql_roll_back."%' OR  `table_name` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_type` LIKE '%".$qmosy_sql_roll_back."%' OR  `where_str` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_timestamp` LIKE '%".$qmosy_sql_roll_back."%' OR  `value_entries` LIKE '%".$qmosy_sql_roll_back."%')";
         
         if($_GET["mosy_sql_roll_back_mosyfilter"]!=""){
         
         $mosyfilter_mosy_sql_roll_back_queries_str=(base64_decode($_GET["mosy_sql_roll_back_mosyfilter"]));
        
         $gft_mosy_sql_roll_back_where_query="(`roll_bk_key` LIKE '%".$qmosy_sql_roll_back."%' OR  `table_name` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_type` LIKE '%".$qmosy_sql_roll_back."%' OR  `where_str` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_timestamp` LIKE '%".$qmosy_sql_roll_back."%' OR  `value_entries` LIKE '%".$qmosy_sql_roll_back."%') AND ".$mosyfilter_mosy_sql_roll_back_queries_str."";
         
         }
         
		 $gft_mosy_sql_roll_back="WHERE ".$gft_mosy_sql_roll_back_where_query;
         
         $gft_mosy_sql_roll_back_and=$gft_mosy_sql_roll_back_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_mosy_sql_roll_back_);
        }
        }elseif(isset($_GET["qmosy_sql_roll_back"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "get_qmosy_sql_roll_back","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
		 $qmosy_sql_roll_back=mmres(base64_decode($_GET["qmosy_sql_roll_back"]));
        
         $gft_mosy_sql_roll_back_where_query="(`roll_bk_key` LIKE '%".$qmosy_sql_roll_back."%' OR  `table_name` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_type` LIKE '%".$qmosy_sql_roll_back."%' OR  `where_str` LIKE '%".$qmosy_sql_roll_back."%' OR  `roll_timestamp` LIKE '%".$qmosy_sql_roll_back."%' OR  `value_entries` LIKE '%".$qmosy_sql_roll_back."%')";
         
         $gft_mosy_sql_roll_back="WHERE ".$gft_mosy_sql_roll_back_where_query;
         
         $gft_mosy_sql_roll_back_and=$gft_mosy_sql_roll_back_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

        }
        }elseif(isset($_GET["mosy_sql_roll_back_mosyfilter"])){
         $gwauthenticate_mosy_sql_roll_back_=gw_oauth("table", magic_current_url(), "mosy_sql_roll_back", "mosy_sql_roll_back_mosyfilter","");

         $gwauthenticate_mosy_sql_roll_back_json=json_decode($gwauthenticate_mosy_sql_roll_back_, true);
         	
          //echo $gwauthenticate_mosy_sql_roll_back_;

         if($gwauthenticate_mosy_sql_roll_back_json["response"]=="ok")
         {
         $gft_mosy_sql_roll_back_where_query="";
         $gft_mosy_sql_roll_back="";

         if($_GET["mosy_sql_roll_back_mosyfilter"]!=""){
          $gft_mosy_sql_roll_back_where_query=(base64_decode($_GET["mosy_sql_roll_back_mosyfilter"]));
          $gft_mosy_sql_roll_back="WHERE ".$gft_mosy_sql_roll_back_where_query;
         }
         
         
         $gft_mosy_sql_roll_back_and=$gft_mosy_sql_roll_back_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_mosy_sql_roll_back_);

        }
        }else{
         $gft_mosy_sql_roll_back="";
         $gft_mosy_sql_roll_back_and="";
         $gft_mosy_sql_roll_back_where_query="";
        }
       
    //************************************************* END  mosy_sql_roll_back OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section payroll_list
  //************************************************* START  payroll_list OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize payroll_list edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['payroll_list_table_alert']))
              	{	
                  if(isset($payroll_list_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$payroll_list_uptoken="";

		if(isset($_GET["payroll_list_uptoken"]))
		{
		$payroll_list_uptoken=base64_decode($_GET["payroll_list_uptoken"]);
		}
        
        if(isset($_POST["payroll_list_uptoken"]))
		{
		$payroll_list_uptoken=base64_decode($_POST["payroll_list_uptoken"]);
		}
        //
        
          $payroll_list_alias_name="PAYROLL LIST";

          if(isset($payroll_list_alias))
          {
             $payroll_list_alias_name=$payroll_list_alias;

          }
          
        //get single data record query with $payroll_list_uptoken
        
        ///$payroll_list_node=get_payroll_list("*", "WHERE primkey='$payroll_list_uptoken'", "r");
        
	
//************* START INSERT  payroll_list QUERY 
if(isset($_POST["payroll_list_insert_btn"])){
//------- begin payroll_list_arr_ins --> 
$payroll_list_arr_ins_=array(

"primkey"=>"NULL",
"payroll_id"=>magic_random_str(7),
"payroll_month_year"=>"?",
"payroll_date"=>"?",
"staff_id"=>"?",
"job_group"=>"?",
"basicsalary"=>"?",
"bonus_and_commissions"=>"?",
"deductions"=>"?",
"payroll_number"=>"?",
"nhif"=>"?",
"nssf"=>"?",
"tax"=>"?",
"net_salary"=>"?",
"payroll_notes"=>"?",
"owner"=>"?",
"allowances"=>"?",
"gross_sal"=>"?",
"loan"=>"?"

);
//===-- End payroll_list_arr_ins -->


          
         $gwauthenticate_payroll_list_=gw_oauth("table", magic_current_url(), "payroll_list", "insert","");

         $gwauthenticate_payroll_list_json=json_decode($gwauthenticate_payroll_list_, true);
         	
          //echo $gwauthenticate_payroll_list_;

         if($gwauthenticate_payroll_list_json["response"]=="ok")
         {

              $payroll_list_validated_ins_str=$payroll_list_arr_ins_;

              if(isset($payroll_list_ins_inputs))
              {
                $payroll_list_validated_ins_str=$payroll_list_ins_inputs;	
              }

              if(empty($payroll_list_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$payroll_list_alias_name." request cannot be empty. Record not added");
              }else{

                $payroll_list_return_key=add_payroll_list($payroll_list_validated_ins_str);
                
                mosy_sql_rollback("payroll_list", "primkey='$payroll_list_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $payroll_list_return_key; 

                      } 

                    }else{ 

                                    
                $payroll_list_custom_redir1=add_url_param ("payroll_list_uptoken", base64_encode($payroll_list_return_key), "");
                $payroll_list_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$payroll_list_custom_redir1);
                $payroll_list_custom_redir3=add_url_param ("payroll_list_table_alert", "payroll_list_added",$payroll_list_custom_redir2);
                
                ///echo magic_message($payroll_list_custom_redir1." -- ".$payroll_list_custom_redir2."--".$payroll_list_custom_redir3);
                
                $payroll_list_custom_redir=$payroll_list_custom_redir3;
                
               header('location:'.$payroll_list_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_payroll_list_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_payroll_list_)."");
         
         }
      
}
//************* END  payroll_list INSERT QUERY 	
	

//************* START payroll_list  UPDATE QUERY 
if(isset($_POST["payroll_list_update_btn"])){
//------- begin payroll_list_arr_updt --> 
$payroll_list_arr_updt_=array(
"payroll_month_year"=>"?",
"payroll_date"=>"?",
"staff_id"=>"?",
"job_group"=>"?",
"basicsalary"=>"?",
"bonus_and_commissions"=>"?",
"deductions"=>"?",
"payroll_number"=>"?",
"nhif"=>"?",
"nssf"=>"?",
"tax"=>"?",
"net_salary"=>"?",
"payroll_notes"=>"?",
"owner"=>"?",
"allowances"=>"?",
"gross_sal"=>"?",
"loan"=>"?"

);
//===-- End payroll_list_arr_updt -->
                     
         $gwauthenticate_payroll_list_=gw_oauth("table", magic_current_url(), "payroll_list", "update","");

         $gwauthenticate_payroll_list_json=json_decode($gwauthenticate_payroll_list_, true);
         	
          //echo $gwauthenticate_payroll_list_;

         if($gwauthenticate_payroll_list_json["response"]=="ok")
         {
         
            $payroll_list_validated_updt_str=$payroll_list_arr_updt_;

            if(isset($payroll_list_updt_inputs))
            {
              $payroll_list_validated_updt_str=$payroll_list_updt_inputs;	
            }

            if(empty($payroll_list_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$payroll_list_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$payroll_list_key_salt=initialize_payroll_list()["payroll_id"];
            
              update_payroll_list($payroll_list_validated_updt_str, "primkey='$payroll_list_uptoken' and payroll_id='$payroll_list_key_salt'");
				

			 mosy_sql_rollback("payroll_list", "primkey='$payroll_list_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $payroll_list_uptoken; 

                    } 

                  }else{ 

                $payroll_list_custom_redir1=add_url_param ("payroll_list_uptoken", base64_encode($payroll_list_uptoken), "");
                $payroll_list_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$payroll_list_custom_redir1);
                $payroll_list_custom_redir3=add_url_param ("payroll_list_table_alert", "payroll_list_updated",$payroll_list_custom_redir2);
                
                ///echo magic_message($payroll_list_custom_redir1." -- ".$payroll_list_custom_redir2."--".$payroll_list_custom_redir3);
                
                $payroll_list_custom_redir=$payroll_list_custom_redir3;
                
               header('location:'.$payroll_list_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_payroll_list_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_payroll_list_)."");
         
         }

      

      
}
//************* END payroll_list  UPDATE QUERY 

    
    
      //== Start payroll_list delete record

      if(isset($_GET["deletepayroll_list"]))
      {
         $gwauthenticate_payroll_list_=gw_oauth("table", magic_current_url(), "payroll_list", "super_delete_request","");

         $gwauthenticate_payroll_list_json=json_decode($gwauthenticate_payroll_list_, true);
         	
          //echo $gwauthenticate_payroll_list_;

         if($gwauthenticate_payroll_list_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_payroll_list_btn=magic_button_link("./".$current_file_url."?payroll_list_uptoken=".$_GET["payroll_list_uptoken"]."&conf_deletepayroll_list&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_payroll_list_btn=magic_button_link("./".$current_file_url."?payroll_list_uptoken=".$_GET["payroll_list_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_payroll_list_btn." ".$cancel_del_payroll_list_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_payroll_list_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletepayroll_list"]))
      {
         $gwauthenticate_payroll_list_=gw_oauth("table", magic_current_url(), "payroll_list", "super_delete_confirm","");

         $gwauthenticate_payroll_list_json=json_decode($gwauthenticate_payroll_list_, true);
         	
          //echo $gwauthenticate_payroll_list_;

         if($gwauthenticate_payroll_list_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $payroll_list_del_key_salt=initialize_payroll_list()["payroll_id"];
      mosy_sql_rollback("payroll_list", "primkey='$payroll_list_uptoken'", "DELETE");
      drop_payroll_list("primkey='$payroll_list_uptoken' and payroll_id='$payroll_list_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_payroll_list_);

      }
      }

      //== End payroll_list delete record  
    
       ///SELECT STRING FOR payroll_list============================
              
       if(isset($_POST["qpayroll_list_btn"])){
         $gwauthenticate_payroll_list_=gw_oauth("table", magic_current_url(), "payroll_list", "qpayroll_list_btn","");

         $gwauthenticate_payroll_list_json=json_decode($gwauthenticate_payroll_list_, true);
         	
          //echo $gwauthenticate_payroll_list_;

         if($gwauthenticate_payroll_list_json["response"]=="ok")
         {
            $current_payroll_list_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_payroll_list_current_url=$current_payroll_list_url_params.'?qpayroll_list=';
            if (strpos($current_payroll_list_url_params, '?') !== false) {

                $clean_payroll_list_current_url=$current_payroll_list_url_params.'&qpayroll_list=';

            }
            if (strpos($current_payroll_list_url_params, '?qpayroll_list')) {

                $remove_payroll_list_old_token = substr($current_payroll_list_url_params, 0, strpos($current_payroll_list_url_params, "?qpayroll_list"));

                $clean_payroll_list_current_url=$remove_payroll_list_old_token.'?qpayroll_list=';

            }
            if(strpos($current_payroll_list_url_params, '&qpayroll_list')) {

                $remove_payroll_list_old_token = substr($current_payroll_list_url_params, 0, strpos($current_payroll_list_url_params, "&qpayroll_list"));

                $clean_payroll_list_current_url=$remove_payroll_list_old_token.'&qpayroll_list=';

            }
        $qpayroll_list_str=base64_encode($_POST["txt_payroll_list"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_payroll_list_current_url.($qpayroll_list_str);
            } 

          }else{ 
             header('location:'.$clean_payroll_list_current_url.($qpayroll_list_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_payroll_list_);

        }
        }
        $qpayroll_list="";
		if(isset($_GET["payroll_list_mosyfilter"]) && isset($_GET["qpayroll_list"])){
         $gwauthenticate_payroll_list_=gw_oauth("table", magic_current_url(), "payroll_list", "payroll_list_mosyfilter_n_query","");

         $gwauthenticate_payroll_list_json=json_decode($gwauthenticate_payroll_list_, true);
         	
          //echo $gwauthenticate_payroll_list_;

         if($gwauthenticate_payroll_list_json["response"]=="ok")
         {
         $qpayroll_list=mmres(base64_decode($_GET["qpayroll_list"]));
         
         $gft_payroll_list_where_query="(`payroll_id` LIKE '%".$qpayroll_list."%' OR  `payroll_month_year` LIKE '%".$qpayroll_list."%' OR  `payroll_date` LIKE '%".$qpayroll_list."%' OR  `staff_id` LIKE '%".$qpayroll_list."%' OR  `job_group` LIKE '%".$qpayroll_list."%' OR  `basicsalary` LIKE '%".$qpayroll_list."%' OR  `bonus_and_commissions` LIKE '%".$qpayroll_list."%' OR  `deductions` LIKE '%".$qpayroll_list."%' OR  `payroll_number` LIKE '%".$qpayroll_list."%' OR  `nhif` LIKE '%".$qpayroll_list."%' OR  `nssf` LIKE '%".$qpayroll_list."%' OR  `tax` LIKE '%".$qpayroll_list."%' OR  `net_salary` LIKE '%".$qpayroll_list."%' OR  `payroll_notes` LIKE '%".$qpayroll_list."%' OR  `owner` LIKE '%".$qpayroll_list."%' OR  `allowances` LIKE '%".$qpayroll_list."%' OR  `gross_sal` LIKE '%".$qpayroll_list."%' OR  `loan` LIKE '%".$qpayroll_list."%')";
         
         if($_GET["payroll_list_mosyfilter"]!=""){
         
         $mosyfilter_payroll_list_queries_str=(base64_decode($_GET["payroll_list_mosyfilter"]));
        
         $gft_payroll_list_where_query="(`payroll_id` LIKE '%".$qpayroll_list."%' OR  `payroll_month_year` LIKE '%".$qpayroll_list."%' OR  `payroll_date` LIKE '%".$qpayroll_list."%' OR  `staff_id` LIKE '%".$qpayroll_list."%' OR  `job_group` LIKE '%".$qpayroll_list."%' OR  `basicsalary` LIKE '%".$qpayroll_list."%' OR  `bonus_and_commissions` LIKE '%".$qpayroll_list."%' OR  `deductions` LIKE '%".$qpayroll_list."%' OR  `payroll_number` LIKE '%".$qpayroll_list."%' OR  `nhif` LIKE '%".$qpayroll_list."%' OR  `nssf` LIKE '%".$qpayroll_list."%' OR  `tax` LIKE '%".$qpayroll_list."%' OR  `net_salary` LIKE '%".$qpayroll_list."%' OR  `payroll_notes` LIKE '%".$qpayroll_list."%' OR  `owner` LIKE '%".$qpayroll_list."%' OR  `allowances` LIKE '%".$qpayroll_list."%' OR  `gross_sal` LIKE '%".$qpayroll_list."%' OR  `loan` LIKE '%".$qpayroll_list."%') AND ".$mosyfilter_payroll_list_queries_str."";
         
         }
         
		 $gft_payroll_list="WHERE ".$gft_payroll_list_where_query;
         
         $gft_payroll_list_and=$gft_payroll_list_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_payroll_list_);
        }
        }elseif(isset($_GET["qpayroll_list"])){
         $gwauthenticate_payroll_list_=gw_oauth("table", magic_current_url(), "payroll_list", "get_qpayroll_list","");

         $gwauthenticate_payroll_list_json=json_decode($gwauthenticate_payroll_list_, true);
         	
          //echo $gwauthenticate_payroll_list_;

         if($gwauthenticate_payroll_list_json["response"]=="ok")
         {
		 $qpayroll_list=mmres(base64_decode($_GET["qpayroll_list"]));
        
         $gft_payroll_list_where_query="(`payroll_id` LIKE '%".$qpayroll_list."%' OR  `payroll_month_year` LIKE '%".$qpayroll_list."%' OR  `payroll_date` LIKE '%".$qpayroll_list."%' OR  `staff_id` LIKE '%".$qpayroll_list."%' OR  `job_group` LIKE '%".$qpayroll_list."%' OR  `basicsalary` LIKE '%".$qpayroll_list."%' OR  `bonus_and_commissions` LIKE '%".$qpayroll_list."%' OR  `deductions` LIKE '%".$qpayroll_list."%' OR  `payroll_number` LIKE '%".$qpayroll_list."%' OR  `nhif` LIKE '%".$qpayroll_list."%' OR  `nssf` LIKE '%".$qpayroll_list."%' OR  `tax` LIKE '%".$qpayroll_list."%' OR  `net_salary` LIKE '%".$qpayroll_list."%' OR  `payroll_notes` LIKE '%".$qpayroll_list."%' OR  `owner` LIKE '%".$qpayroll_list."%' OR  `allowances` LIKE '%".$qpayroll_list."%' OR  `gross_sal` LIKE '%".$qpayroll_list."%' OR  `loan` LIKE '%".$qpayroll_list."%')";
         
         $gft_payroll_list="WHERE ".$gft_payroll_list_where_query;
         
         $gft_payroll_list_and=$gft_payroll_list_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_payroll_list_);

        }
        }elseif(isset($_GET["payroll_list_mosyfilter"])){
         $gwauthenticate_payroll_list_=gw_oauth("table", magic_current_url(), "payroll_list", "payroll_list_mosyfilter","");

         $gwauthenticate_payroll_list_json=json_decode($gwauthenticate_payroll_list_, true);
         	
          //echo $gwauthenticate_payroll_list_;

         if($gwauthenticate_payroll_list_json["response"]=="ok")
         {
         $gft_payroll_list_where_query="";
         $gft_payroll_list="";

         if($_GET["payroll_list_mosyfilter"]!=""){
          $gft_payroll_list_where_query=(base64_decode($_GET["payroll_list_mosyfilter"]));
          $gft_payroll_list="WHERE ".$gft_payroll_list_where_query;
         }
         
         
         $gft_payroll_list_and=$gft_payroll_list_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_payroll_list_);

        }
        }else{
         $gft_payroll_list="";
         $gft_payroll_list_and="";
         $gft_payroll_list_where_query="";
        }
       
    //************************************************* END  payroll_list OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section prl_allowances
  //************************************************* START  prl_allowances OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize prl_allowances edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['prl_allowances_table_alert']))
              	{	
                  if(isset($prl_allowances_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$prl_allowances_uptoken="";

		if(isset($_GET["prl_allowances_uptoken"]))
		{
		$prl_allowances_uptoken=base64_decode($_GET["prl_allowances_uptoken"]);
		}
        
        if(isset($_POST["prl_allowances_uptoken"]))
		{
		$prl_allowances_uptoken=base64_decode($_POST["prl_allowances_uptoken"]);
		}
        //
        
          $prl_allowances_alias_name="PRL ALLOWANCES";

          if(isset($prl_allowances_alias))
          {
             $prl_allowances_alias_name=$prl_allowances_alias;

          }
          
        //get single data record query with $prl_allowances_uptoken
        
        ///$prl_allowances_node=get_prl_allowances("*", "WHERE primkey='$prl_allowances_uptoken'", "r");
        
	
//************* START INSERT  prl_allowances QUERY 
if(isset($_POST["prl_allowances_insert_btn"])){
//------- begin prl_allowances_arr_ins --> 
$prl_allowances_arr_ins_=array(

"primkey"=>"NULL",
"allowance_id"=>magic_random_str(7),
"allowance_title"=>"?",
"amount"=>"?",
"staff_id"=>"?",
"remark"=>"?",
"owner"=>"?",
"active_state"=>"?"

);
//===-- End prl_allowances_arr_ins -->


          
         $gwauthenticate_prl_allowances_=gw_oauth("table", magic_current_url(), "prl_allowances", "insert","");

         $gwauthenticate_prl_allowances_json=json_decode($gwauthenticate_prl_allowances_, true);
         	
          //echo $gwauthenticate_prl_allowances_;

         if($gwauthenticate_prl_allowances_json["response"]=="ok")
         {

              $prl_allowances_validated_ins_str=$prl_allowances_arr_ins_;

              if(isset($prl_allowances_ins_inputs))
              {
                $prl_allowances_validated_ins_str=$prl_allowances_ins_inputs;	
              }

              if(empty($prl_allowances_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$prl_allowances_alias_name." request cannot be empty. Record not added");
              }else{

                $prl_allowances_return_key=add_prl_allowances($prl_allowances_validated_ins_str);
                
                mosy_sql_rollback("prl_allowances", "primkey='$prl_allowances_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $prl_allowances_return_key; 

                      } 

                    }else{ 

                                    
                $prl_allowances_custom_redir1=add_url_param ("prl_allowances_uptoken", base64_encode($prl_allowances_return_key), "");
                $prl_allowances_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$prl_allowances_custom_redir1);
                $prl_allowances_custom_redir3=add_url_param ("prl_allowances_table_alert", "prl_allowances_added",$prl_allowances_custom_redir2);
                
                ///echo magic_message($prl_allowances_custom_redir1." -- ".$prl_allowances_custom_redir2."--".$prl_allowances_custom_redir3);
                
                $prl_allowances_custom_redir=$prl_allowances_custom_redir3;
                
               header('location:'.$prl_allowances_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_prl_allowances_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_prl_allowances_)."");
         
         }
      
}
//************* END  prl_allowances INSERT QUERY 	
	

//************* START prl_allowances  UPDATE QUERY 
if(isset($_POST["prl_allowances_update_btn"])){
//------- begin prl_allowances_arr_updt --> 
$prl_allowances_arr_updt_=array(
"allowance_title"=>"?",
"amount"=>"?",
"staff_id"=>"?",
"remark"=>"?",
"owner"=>"?",
"active_state"=>"?"

);
//===-- End prl_allowances_arr_updt -->
                     
         $gwauthenticate_prl_allowances_=gw_oauth("table", magic_current_url(), "prl_allowances", "update","");

         $gwauthenticate_prl_allowances_json=json_decode($gwauthenticate_prl_allowances_, true);
         	
          //echo $gwauthenticate_prl_allowances_;

         if($gwauthenticate_prl_allowances_json["response"]=="ok")
         {
         
            $prl_allowances_validated_updt_str=$prl_allowances_arr_updt_;

            if(isset($prl_allowances_updt_inputs))
            {
              $prl_allowances_validated_updt_str=$prl_allowances_updt_inputs;	
            }

            if(empty($prl_allowances_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$prl_allowances_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$prl_allowances_key_salt=initialize_prl_allowances()["allowance_id"];
            
              update_prl_allowances($prl_allowances_validated_updt_str, "primkey='$prl_allowances_uptoken' and allowance_id='$prl_allowances_key_salt'");
				

			 mosy_sql_rollback("prl_allowances", "primkey='$prl_allowances_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $prl_allowances_uptoken; 

                    } 

                  }else{ 

                $prl_allowances_custom_redir1=add_url_param ("prl_allowances_uptoken", base64_encode($prl_allowances_uptoken), "");
                $prl_allowances_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$prl_allowances_custom_redir1);
                $prl_allowances_custom_redir3=add_url_param ("prl_allowances_table_alert", "prl_allowances_updated",$prl_allowances_custom_redir2);
                
                ///echo magic_message($prl_allowances_custom_redir1." -- ".$prl_allowances_custom_redir2."--".$prl_allowances_custom_redir3);
                
                $prl_allowances_custom_redir=$prl_allowances_custom_redir3;
                
               header('location:'.$prl_allowances_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_prl_allowances_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_prl_allowances_)."");
         
         }

      

      
}
//************* END prl_allowances  UPDATE QUERY 

    
    
      //== Start prl_allowances delete record

      if(isset($_GET["deleteprl_allowances"]))
      {
         $gwauthenticate_prl_allowances_=gw_oauth("table", magic_current_url(), "prl_allowances", "super_delete_request","");

         $gwauthenticate_prl_allowances_json=json_decode($gwauthenticate_prl_allowances_, true);
         	
          //echo $gwauthenticate_prl_allowances_;

         if($gwauthenticate_prl_allowances_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_prl_allowances_btn=magic_button_link("./".$current_file_url."?prl_allowances_uptoken=".$_GET["prl_allowances_uptoken"]."&conf_deleteprl_allowances&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_prl_allowances_btn=magic_button_link("./".$current_file_url."?prl_allowances_uptoken=".$_GET["prl_allowances_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_prl_allowances_btn." ".$cancel_del_prl_allowances_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_prl_allowances_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteprl_allowances"]))
      {
         $gwauthenticate_prl_allowances_=gw_oauth("table", magic_current_url(), "prl_allowances", "super_delete_confirm","");

         $gwauthenticate_prl_allowances_json=json_decode($gwauthenticate_prl_allowances_, true);
         	
          //echo $gwauthenticate_prl_allowances_;

         if($gwauthenticate_prl_allowances_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $prl_allowances_del_key_salt=initialize_prl_allowances()["allowance_id"];
      mosy_sql_rollback("prl_allowances", "primkey='$prl_allowances_uptoken'", "DELETE");
      drop_prl_allowances("primkey='$prl_allowances_uptoken' and allowance_id='$prl_allowances_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_prl_allowances_);

      }
      }

      //== End prl_allowances delete record  
    
       ///SELECT STRING FOR prl_allowances============================
              
       if(isset($_POST["qprl_allowances_btn"])){
         $gwauthenticate_prl_allowances_=gw_oauth("table", magic_current_url(), "prl_allowances", "qprl_allowances_btn","");

         $gwauthenticate_prl_allowances_json=json_decode($gwauthenticate_prl_allowances_, true);
         	
          //echo $gwauthenticate_prl_allowances_;

         if($gwauthenticate_prl_allowances_json["response"]=="ok")
         {
            $current_prl_allowances_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_prl_allowances_current_url=$current_prl_allowances_url_params.'?qprl_allowances=';
            if (strpos($current_prl_allowances_url_params, '?') !== false) {

                $clean_prl_allowances_current_url=$current_prl_allowances_url_params.'&qprl_allowances=';

            }
            if (strpos($current_prl_allowances_url_params, '?qprl_allowances')) {

                $remove_prl_allowances_old_token = substr($current_prl_allowances_url_params, 0, strpos($current_prl_allowances_url_params, "?qprl_allowances"));

                $clean_prl_allowances_current_url=$remove_prl_allowances_old_token.'?qprl_allowances=';

            }
            if(strpos($current_prl_allowances_url_params, '&qprl_allowances')) {

                $remove_prl_allowances_old_token = substr($current_prl_allowances_url_params, 0, strpos($current_prl_allowances_url_params, "&qprl_allowances"));

                $clean_prl_allowances_current_url=$remove_prl_allowances_old_token.'&qprl_allowances=';

            }
        $qprl_allowances_str=base64_encode($_POST["txt_prl_allowances"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_prl_allowances_current_url.($qprl_allowances_str);
            } 

          }else{ 
             header('location:'.$clean_prl_allowances_current_url.($qprl_allowances_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_prl_allowances_);

        }
        }
        $qprl_allowances="";
		if(isset($_GET["prl_allowances_mosyfilter"]) && isset($_GET["qprl_allowances"])){
         $gwauthenticate_prl_allowances_=gw_oauth("table", magic_current_url(), "prl_allowances", "prl_allowances_mosyfilter_n_query","");

         $gwauthenticate_prl_allowances_json=json_decode($gwauthenticate_prl_allowances_, true);
         	
          //echo $gwauthenticate_prl_allowances_;

         if($gwauthenticate_prl_allowances_json["response"]=="ok")
         {
         $qprl_allowances=mmres(base64_decode($_GET["qprl_allowances"]));
         
         $gft_prl_allowances_where_query="(`allowance_id` LIKE '%".$qprl_allowances."%' OR  `allowance_title` LIKE '%".$qprl_allowances."%' OR  `amount` LIKE '%".$qprl_allowances."%' OR  `staff_id` LIKE '%".$qprl_allowances."%' OR  `remark` LIKE '%".$qprl_allowances."%' OR  `owner` LIKE '%".$qprl_allowances."%' OR  `active_state` LIKE '%".$qprl_allowances."%')";
         
         if($_GET["prl_allowances_mosyfilter"]!=""){
         
         $mosyfilter_prl_allowances_queries_str=(base64_decode($_GET["prl_allowances_mosyfilter"]));
        
         $gft_prl_allowances_where_query="(`allowance_id` LIKE '%".$qprl_allowances."%' OR  `allowance_title` LIKE '%".$qprl_allowances."%' OR  `amount` LIKE '%".$qprl_allowances."%' OR  `staff_id` LIKE '%".$qprl_allowances."%' OR  `remark` LIKE '%".$qprl_allowances."%' OR  `owner` LIKE '%".$qprl_allowances."%' OR  `active_state` LIKE '%".$qprl_allowances."%') AND ".$mosyfilter_prl_allowances_queries_str."";
         
         }
         
		 $gft_prl_allowances="WHERE ".$gft_prl_allowances_where_query;
         
         $gft_prl_allowances_and=$gft_prl_allowances_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_prl_allowances_);
        }
        }elseif(isset($_GET["qprl_allowances"])){
         $gwauthenticate_prl_allowances_=gw_oauth("table", magic_current_url(), "prl_allowances", "get_qprl_allowances","");

         $gwauthenticate_prl_allowances_json=json_decode($gwauthenticate_prl_allowances_, true);
         	
          //echo $gwauthenticate_prl_allowances_;

         if($gwauthenticate_prl_allowances_json["response"]=="ok")
         {
		 $qprl_allowances=mmres(base64_decode($_GET["qprl_allowances"]));
        
         $gft_prl_allowances_where_query="(`allowance_id` LIKE '%".$qprl_allowances."%' OR  `allowance_title` LIKE '%".$qprl_allowances."%' OR  `amount` LIKE '%".$qprl_allowances."%' OR  `staff_id` LIKE '%".$qprl_allowances."%' OR  `remark` LIKE '%".$qprl_allowances."%' OR  `owner` LIKE '%".$qprl_allowances."%' OR  `active_state` LIKE '%".$qprl_allowances."%')";
         
         $gft_prl_allowances="WHERE ".$gft_prl_allowances_where_query;
         
         $gft_prl_allowances_and=$gft_prl_allowances_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_prl_allowances_);

        }
        }elseif(isset($_GET["prl_allowances_mosyfilter"])){
         $gwauthenticate_prl_allowances_=gw_oauth("table", magic_current_url(), "prl_allowances", "prl_allowances_mosyfilter","");

         $gwauthenticate_prl_allowances_json=json_decode($gwauthenticate_prl_allowances_, true);
         	
          //echo $gwauthenticate_prl_allowances_;

         if($gwauthenticate_prl_allowances_json["response"]=="ok")
         {
         $gft_prl_allowances_where_query="";
         $gft_prl_allowances="";

         if($_GET["prl_allowances_mosyfilter"]!=""){
          $gft_prl_allowances_where_query=(base64_decode($_GET["prl_allowances_mosyfilter"]));
          $gft_prl_allowances="WHERE ".$gft_prl_allowances_where_query;
         }
         
         
         $gft_prl_allowances_and=$gft_prl_allowances_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_prl_allowances_);

        }
        }else{
         $gft_prl_allowances="";
         $gft_prl_allowances_and="";
         $gft_prl_allowances_where_query="";
        }
       
    //************************************************* END  prl_allowances OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section subcriptions
  //************************************************* START  subcriptions OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize subcriptions edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['subcriptions_table_alert']))
              	{	
                  if(isset($subcriptions_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$subcriptions_uptoken="";

		if(isset($_GET["subcriptions_uptoken"]))
		{
		$subcriptions_uptoken=base64_decode($_GET["subcriptions_uptoken"]);
		}
        
        if(isset($_POST["subcriptions_uptoken"]))
		{
		$subcriptions_uptoken=base64_decode($_POST["subcriptions_uptoken"]);
		}
        //
        
          $subcriptions_alias_name="SUBCRIPTIONS";

          if(isset($subcriptions_alias))
          {
             $subcriptions_alias_name=$subcriptions_alias;

          }
          
        //get single data record query with $subcriptions_uptoken
        
        ///$subcriptions_node=get_subcriptions("*", "WHERE primkey='$subcriptions_uptoken'", "r");
        
	
//************* START INSERT  subcriptions QUERY 
if(isset($_POST["subcriptions_insert_btn"])){
//------- begin subcriptions_arr_ins --> 
$subcriptions_arr_ins_=array(

"primkey"=>"NULL",
"subcription_id"=>magic_random_str(7),
"user_id"=>"?",
"account_id"=>"?",
"ref_no"=>"?",
"trx_date"=>"?",
"amount_paid"=>"?",
"payment_mode"=>"?",
"expiry_date"=>"?",
"remark"=>"?"

);
//===-- End subcriptions_arr_ins -->


          
         $gwauthenticate_subcriptions_=gw_oauth("table", magic_current_url(), "subcriptions", "insert","");

         $gwauthenticate_subcriptions_json=json_decode($gwauthenticate_subcriptions_, true);
         	
          //echo $gwauthenticate_subcriptions_;

         if($gwauthenticate_subcriptions_json["response"]=="ok")
         {

              $subcriptions_validated_ins_str=$subcriptions_arr_ins_;

              if(isset($subcriptions_ins_inputs))
              {
                $subcriptions_validated_ins_str=$subcriptions_ins_inputs;	
              }

              if(empty($subcriptions_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$subcriptions_alias_name." request cannot be empty. Record not added");
              }else{

                $subcriptions_return_key=add_subcriptions($subcriptions_validated_ins_str);
                
                mosy_sql_rollback("subcriptions", "primkey='$subcriptions_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $subcriptions_return_key; 

                      } 

                    }else{ 

                                    
                $subcriptions_custom_redir1=add_url_param ("subcriptions_uptoken", base64_encode($subcriptions_return_key), "");
                $subcriptions_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$subcriptions_custom_redir1);
                $subcriptions_custom_redir3=add_url_param ("subcriptions_table_alert", "subcriptions_added",$subcriptions_custom_redir2);
                
                ///echo magic_message($subcriptions_custom_redir1." -- ".$subcriptions_custom_redir2."--".$subcriptions_custom_redir3);
                
                $subcriptions_custom_redir=$subcriptions_custom_redir3;
                
               header('location:'.$subcriptions_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_subcriptions_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_subcriptions_)."");
         
         }
      
}
//************* END  subcriptions INSERT QUERY 	
	

//************* START subcriptions  UPDATE QUERY 
if(isset($_POST["subcriptions_update_btn"])){
//------- begin subcriptions_arr_updt --> 
$subcriptions_arr_updt_=array(
"user_id"=>"?",
"account_id"=>"?",
"ref_no"=>"?",
"trx_date"=>"?",
"amount_paid"=>"?",
"payment_mode"=>"?",
"expiry_date"=>"?",
"remark"=>"?"

);
//===-- End subcriptions_arr_updt -->
                     
         $gwauthenticate_subcriptions_=gw_oauth("table", magic_current_url(), "subcriptions", "update","");

         $gwauthenticate_subcriptions_json=json_decode($gwauthenticate_subcriptions_, true);
         	
          //echo $gwauthenticate_subcriptions_;

         if($gwauthenticate_subcriptions_json["response"]=="ok")
         {
         
            $subcriptions_validated_updt_str=$subcriptions_arr_updt_;

            if(isset($subcriptions_updt_inputs))
            {
              $subcriptions_validated_updt_str=$subcriptions_updt_inputs;	
            }

            if(empty($subcriptions_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$subcriptions_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$subcriptions_key_salt=initialize_subcriptions()["subcription_id"];
            
              update_subcriptions($subcriptions_validated_updt_str, "primkey='$subcriptions_uptoken' and subcription_id='$subcriptions_key_salt'");
				

			 mosy_sql_rollback("subcriptions", "primkey='$subcriptions_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $subcriptions_uptoken; 

                    } 

                  }else{ 

                $subcriptions_custom_redir1=add_url_param ("subcriptions_uptoken", base64_encode($subcriptions_uptoken), "");
                $subcriptions_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$subcriptions_custom_redir1);
                $subcriptions_custom_redir3=add_url_param ("subcriptions_table_alert", "subcriptions_updated",$subcriptions_custom_redir2);
                
                ///echo magic_message($subcriptions_custom_redir1." -- ".$subcriptions_custom_redir2."--".$subcriptions_custom_redir3);
                
                $subcriptions_custom_redir=$subcriptions_custom_redir3;
                
               header('location:'.$subcriptions_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_subcriptions_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_subcriptions_)."");
         
         }

      

      
}
//************* END subcriptions  UPDATE QUERY 

    
    
      //== Start subcriptions delete record

      if(isset($_GET["deletesubcriptions"]))
      {
         $gwauthenticate_subcriptions_=gw_oauth("table", magic_current_url(), "subcriptions", "super_delete_request","");

         $gwauthenticate_subcriptions_json=json_decode($gwauthenticate_subcriptions_, true);
         	
          //echo $gwauthenticate_subcriptions_;

         if($gwauthenticate_subcriptions_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_subcriptions_btn=magic_button_link("./".$current_file_url."?subcriptions_uptoken=".$_GET["subcriptions_uptoken"]."&conf_deletesubcriptions&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_subcriptions_btn=magic_button_link("./".$current_file_url."?subcriptions_uptoken=".$_GET["subcriptions_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_subcriptions_btn." ".$cancel_del_subcriptions_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_subcriptions_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletesubcriptions"]))
      {
         $gwauthenticate_subcriptions_=gw_oauth("table", magic_current_url(), "subcriptions", "super_delete_confirm","");

         $gwauthenticate_subcriptions_json=json_decode($gwauthenticate_subcriptions_, true);
         	
          //echo $gwauthenticate_subcriptions_;

         if($gwauthenticate_subcriptions_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $subcriptions_del_key_salt=initialize_subcriptions()["subcription_id"];
      mosy_sql_rollback("subcriptions", "primkey='$subcriptions_uptoken'", "DELETE");
      drop_subcriptions("primkey='$subcriptions_uptoken' and subcription_id='$subcriptions_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_subcriptions_);

      }
      }

      //== End subcriptions delete record  
    
       ///SELECT STRING FOR subcriptions============================
              
       if(isset($_POST["qsubcriptions_btn"])){
         $gwauthenticate_subcriptions_=gw_oauth("table", magic_current_url(), "subcriptions", "qsubcriptions_btn","");

         $gwauthenticate_subcriptions_json=json_decode($gwauthenticate_subcriptions_, true);
         	
          //echo $gwauthenticate_subcriptions_;

         if($gwauthenticate_subcriptions_json["response"]=="ok")
         {
            $current_subcriptions_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_subcriptions_current_url=$current_subcriptions_url_params.'?qsubcriptions=';
            if (strpos($current_subcriptions_url_params, '?') !== false) {

                $clean_subcriptions_current_url=$current_subcriptions_url_params.'&qsubcriptions=';

            }
            if (strpos($current_subcriptions_url_params, '?qsubcriptions')) {

                $remove_subcriptions_old_token = substr($current_subcriptions_url_params, 0, strpos($current_subcriptions_url_params, "?qsubcriptions"));

                $clean_subcriptions_current_url=$remove_subcriptions_old_token.'?qsubcriptions=';

            }
            if(strpos($current_subcriptions_url_params, '&qsubcriptions')) {

                $remove_subcriptions_old_token = substr($current_subcriptions_url_params, 0, strpos($current_subcriptions_url_params, "&qsubcriptions"));

                $clean_subcriptions_current_url=$remove_subcriptions_old_token.'&qsubcriptions=';

            }
        $qsubcriptions_str=base64_encode($_POST["txt_subcriptions"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_subcriptions_current_url.($qsubcriptions_str);
            } 

          }else{ 
             header('location:'.$clean_subcriptions_current_url.($qsubcriptions_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_subcriptions_);

        }
        }
        $qsubcriptions="";
		if(isset($_GET["subcriptions_mosyfilter"]) && isset($_GET["qsubcriptions"])){
         $gwauthenticate_subcriptions_=gw_oauth("table", magic_current_url(), "subcriptions", "subcriptions_mosyfilter_n_query","");

         $gwauthenticate_subcriptions_json=json_decode($gwauthenticate_subcriptions_, true);
         	
          //echo $gwauthenticate_subcriptions_;

         if($gwauthenticate_subcriptions_json["response"]=="ok")
         {
         $qsubcriptions=mmres(base64_decode($_GET["qsubcriptions"]));
         
         $gft_subcriptions_where_query="(`subcription_id` LIKE '%".$qsubcriptions."%' OR  `user_id` LIKE '%".$qsubcriptions."%' OR  `account_id` LIKE '%".$qsubcriptions."%' OR  `ref_no` LIKE '%".$qsubcriptions."%' OR  `trx_date` LIKE '%".$qsubcriptions."%' OR  `amount_paid` LIKE '%".$qsubcriptions."%' OR  `payment_mode` LIKE '%".$qsubcriptions."%' OR  `expiry_date` LIKE '%".$qsubcriptions."%' OR  `remark` LIKE '%".$qsubcriptions."%')";
         
         if($_GET["subcriptions_mosyfilter"]!=""){
         
         $mosyfilter_subcriptions_queries_str=(base64_decode($_GET["subcriptions_mosyfilter"]));
        
         $gft_subcriptions_where_query="(`subcription_id` LIKE '%".$qsubcriptions."%' OR  `user_id` LIKE '%".$qsubcriptions."%' OR  `account_id` LIKE '%".$qsubcriptions."%' OR  `ref_no` LIKE '%".$qsubcriptions."%' OR  `trx_date` LIKE '%".$qsubcriptions."%' OR  `amount_paid` LIKE '%".$qsubcriptions."%' OR  `payment_mode` LIKE '%".$qsubcriptions."%' OR  `expiry_date` LIKE '%".$qsubcriptions."%' OR  `remark` LIKE '%".$qsubcriptions."%') AND ".$mosyfilter_subcriptions_queries_str."";
         
         }
         
		 $gft_subcriptions="WHERE ".$gft_subcriptions_where_query;
         
         $gft_subcriptions_and=$gft_subcriptions_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_subcriptions_);
        }
        }elseif(isset($_GET["qsubcriptions"])){
         $gwauthenticate_subcriptions_=gw_oauth("table", magic_current_url(), "subcriptions", "get_qsubcriptions","");

         $gwauthenticate_subcriptions_json=json_decode($gwauthenticate_subcriptions_, true);
         	
          //echo $gwauthenticate_subcriptions_;

         if($gwauthenticate_subcriptions_json["response"]=="ok")
         {
		 $qsubcriptions=mmres(base64_decode($_GET["qsubcriptions"]));
        
         $gft_subcriptions_where_query="(`subcription_id` LIKE '%".$qsubcriptions."%' OR  `user_id` LIKE '%".$qsubcriptions."%' OR  `account_id` LIKE '%".$qsubcriptions."%' OR  `ref_no` LIKE '%".$qsubcriptions."%' OR  `trx_date` LIKE '%".$qsubcriptions."%' OR  `amount_paid` LIKE '%".$qsubcriptions."%' OR  `payment_mode` LIKE '%".$qsubcriptions."%' OR  `expiry_date` LIKE '%".$qsubcriptions."%' OR  `remark` LIKE '%".$qsubcriptions."%')";
         
         $gft_subcriptions="WHERE ".$gft_subcriptions_where_query;
         
         $gft_subcriptions_and=$gft_subcriptions_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_subcriptions_);

        }
        }elseif(isset($_GET["subcriptions_mosyfilter"])){
         $gwauthenticate_subcriptions_=gw_oauth("table", magic_current_url(), "subcriptions", "subcriptions_mosyfilter","");

         $gwauthenticate_subcriptions_json=json_decode($gwauthenticate_subcriptions_, true);
         	
          //echo $gwauthenticate_subcriptions_;

         if($gwauthenticate_subcriptions_json["response"]=="ok")
         {
         $gft_subcriptions_where_query="";
         $gft_subcriptions="";

         if($_GET["subcriptions_mosyfilter"]!=""){
          $gft_subcriptions_where_query=(base64_decode($_GET["subcriptions_mosyfilter"]));
          $gft_subcriptions="WHERE ".$gft_subcriptions_where_query;
         }
         
         
         $gft_subcriptions_and=$gft_subcriptions_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_subcriptions_);

        }
        }else{
         $gft_subcriptions="";
         $gft_subcriptions_and="";
         $gft_subcriptions_where_query="";
        }
       
    //************************************************* END  subcriptions OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section system_admins
  //************************************************* START  system_admins OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize system_admins edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['system_admins_table_alert']))
              	{	
                  if(isset($system_admins_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$system_admins_uptoken="";

		if(isset($_GET["system_admins_uptoken"]))
		{
		$system_admins_uptoken=base64_decode($_GET["system_admins_uptoken"]);
		}
        
        if(isset($_POST["system_admins_uptoken"]))
		{
		$system_admins_uptoken=base64_decode($_POST["system_admins_uptoken"]);
		}
        //
        
          $system_admins_alias_name="SYSTEM ADMINS";

          if(isset($system_admins_alias))
          {
             $system_admins_alias_name=$system_admins_alias;

          }
          
        //get single data record query with $system_admins_uptoken
        
        ///$system_admins_node=get_system_admins("*", "WHERE primkey='$system_admins_uptoken'", "r");
        
	
//************* START INSERT  system_admins QUERY 
if(isset($_POST["system_admins_insert_btn"])){
//------- begin system_admins_arr_ins --> 
$system_admins_arr_ins_=array(

"primkey"=>"NULL",
"user_id"=>magic_random_str(7),
"name"=>"?",
"email"=>"?",
"tel"=>"?",
"login_password"=>"?",
"ref_id"=>"?",
"regdate"=>"?",
"user_no"=>"?",
"user_pic"=>"?",
"user_gender"=>"?",
"last_seen"=>"?",
"about"=>"?"

);
//===-- End system_admins_arr_ins -->


          
         $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "insert","");

         $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
         	
          //echo $gwauthenticate_system_admins_;

         if($gwauthenticate_system_admins_json["response"]=="ok")
         {

              $system_admins_validated_ins_str=$system_admins_arr_ins_;

              if(isset($system_admins_ins_inputs))
              {
                $system_admins_validated_ins_str=$system_admins_ins_inputs;	
              }

              if(empty($system_admins_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$system_admins_alias_name." request cannot be empty. Record not added");
              }else{

                $system_admins_return_key=add_system_admins($system_admins_validated_ins_str);
                
                mosy_sql_rollback("system_admins", "primkey='$system_admins_return_key'", "INSERT");
					
         
                if(!empty($_FILES['txt_system_admins_user_pic']['tmp_name']))
                {
                
                 upload_system_admins_user_pic('txt_system_admins_user_pic', "primkey='$system_admins_return_key'");
                 
				}
                
         
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $system_admins_return_key; 

                      } 

                    }else{ 

                                    
                $system_admins_custom_redir1=add_url_param ("system_admins_uptoken", base64_encode($system_admins_return_key), "");
                $system_admins_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$system_admins_custom_redir1);
                $system_admins_custom_redir3=add_url_param ("system_admins_table_alert", "system_admins_added",$system_admins_custom_redir2);
                
                ///echo magic_message($system_admins_custom_redir1." -- ".$system_admins_custom_redir2."--".$system_admins_custom_redir3);
                
                $system_admins_custom_redir=$system_admins_custom_redir3;
                
               header('location:'.$system_admins_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_system_admins_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_admins_)."");
         
         }
      
}
//************* END  system_admins INSERT QUERY 	
	

//************* START system_admins  UPDATE QUERY 
if(isset($_POST["system_admins_update_btn"])){
//------- begin system_admins_arr_updt --> 
$system_admins_arr_updt_=array(
"name"=>"?",
"email"=>"?",
"tel"=>"?",
"login_password"=>"?",
"ref_id"=>"?",
"regdate"=>"?",
"user_no"=>"?",
"user_pic"=>"?",
"user_gender"=>"?",
"last_seen"=>"?",
"about"=>"?"

);
//===-- End system_admins_arr_updt -->
                     
         $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "update","");

         $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
         	
          //echo $gwauthenticate_system_admins_;

         if($gwauthenticate_system_admins_json["response"]=="ok")
         {
         
            $system_admins_validated_updt_str=$system_admins_arr_updt_;

            if(isset($system_admins_updt_inputs))
            {
              $system_admins_validated_updt_str=$system_admins_updt_inputs;	
            }

            if(empty($system_admins_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$system_admins_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$system_admins_key_salt=initialize_system_admins()["user_id"];
            
              update_system_admins($system_admins_validated_updt_str, "primkey='$system_admins_uptoken' and user_id='$system_admins_key_salt'");
				
         
                if(!empty($_FILES['txt_system_admins_user_pic']['tmp_name']))
                {
                
                 upload_system_admins_user_pic('txt_system_admins_user_pic', "primkey='$system_admins_uptoken'");
                 
				}

			 mosy_sql_rollback("system_admins", "primkey='$system_admins_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $system_admins_uptoken; 

                    } 

                  }else{ 

                $system_admins_custom_redir1=add_url_param ("system_admins_uptoken", base64_encode($system_admins_uptoken), "");
                $system_admins_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$system_admins_custom_redir1);
                $system_admins_custom_redir3=add_url_param ("system_admins_table_alert", "system_admins_updated",$system_admins_custom_redir2);
                
                ///echo magic_message($system_admins_custom_redir1." -- ".$system_admins_custom_redir2."--".$system_admins_custom_redir3);
                
                $system_admins_custom_redir=$system_admins_custom_redir3;
                
               header('location:'.$system_admins_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_system_admins_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_admins_)."");
         
         }

      

      
}
//************* END system_admins  UPDATE QUERY 

    

          //===-====Start upload system_admins_user_pic 
          if(isset($_POST["btn_upload_system_admins_user_pic"]))
          {
         $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "upload_system_admins_user_pic","");

         $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
         	
          //echo $gwauthenticate_system_admins_;

         if($gwauthenticate_system_admins_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_system_admins_user_pic']['tmp_name'])){

				upload_system_admins_user_pic('txt_system_admins_user_pic', "primkey='$system_admins_uptoken'");
                
                $system_admins_custom_redir1=add_url_param ("system_admins_uptoken", base64_encode($system_admins_uptoken), "");
                $system_admins_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$system_admins_custom_redir1);
                $system_admins_custom_redir3=add_url_param ("system_admins_table_alert", "system_admins_uploaded",$system_admins_custom_redir2);
                
                ///echo magic_message($system_admins_custom_redir1." -- ".$system_admins_custom_redir2."--".$system_admins_custom_redir3);
                
                $system_admins_custom_redir=$system_admins_custom_redir3;
                
               header('location:'.$system_admins_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_system_admins_);

          }
          }
          //===-====End upload system_admins_user_pic  

			//drop system_admins_user_pic image 
            
          if(isset($_GET["conf_deletesystem_admins"]))
          {
          	$system_admins_node=initialize_system_admins();
          	if($system_admins_node["user_pic"]!="")
            {
          	 unlink($system_admins_node["user_pic"]);
            }
          }
          
          
    
      //== Start system_admins delete record

      if(isset($_GET["deletesystem_admins"]))
      {
         $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "super_delete_request","");

         $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
         	
          //echo $gwauthenticate_system_admins_;

         if($gwauthenticate_system_admins_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_system_admins_btn=magic_button_link("./".$current_file_url."?system_admins_uptoken=".$_GET["system_admins_uptoken"]."&conf_deletesystem_admins&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_system_admins_btn=magic_button_link("./".$current_file_url."?system_admins_uptoken=".$_GET["system_admins_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_system_admins_btn." ".$cancel_del_system_admins_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_system_admins_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletesystem_admins"]))
      {
         $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "super_delete_confirm","");

         $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
         	
          //echo $gwauthenticate_system_admins_;

         if($gwauthenticate_system_admins_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $system_admins_del_key_salt=initialize_system_admins()["user_id"];
      mosy_sql_rollback("system_admins", "primkey='$system_admins_uptoken'", "DELETE");
      drop_system_admins("primkey='$system_admins_uptoken' and user_id='$system_admins_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_system_admins_);

      }
      }

      //== End system_admins delete record  
    
       ///SELECT STRING FOR system_admins============================
              
       if(isset($_POST["qsystem_admins_btn"])){
         $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "qsystem_admins_btn","");

         $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
         	
          //echo $gwauthenticate_system_admins_;

         if($gwauthenticate_system_admins_json["response"]=="ok")
         {
            $current_system_admins_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_system_admins_current_url=$current_system_admins_url_params.'?qsystem_admins=';
            if (strpos($current_system_admins_url_params, '?') !== false) {

                $clean_system_admins_current_url=$current_system_admins_url_params.'&qsystem_admins=';

            }
            if (strpos($current_system_admins_url_params, '?qsystem_admins')) {

                $remove_system_admins_old_token = substr($current_system_admins_url_params, 0, strpos($current_system_admins_url_params, "?qsystem_admins"));

                $clean_system_admins_current_url=$remove_system_admins_old_token.'?qsystem_admins=';

            }
            if(strpos($current_system_admins_url_params, '&qsystem_admins')) {

                $remove_system_admins_old_token = substr($current_system_admins_url_params, 0, strpos($current_system_admins_url_params, "&qsystem_admins"));

                $clean_system_admins_current_url=$remove_system_admins_old_token.'&qsystem_admins=';

            }
        $qsystem_admins_str=base64_encode($_POST["txt_system_admins"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_system_admins_current_url.($qsystem_admins_str);
            } 

          }else{ 
             header('location:'.$clean_system_admins_current_url.($qsystem_admins_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_system_admins_);

        }
        }
        $qsystem_admins="";
		if(isset($_GET["system_admins_mosyfilter"]) && isset($_GET["qsystem_admins"])){
         $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "system_admins_mosyfilter_n_query","");

         $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
         	
          //echo $gwauthenticate_system_admins_;

         if($gwauthenticate_system_admins_json["response"]=="ok")
         {
         $qsystem_admins=mmres(base64_decode($_GET["qsystem_admins"]));
         
         $gft_system_admins_where_query="(`user_id` LIKE '%".$qsystem_admins."%' OR  `name` LIKE '%".$qsystem_admins."%' OR  `email` LIKE '%".$qsystem_admins."%' OR  `tel` LIKE '%".$qsystem_admins."%' OR  `login_password` LIKE '%".$qsystem_admins."%' OR  `ref_id` LIKE '%".$qsystem_admins."%' OR  `regdate` LIKE '%".$qsystem_admins."%' OR  `user_no` LIKE '%".$qsystem_admins."%' OR  `user_pic` LIKE '%".$qsystem_admins."%' OR  `user_gender` LIKE '%".$qsystem_admins."%' OR  `last_seen` LIKE '%".$qsystem_admins."%' OR  `about` LIKE '%".$qsystem_admins."%')";
         
         if($_GET["system_admins_mosyfilter"]!=""){
         
         $mosyfilter_system_admins_queries_str=(base64_decode($_GET["system_admins_mosyfilter"]));
        
         $gft_system_admins_where_query="(`user_id` LIKE '%".$qsystem_admins."%' OR  `name` LIKE '%".$qsystem_admins."%' OR  `email` LIKE '%".$qsystem_admins."%' OR  `tel` LIKE '%".$qsystem_admins."%' OR  `login_password` LIKE '%".$qsystem_admins."%' OR  `ref_id` LIKE '%".$qsystem_admins."%' OR  `regdate` LIKE '%".$qsystem_admins."%' OR  `user_no` LIKE '%".$qsystem_admins."%' OR  `user_pic` LIKE '%".$qsystem_admins."%' OR  `user_gender` LIKE '%".$qsystem_admins."%' OR  `last_seen` LIKE '%".$qsystem_admins."%' OR  `about` LIKE '%".$qsystem_admins."%') AND ".$mosyfilter_system_admins_queries_str."";
         
         }
         
		 $gft_system_admins="WHERE ".$gft_system_admins_where_query;
         
         $gft_system_admins_and=$gft_system_admins_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_system_admins_);
        }
        }elseif(isset($_GET["qsystem_admins"])){
         $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "get_qsystem_admins","");

         $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
         	
          //echo $gwauthenticate_system_admins_;

         if($gwauthenticate_system_admins_json["response"]=="ok")
         {
		 $qsystem_admins=mmres(base64_decode($_GET["qsystem_admins"]));
        
         $gft_system_admins_where_query="(`user_id` LIKE '%".$qsystem_admins."%' OR  `name` LIKE '%".$qsystem_admins."%' OR  `email` LIKE '%".$qsystem_admins."%' OR  `tel` LIKE '%".$qsystem_admins."%' OR  `login_password` LIKE '%".$qsystem_admins."%' OR  `ref_id` LIKE '%".$qsystem_admins."%' OR  `regdate` LIKE '%".$qsystem_admins."%' OR  `user_no` LIKE '%".$qsystem_admins."%' OR  `user_pic` LIKE '%".$qsystem_admins."%' OR  `user_gender` LIKE '%".$qsystem_admins."%' OR  `last_seen` LIKE '%".$qsystem_admins."%' OR  `about` LIKE '%".$qsystem_admins."%')";
         
         $gft_system_admins="WHERE ".$gft_system_admins_where_query;
         
         $gft_system_admins_and=$gft_system_admins_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_system_admins_);

        }
        }elseif(isset($_GET["system_admins_mosyfilter"])){
         $gwauthenticate_system_admins_=gw_oauth("table", magic_current_url(), "system_admins", "system_admins_mosyfilter","");

         $gwauthenticate_system_admins_json=json_decode($gwauthenticate_system_admins_, true);
         	
          //echo $gwauthenticate_system_admins_;

         if($gwauthenticate_system_admins_json["response"]=="ok")
         {
         $gft_system_admins_where_query="";
         $gft_system_admins="";

         if($_GET["system_admins_mosyfilter"]!=""){
          $gft_system_admins_where_query=(base64_decode($_GET["system_admins_mosyfilter"]));
          $gft_system_admins="WHERE ".$gft_system_admins_where_query;
         }
         
         
         $gft_system_admins_and=$gft_system_admins_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_system_admins_);

        }
        }else{
         $gft_system_admins="";
         $gft_system_admins_and="";
         $gft_system_admins_where_query="";
        }
       
    //************************************************* END  system_admins OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section system_files
  //************************************************* START  system_files OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize system_files edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['system_files_table_alert']))
              	{	
                  if(isset($system_files_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$system_files_uptoken="";

		if(isset($_GET["system_files_uptoken"]))
		{
		$system_files_uptoken=base64_decode($_GET["system_files_uptoken"]);
		}
        
        if(isset($_POST["system_files_uptoken"]))
		{
		$system_files_uptoken=base64_decode($_POST["system_files_uptoken"]);
		}
        //
        
          $system_files_alias_name="SYSTEM FILES";

          if(isset($system_files_alias))
          {
             $system_files_alias_name=$system_files_alias;

          }
          
        //get single data record query with $system_files_uptoken
        
        ///$system_files_node=get_system_files("*", "WHERE primkey='$system_files_uptoken'", "r");
        
	
//************* START INSERT  system_files QUERY 
if(isset($_POST["system_files_insert_btn"])){
//------- begin system_files_arr_ins --> 
$system_files_arr_ins_=array(

"primkey"=>"NULL",
"file_id"=>magic_random_str(7),
"file_title"=>"?",
"file_type"=>"?",
"file_url"=>"?",
"item_id"=>"?",
"owner"=>"?"

);
//===-- End system_files_arr_ins -->


          
         $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "insert","");

         $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
         	
          //echo $gwauthenticate_system_files_;

         if($gwauthenticate_system_files_json["response"]=="ok")
         {

              $system_files_validated_ins_str=$system_files_arr_ins_;

              if(isset($system_files_ins_inputs))
              {
                $system_files_validated_ins_str=$system_files_ins_inputs;	
              }

              if(empty($system_files_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$system_files_alias_name." request cannot be empty. Record not added");
              }else{

                $system_files_return_key=add_system_files($system_files_validated_ins_str);
                
                mosy_sql_rollback("system_files", "primkey='$system_files_return_key'", "INSERT");
					
         
                if(!empty($_FILES['txt_system_files_file_url']['tmp_name']))
                {
                
                 upload_system_files_file_url('txt_system_files_file_url', "primkey='$system_files_return_key'");
                 
				}
                
         
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $system_files_return_key; 

                      } 

                    }else{ 

                                    
                $system_files_custom_redir1=add_url_param ("system_files_uptoken", base64_encode($system_files_return_key), "");
                $system_files_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$system_files_custom_redir1);
                $system_files_custom_redir3=add_url_param ("system_files_table_alert", "system_files_added",$system_files_custom_redir2);
                
                ///echo magic_message($system_files_custom_redir1." -- ".$system_files_custom_redir2."--".$system_files_custom_redir3);
                
                $system_files_custom_redir=$system_files_custom_redir3;
                
               header('location:'.$system_files_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_system_files_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_files_)."");
         
         }
      
}
//************* END  system_files INSERT QUERY 	
	

//************* START system_files  UPDATE QUERY 
if(isset($_POST["system_files_update_btn"])){
//------- begin system_files_arr_updt --> 
$system_files_arr_updt_=array(
"file_title"=>"?",
"file_type"=>"?",
"file_url"=>"?",
"item_id"=>"?",
"owner"=>"?"

);
//===-- End system_files_arr_updt -->
                     
         $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "update","");

         $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
         	
          //echo $gwauthenticate_system_files_;

         if($gwauthenticate_system_files_json["response"]=="ok")
         {
         
            $system_files_validated_updt_str=$system_files_arr_updt_;

            if(isset($system_files_updt_inputs))
            {
              $system_files_validated_updt_str=$system_files_updt_inputs;	
            }

            if(empty($system_files_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$system_files_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$system_files_key_salt=initialize_system_files()["file_id"];
            
              update_system_files($system_files_validated_updt_str, "primkey='$system_files_uptoken' and file_id='$system_files_key_salt'");
				
         
                if(!empty($_FILES['txt_system_files_file_url']['tmp_name']))
                {
                
                 upload_system_files_file_url('txt_system_files_file_url', "primkey='$system_files_uptoken'");
                 
				}

			 mosy_sql_rollback("system_files", "primkey='$system_files_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $system_files_uptoken; 

                    } 

                  }else{ 

                $system_files_custom_redir1=add_url_param ("system_files_uptoken", base64_encode($system_files_uptoken), "");
                $system_files_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$system_files_custom_redir1);
                $system_files_custom_redir3=add_url_param ("system_files_table_alert", "system_files_updated",$system_files_custom_redir2);
                
                ///echo magic_message($system_files_custom_redir1." -- ".$system_files_custom_redir2."--".$system_files_custom_redir3);
                
                $system_files_custom_redir=$system_files_custom_redir3;
                
               header('location:'.$system_files_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_system_files_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_system_files_)."");
         
         }

      

      
}
//************* END system_files  UPDATE QUERY 

    

          //===-====Start upload system_files_file_url 
          if(isset($_POST["btn_upload_system_files_file_url"]))
          {
         $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "upload_system_files_file_url","");

         $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
         	
          //echo $gwauthenticate_system_files_;

         if($gwauthenticate_system_files_json["response"]=="ok")
         {
          if(!empty($_FILES['txt_system_files_file_url']['tmp_name'])){

				upload_system_files_file_url('txt_system_files_file_url', "primkey='$system_files_uptoken'");
                
                $system_files_custom_redir1=add_url_param ("system_files_uptoken", base64_encode($system_files_uptoken), "");
                $system_files_custom_redir2=add_url_param ("table_alert", " File Uploaded Succesfully",$system_files_custom_redir1);
                $system_files_custom_redir3=add_url_param ("system_files_table_alert", "system_files_uploaded",$system_files_custom_redir2);
                
                ///echo magic_message($system_files_custom_redir1." -- ".$system_files_custom_redir2."--".$system_files_custom_redir3);
                
                $system_files_custom_redir=$system_files_custom_redir3;
                
               header('location:'.$system_files_custom_redir.'');

          }else{

              echo magic_message('Please Browse A valid file');
          }
		  }else{
         	echo magic_screen($gwauthenticate_system_files_);

          }
          }
          //===-====End upload system_files_file_url  

			//drop system_files_file_url image 
            
          if(isset($_GET["conf_deletesystem_files"]))
          {
          	$system_files_node=initialize_system_files();
          	if($system_files_node["file_url"]!="")
            {
          	 unlink($system_files_node["file_url"]);
            }
          }
          
          
    
      //== Start system_files delete record

      if(isset($_GET["deletesystem_files"]))
      {
         $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "super_delete_request","");

         $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
         	
          //echo $gwauthenticate_system_files_;

         if($gwauthenticate_system_files_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_system_files_btn=magic_button_link("./".$current_file_url."?system_files_uptoken=".$_GET["system_files_uptoken"]."&conf_deletesystem_files&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_system_files_btn=magic_button_link("./".$current_file_url."?system_files_uptoken=".$_GET["system_files_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_system_files_btn." ".$cancel_del_system_files_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_system_files_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deletesystem_files"]))
      {
         $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "super_delete_confirm","");

         $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
         	
          //echo $gwauthenticate_system_files_;

         if($gwauthenticate_system_files_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $system_files_del_key_salt=initialize_system_files()["file_id"];
      mosy_sql_rollback("system_files", "primkey='$system_files_uptoken'", "DELETE");
      drop_system_files("primkey='$system_files_uptoken' and file_id='$system_files_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_system_files_);

      }
      }

      //== End system_files delete record  
    
       ///SELECT STRING FOR system_files============================
              
       if(isset($_POST["qsystem_files_btn"])){
         $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "qsystem_files_btn","");

         $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
         	
          //echo $gwauthenticate_system_files_;

         if($gwauthenticate_system_files_json["response"]=="ok")
         {
            $current_system_files_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_system_files_current_url=$current_system_files_url_params.'?qsystem_files=';
            if (strpos($current_system_files_url_params, '?') !== false) {

                $clean_system_files_current_url=$current_system_files_url_params.'&qsystem_files=';

            }
            if (strpos($current_system_files_url_params, '?qsystem_files')) {

                $remove_system_files_old_token = substr($current_system_files_url_params, 0, strpos($current_system_files_url_params, "?qsystem_files"));

                $clean_system_files_current_url=$remove_system_files_old_token.'?qsystem_files=';

            }
            if(strpos($current_system_files_url_params, '&qsystem_files')) {

                $remove_system_files_old_token = substr($current_system_files_url_params, 0, strpos($current_system_files_url_params, "&qsystem_files"));

                $clean_system_files_current_url=$remove_system_files_old_token.'&qsystem_files=';

            }
        $qsystem_files_str=base64_encode($_POST["txt_system_files"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_system_files_current_url.($qsystem_files_str);
            } 

          }else{ 
             header('location:'.$clean_system_files_current_url.($qsystem_files_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_system_files_);

        }
        }
        $qsystem_files="";
		if(isset($_GET["system_files_mosyfilter"]) && isset($_GET["qsystem_files"])){
         $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "system_files_mosyfilter_n_query","");

         $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
         	
          //echo $gwauthenticate_system_files_;

         if($gwauthenticate_system_files_json["response"]=="ok")
         {
         $qsystem_files=mmres(base64_decode($_GET["qsystem_files"]));
         
         $gft_system_files_where_query="(`file_id` LIKE '%".$qsystem_files."%' OR  `file_title` LIKE '%".$qsystem_files."%' OR  `file_type` LIKE '%".$qsystem_files."%' OR  `file_url` LIKE '%".$qsystem_files."%' OR  `item_id` LIKE '%".$qsystem_files."%' OR  `owner` LIKE '%".$qsystem_files."%')";
         
         if($_GET["system_files_mosyfilter"]!=""){
         
         $mosyfilter_system_files_queries_str=(base64_decode($_GET["system_files_mosyfilter"]));
        
         $gft_system_files_where_query="(`file_id` LIKE '%".$qsystem_files."%' OR  `file_title` LIKE '%".$qsystem_files."%' OR  `file_type` LIKE '%".$qsystem_files."%' OR  `file_url` LIKE '%".$qsystem_files."%' OR  `item_id` LIKE '%".$qsystem_files."%' OR  `owner` LIKE '%".$qsystem_files."%') AND ".$mosyfilter_system_files_queries_str."";
         
         }
         
		 $gft_system_files="WHERE ".$gft_system_files_where_query;
         
         $gft_system_files_and=$gft_system_files_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_system_files_);
        }
        }elseif(isset($_GET["qsystem_files"])){
         $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "get_qsystem_files","");

         $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
         	
          //echo $gwauthenticate_system_files_;

         if($gwauthenticate_system_files_json["response"]=="ok")
         {
		 $qsystem_files=mmres(base64_decode($_GET["qsystem_files"]));
        
         $gft_system_files_where_query="(`file_id` LIKE '%".$qsystem_files."%' OR  `file_title` LIKE '%".$qsystem_files."%' OR  `file_type` LIKE '%".$qsystem_files."%' OR  `file_url` LIKE '%".$qsystem_files."%' OR  `item_id` LIKE '%".$qsystem_files."%' OR  `owner` LIKE '%".$qsystem_files."%')";
         
         $gft_system_files="WHERE ".$gft_system_files_where_query;
         
         $gft_system_files_and=$gft_system_files_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_system_files_);

        }
        }elseif(isset($_GET["system_files_mosyfilter"])){
         $gwauthenticate_system_files_=gw_oauth("table", magic_current_url(), "system_files", "system_files_mosyfilter","");

         $gwauthenticate_system_files_json=json_decode($gwauthenticate_system_files_, true);
         	
          //echo $gwauthenticate_system_files_;

         if($gwauthenticate_system_files_json["response"]=="ok")
         {
         $gft_system_files_where_query="";
         $gft_system_files="";

         if($_GET["system_files_mosyfilter"]!=""){
          $gft_system_files_where_query=(base64_decode($_GET["system_files_mosyfilter"]));
          $gft_system_files="WHERE ".$gft_system_files_where_query;
         }
         
         
         $gft_system_files_and=$gft_system_files_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_system_files_);

        }
        }else{
         $gft_system_files="";
         $gft_system_files_and="";
         $gft_system_files_where_query="";
        }
       
    //************************************************* END  system_files OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  //table section ux_table
  //************************************************* START  ux_table OPERATIONS INSERT/UPDATE/DELETE *************************//
  		//== initialize ux_table edit token variable

			///toast card  ui table alert 
			  if(isset($_GET['table_alert']))
              {
               if(isset($_GET['ux_table_table_alert']))
              	{	
                  if(isset($ux_table_custom_alert))
                  {
                  ///===stop table alert
                  }else{
                  //echo '
                  //<div style="text-align: center; z-index:999;" class="toast_card_holder">
                   //'.magic_toast('Success', $_GET['table_alert'], 'darkgreen', '#FFF').'
                  //</div>';

                  }
                }
            }
            
		$ux_table_uptoken="";

		if(isset($_GET["ux_table_uptoken"]))
		{
		$ux_table_uptoken=base64_decode($_GET["ux_table_uptoken"]);
		}
        
        if(isset($_POST["ux_table_uptoken"]))
		{
		$ux_table_uptoken=base64_decode($_POST["ux_table_uptoken"]);
		}
        //
        
          $ux_table_alias_name="UX TABLE";

          if(isset($ux_table_alias))
          {
             $ux_table_alias_name=$ux_table_alias;

          }
          
        //get single data record query with $ux_table_uptoken
        
        ///$ux_table_node=get_ux_table("*", "WHERE primkey='$ux_table_uptoken'", "r");
        
	
//************* START INSERT  ux_table QUERY 
if(isset($_POST["ux_table_insert_btn"])){
//------- begin ux_table_arr_ins --> 
$ux_table_arr_ins_=array(

"primkey"=>"NULL",
"ux_id"=>magic_random_str(7),
"ux_key"=>"?",
"ux_value"=>"?",
"ux_type"=>"?",
"ux_state"=>"?",
"remark"=>"?"

);
//===-- End ux_table_arr_ins -->


          
         $gwauthenticate_ux_table_=gw_oauth("table", magic_current_url(), "ux_table", "insert","");

         $gwauthenticate_ux_table_json=json_decode($gwauthenticate_ux_table_, true);
         	
          //echo $gwauthenticate_ux_table_;

         if($gwauthenticate_ux_table_json["response"]=="ok")
         {

              $ux_table_validated_ins_str=$ux_table_arr_ins_;

              if(isset($ux_table_ins_inputs))
              {
                $ux_table_validated_ins_str=$ux_table_ins_inputs;	
              }

              if(empty($ux_table_validated_ins_str))
              {
                echo magic_message("Error BLANK_INPUT : ".$ux_table_alias_name." request cannot be empty. Record not added");
              }else{

                $ux_table_return_key=add_ux_table($ux_table_validated_ins_str);
                
                mosy_sql_rollback("ux_table", "primkey='$ux_table_return_key'", "INSERT");
					
                
                

                   if(isset($_POST["mosyrequest_type"])) 

                    { 

                      if($_POST["mosyrequest_type"]=="ajax") 

                      { 

                          echo $ux_table_return_key; 

                      } 

                    }else{ 

                                    
                $ux_table_custom_redir1=add_url_param ("ux_table_uptoken", base64_encode($ux_table_return_key), "");
                $ux_table_custom_redir2=add_url_param ("table_alert", "Record Added Succesfully",$ux_table_custom_redir1);
                $ux_table_custom_redir3=add_url_param ("ux_table_table_alert", "ux_table_added",$ux_table_custom_redir2);
                
                ///echo magic_message($ux_table_custom_redir1." -- ".$ux_table_custom_redir2."--".$ux_table_custom_redir3);
                
                $ux_table_custom_redir=$ux_table_custom_redir3;
                
               header('location:'.$ux_table_custom_redir.'');
                
                       

                   } 

               }
          }else{

         	echo magic_screen($gwauthenticate_ux_table_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_ux_table_)."");
         
         }
      
}
//************* END  ux_table INSERT QUERY 	
	

//************* START ux_table  UPDATE QUERY 
if(isset($_POST["ux_table_update_btn"])){
//------- begin ux_table_arr_updt --> 
$ux_table_arr_updt_=array(
"ux_key"=>"?",
"ux_value"=>"?",
"ux_type"=>"?",
"ux_state"=>"?",
"remark"=>"?"

);
//===-- End ux_table_arr_updt -->
                     
         $gwauthenticate_ux_table_=gw_oauth("table", magic_current_url(), "ux_table", "update","");

         $gwauthenticate_ux_table_json=json_decode($gwauthenticate_ux_table_, true);
         	
          //echo $gwauthenticate_ux_table_;

         if($gwauthenticate_ux_table_json["response"]=="ok")
         {
         
            $ux_table_validated_updt_str=$ux_table_arr_updt_;

            if(isset($ux_table_updt_inputs))
            {
              $ux_table_validated_updt_str=$ux_table_updt_inputs;	
            }

            if(empty($ux_table_validated_updt_str)){

              echo magic_message("Error BLANK_INPUT : ".$ux_table_alias_name."  input cannot be empty. Record not Updated");

            }else{
			$ux_table_key_salt=initialize_ux_table()["ux_id"];
            
              update_ux_table($ux_table_validated_updt_str, "primkey='$ux_table_uptoken' and ux_id='$ux_table_key_salt'");
				

			 mosy_sql_rollback("ux_table", "primkey='$ux_table_uptoken'", "UPDATE");

              
                 if(isset($_POST["mosyrequest_type"])) 

                  { 

                    if($_POST["mosyrequest_type"]=="ajax")
                    { 

                        echo $ux_table_uptoken; 

                    } 

                  }else{ 

                $ux_table_custom_redir1=add_url_param ("ux_table_uptoken", base64_encode($ux_table_uptoken), "");
                $ux_table_custom_redir2=add_url_param ("table_alert", "Record Updated Succesfully",$ux_table_custom_redir1);
                $ux_table_custom_redir3=add_url_param ("ux_table_table_alert", "ux_table_updated",$ux_table_custom_redir2);
                
                ///echo magic_message($ux_table_custom_redir1." -- ".$ux_table_custom_redir2."--".$ux_table_custom_redir3);
                
                $ux_table_custom_redir=$ux_table_custom_redir3;
                
               header('location:'.$ux_table_custom_redir.'');
                
                    
 

                  } 

               }

         }else{

         	echo magic_screen($gwauthenticate_ux_table_);
            
            //header("location:./gwdenied?gwdenied=".base64_encode($gwauthenticate_ux_table_)."");
         
         }

      

      
}
//************* END ux_table  UPDATE QUERY 

    
    
      //== Start ux_table delete record

      if(isset($_GET["deleteux_table"]))
      {
         $gwauthenticate_ux_table_=gw_oauth("table", magic_current_url(), "ux_table", "super_delete_request","");

         $gwauthenticate_ux_table_json=json_decode($gwauthenticate_ux_table_, true);
         	
          //echo $gwauthenticate_ux_table_;

         if($gwauthenticate_ux_table_json["response"]=="ok")
         {
          //======confirm pop up 
          $current_file_url=magic_basename(magic_current_url());

          $after_delete=base64_encode($current_file_url);

          if(isset($_GET['after_delete']))
          {
            $after_delete=$_GET['after_delete'];
          }
      $conf_del_ux_table_btn=magic_button_link("./".$current_file_url."?ux_table_uptoken=".$_GET["ux_table_uptoken"]."&conf_deleteux_table&after_delete=".$after_delete, "Yes", 'style="margin-right:10px;"');

      $cancel_del_ux_table_btn=magic_button_link("./".$current_file_url."?ux_table_uptoken=".$_GET["ux_table_uptoken"], "No", "");

      echo magic_screen("Delete this record?<hr>".$conf_del_ux_table_btn." ".$cancel_del_ux_table_btn."");
	   }else{
                
          echo magic_screen($gwauthenticate_ux_table_);

       }
      }

      //==Delete Record 

      if(isset($_GET["conf_deleteux_table"]))
      {
         $gwauthenticate_ux_table_=gw_oauth("table", magic_current_url(), "ux_table", "super_delete_confirm","");

         $gwauthenticate_ux_table_json=json_decode($gwauthenticate_ux_table_, true);
         	
          //echo $gwauthenticate_ux_table_;

         if($gwauthenticate_ux_table_json["response"]=="ok")
         {
      //====== start back to list file after delete 

      $current_file_url=magic_basename(magic_current_url());

      $after_delete=($current_file_url);

      if(isset($_GET['after_delete']))
      {
        $after_delete=magic_basename(base64_decode($_GET['after_delete']));
      }
        //====== End  back to list file after delete 
      $ux_table_del_key_salt=initialize_ux_table()["ux_id"];
      mosy_sql_rollback("ux_table", "primkey='$ux_table_uptoken'", "DELETE");
      drop_ux_table("primkey='$ux_table_uptoken' and ux_id='$ux_table_del_key_salt'");

      //==add your redirect here 

      header("location:./".$after_delete."?table_alert=Record Deleted Succesfully");
      }else{
        
        echo magic_screen($gwauthenticate_ux_table_);

      }
      }

      //== End ux_table delete record  
    
       ///SELECT STRING FOR ux_table============================
              
       if(isset($_POST["qux_table_btn"])){
         $gwauthenticate_ux_table_=gw_oauth("table", magic_current_url(), "ux_table", "qux_table_btn","");

         $gwauthenticate_ux_table_json=json_decode($gwauthenticate_ux_table_, true);
         	
          //echo $gwauthenticate_ux_table_;

         if($gwauthenticate_ux_table_json["response"]=="ok")
         {
            $current_ux_table_url_params=''.$http_protocol.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"].'';

            $clean_ux_table_current_url=$current_ux_table_url_params.'?qux_table=';
            if (strpos($current_ux_table_url_params, '?') !== false) {

                $clean_ux_table_current_url=$current_ux_table_url_params.'&qux_table=';

            }
            if (strpos($current_ux_table_url_params, '?qux_table')) {

                $remove_ux_table_old_token = substr($current_ux_table_url_params, 0, strpos($current_ux_table_url_params, "?qux_table"));

                $clean_ux_table_current_url=$remove_ux_table_old_token.'?qux_table=';

            }
            if(strpos($current_ux_table_url_params, '&qux_table')) {

                $remove_ux_table_old_token = substr($current_ux_table_url_params, 0, strpos($current_ux_table_url_params, "&qux_table"));

                $clean_ux_table_current_url=$remove_ux_table_old_token.'&qux_table=';

            }
        $qux_table_str=base64_encode($_POST["txt_ux_table"]);
        
          if(isset($_POST["mosyrequest_type"])) 

          { 

            if($_POST["mosyrequest_type"]=="ajax") 

            { 

                echo $clean_ux_table_current_url.($qux_table_str);
            } 

          }else{ 
             header('location:'.$clean_ux_table_current_url.($qux_table_str).'');

          } 

        
        }else{

			echo magic_screen($gwauthenticate_ux_table_);

        }
        }
        $qux_table="";
		if(isset($_GET["ux_table_mosyfilter"]) && isset($_GET["qux_table"])){
         $gwauthenticate_ux_table_=gw_oauth("table", magic_current_url(), "ux_table", "ux_table_mosyfilter_n_query","");

         $gwauthenticate_ux_table_json=json_decode($gwauthenticate_ux_table_, true);
         	
          //echo $gwauthenticate_ux_table_;

         if($gwauthenticate_ux_table_json["response"]=="ok")
         {
         $qux_table=mmres(base64_decode($_GET["qux_table"]));
         
         $gft_ux_table_where_query="(`ux_id` LIKE '%".$qux_table."%' OR  `ux_key` LIKE '%".$qux_table."%' OR  `ux_value` LIKE '%".$qux_table."%' OR  `ux_type` LIKE '%".$qux_table."%' OR  `ux_state` LIKE '%".$qux_table."%' OR  `remark` LIKE '%".$qux_table."%')";
         
         if($_GET["ux_table_mosyfilter"]!=""){
         
         $mosyfilter_ux_table_queries_str=(base64_decode($_GET["ux_table_mosyfilter"]));
        
         $gft_ux_table_where_query="(`ux_id` LIKE '%".$qux_table."%' OR  `ux_key` LIKE '%".$qux_table."%' OR  `ux_value` LIKE '%".$qux_table."%' OR  `ux_type` LIKE '%".$qux_table."%' OR  `ux_state` LIKE '%".$qux_table."%' OR  `remark` LIKE '%".$qux_table."%') AND ".$mosyfilter_ux_table_queries_str."";
         
         }
         
		 $gft_ux_table="WHERE ".$gft_ux_table_where_query;
         
         $gft_ux_table_and=$gft_ux_table_where_query." AND ";
         
		}else{
			echo magic_screen($gwauthenticate_ux_table_);
        }
        }elseif(isset($_GET["qux_table"])){
         $gwauthenticate_ux_table_=gw_oauth("table", magic_current_url(), "ux_table", "get_qux_table","");

         $gwauthenticate_ux_table_json=json_decode($gwauthenticate_ux_table_, true);
         	
          //echo $gwauthenticate_ux_table_;

         if($gwauthenticate_ux_table_json["response"]=="ok")
         {
		 $qux_table=mmres(base64_decode($_GET["qux_table"]));
        
         $gft_ux_table_where_query="(`ux_id` LIKE '%".$qux_table."%' OR  `ux_key` LIKE '%".$qux_table."%' OR  `ux_value` LIKE '%".$qux_table."%' OR  `ux_type` LIKE '%".$qux_table."%' OR  `ux_state` LIKE '%".$qux_table."%' OR  `remark` LIKE '%".$qux_table."%')";
         
         $gft_ux_table="WHERE ".$gft_ux_table_where_query;
         
         $gft_ux_table_and=$gft_ux_table_where_query." AND ";
         
		}else{
        			
          echo magic_screen($gwauthenticate_ux_table_);

        }
        }elseif(isset($_GET["ux_table_mosyfilter"])){
         $gwauthenticate_ux_table_=gw_oauth("table", magic_current_url(), "ux_table", "ux_table_mosyfilter","");

         $gwauthenticate_ux_table_json=json_decode($gwauthenticate_ux_table_, true);
         	
          //echo $gwauthenticate_ux_table_;

         if($gwauthenticate_ux_table_json["response"]=="ok")
         {
         $gft_ux_table_where_query="";
         $gft_ux_table="";

         if($_GET["ux_table_mosyfilter"]!=""){
          $gft_ux_table_where_query=(base64_decode($_GET["ux_table_mosyfilter"]));
          $gft_ux_table="WHERE ".$gft_ux_table_where_query;
         }
         
         
         $gft_ux_table_and=$gft_ux_table_where_query." AND ";
         
        }else{
         
         echo magic_screen($gwauthenticate_ux_table_);

        }
        }else{
         $gft_ux_table="";
         $gft_ux_table_and="";
         $gft_ux_table_where_query="";
        }
       
    //************************************************* END  ux_table OPERATIONS INSERT/UPDATE/DELETE *************************//
    
  

//<--ncgh-->

?>