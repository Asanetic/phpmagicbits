<!DOCTYPE html>
<html>
<head>
    <title></title>
    <script src="./lib/jquery-3.4.1.min.js"></script>
    <script src="./lib/jquery-migrate-1.2.1.min.js"></script>

    <link rel="stylesheet" href="./assets/designer.css"/>
    <link href="./assets/fonts.css" rel="stylesheet">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />

    <link rel="stylesheet" href="./dist/drawerJs.css"/>
    <script src="./dist/drawerJs.standalone.js"></script>
 <style type="text/css">
   /* width */
::-webkit-scrollbar {
  width: 3px;
}

/* Track */
::-webkit-scrollbar-track {
  background: #00235d; 
}
 
/* Handle */
::-webkit-scrollbar-thumb {
  background: rgba(255,255,255,0.2); 
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #555; 
}

.input_control{
  border:none;
  background:transparent;
  border-bottom:1px solid #000;
}
</style> 
 
</head>

<body>
    <main role="main" class="container-fluid skin_plasma" style="min-height:100vh;">
  <div class="row bg-light justify-content-center text-center">
  <div class="row justify-content-center m-0 p-0 col-md-12">
  <h4 class="col-md-3 p-0 pt-2">Lightspeed sketch</h4>
  <div class="col-md-9 text-left pt-2">
    <input type="text" id="txt_writeto" name="txt_writeto" class="mr-4 input_control" value="./projects/filetitle.lsdsn" placeholder="File Name"/>
    <button class="badge bg-transparent border-0" onclick="save_file()">Save Data</button>
      <input type="text" id="txt_trashfile" name="txt_trashfile" class="mr-4 ml-5 input_control" value="" placeholder="Delete File Name"/>
    <button class="badge bg-transparent border-0 text-danger" onclick="delete_file(document.getElementById('txt_trashfile').value)"><i class="fa fa-trash"></i> Trash </button>
 </div>
  </div>

  </div>
  <div class="row justify-content-center m-0 p-0 col-md-12">
    <div class="col-md-10 p-0">
      <div class="" style="padding:0px; position:relative;">
          <div id="canvas-editor">
          </div>
      </div>
    </div>
    <div class="col-md-2 shadow p-2" >
    <!-- Start  Title ribbon-->
      <h5 class="col-md-12 row p-2 justify-content-center p-0 m-0 ">
	      <div class="col-md-12 text-left"> File List</div>
	      <div class="col-md-12 bg-dark mt-1" style="height: 1px"></div>
      </h5>
    <!-- End Title ribbon-->
 <div style="padding:5px; font-size: 12px; display: none; word-wrap:break-word" onclick="this.style.display='none'" id="notification_card">Notifications</div>
<input type="text" style="font-size: 12px; width: 100%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px; margin-top: 5px; padding: 5px;" onkeyup="search_log()" required="" id="function_card" placeholder=" Search Window"  autocomplete="off">

 <input type="text" id="folderpath" style="font-size: 12px; width: 100%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px; margin-top: 5px; padding: 5px;" onkeyup="loop_folder(this.value)" onchange="loop_folder(this.value)"  required="" placeholder="Search Folders"  autocomplete="off">
<div class="col-md-12 p-0 m-0" style="overflow-y:auto; max-height:400px;" id="log_window"> 
</div> 
    </div>
  </div>
</main>

<script type="text/javascript">
var canvas = null;  
    $(document).ready(function () {
        var drawerPlugins = [
            // Drawing tools
            'Pencil',
            'Eraser',
            'Text',
            'Line',
            'ArrowOneSide',
            'ArrowTwoSide',
            'Triangle',
            'Rectangle',
            'Circle',
            'Polygon',

            // Drawing options
            //'ColorHtml5',
            'Color',
            'ShapeBorder',
            'BrushSize',
            'OpacityOption',
            'LineWidth',
            'StrokeWidth',

            'Resize',
            'ShapeContextMenu',
            'CloseButton',
            'OvercanvasPopup',
            'OpenPopupButton',
            'MinimizeButton',
            'ToggleVisibilityButton',
            'MovableFloatingMode',
            'FullscreenModeButton',


            'TextLineHeight',
            'TextAlign',

            'TextFontFamily',
            'TextFontSize',
            'TextFontWeight',
            'TextFontStyle',
            'TextDecoration',
            'TextColor',
            'TextBackgroundColor'
        ];

        // drawer is created as global property solely for debug purposes.
        // doing  in production is considered as bad practice
        canvas = new DrawerJs.Drawer(null, {
          
            plugins: drawerPlugins,
            pluginsConfig: {
				Image: {
					scaleDownLargeImage: true,
					maxImageSizeKb: 1024 //1MB
				},
				BackgroundImage: {
				    scaleDownLargeImage: true,
					maxImageSizeKb: 1024, //1MB
					//fixedBackgroundUrl: '/examples/redactor/images/vanGogh.jpg',
					imagePosition: 'stretch',  // one of  'center', 'stretch', 'top-left', 'top-right', 'bottom-left', 'bottom-right'
		        	acceptedMIMETypes: ['image/jpeg', 'image/png', 'image/gif'] ,
                    dynamicRepositionImage: true,
                    dynamicRepositionImageThrottle: 100
				},
                Text : {
                    editIconMode : true,
                    editIconSize : 'large'
                }
			},
             toolbars: {
                drawingTools: {
                    position: 'top',         
                    positionType: 'inside',
                    customAnchorSelector: '#custom-toolbar-here',  
                    compactType: 'scrollable',   
                    hidden: false,     
                    toggleVisibilityButton: false,
                    fullscreenMode: {
                        position: 'top', 
                        hidden: false,
                        toggleVisibilityButton: false
                    }
                },
                Zoom: {
                    enabled: true, 
                    showZoomTooltip: true, 
                    useWheelEvents: true,
                    zoomStep: 1.05, 
                    defaultZoom: 1, 
                    maxZoom: 32,
                    minZoom: 1, 
                    smoothnessOfWheel: 0,
                    //Moving:
                    enableMove: true,
                    enableWhenNoActiveTool: true,
                    enableButton: true
                },
                settings : {
                    position : 'right', 
                    positionType: 'inside',					
                    compactType : 'scrollable',
                    hidden: false,	
                    toggleVisibilityButton: false,
                    fullscreenMode: {
                        position : 'right', 
                        hidden: false,
                        toggleVisibilityButton: false
                    }
                }
            },         
            defaultActivePlugin : { name : 'Rectangle', mode : 'lastUsed'},
            debug: true,
			transparentBackground: true,
            align: 'floating',  //one of 'left', 'right', 'center', 'inline', 'floating'
			lineAngleTooltip: { enabled: true, color: 'blue',  fontSize: 15}
        });

        $('#canvas-editor').append(canvas.getHtml());
        canvas.onInsert();

    });

</script>
<script type="text/javascript" src="./cm_terminal.js?v=<?php echo date("dmyhisa")?>"></script> 
<script type="text/javascript">
window.onload=load_start_folder('./projects');check_autoload();
function check_autoload()
{

var url =new URL(window.location.href);
var c = url.searchParams.get("check_autoload");

if(c!=undefined){

document.getElementById('txt_writeto').value=atob(c);

load_file()

}
}
</script>
</body>
</html>
