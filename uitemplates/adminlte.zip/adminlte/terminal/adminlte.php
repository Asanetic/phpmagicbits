<?php
ob_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>{page_title}</title>

    <!-- Bootstrap core CSS -->
{header_css_scripts}
</head>

<body class="sidebar-mini">
  <div class="wrapper">
	{navbar_path}
  	<main class="content-wrapper">
      <form method="post" enctype="multipart/form-data">
      <div class="row justify-content-center m-0 p-0 ">
        <h4 class="col-md-12" style="text-align: center;">{page_title}<br><br></h4>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
          <!--<{ncgh}/>-->
      </div>
      </form>
    </main><!-- /.container -->
 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
   <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>   
{footer_path}
    </div>
</body>
</html>