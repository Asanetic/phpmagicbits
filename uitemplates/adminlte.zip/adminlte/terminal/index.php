<?php
ob_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
  <link rel="stylesheet" href="boot.css"/>
    <meta name="author" content="">
    <title>PageName</title>

    <!-- Bootstrap core CSS -->
</head>

<body>
    <form method="post" enctype="multipart/form-data">
========== Basic funtions

Welcome to terminal X

  Terminal X is PHP based code editor that is designed to combine all the front end and back end functions of creating a perfect web application. 
  
  Guide
  -----
  
  On your right you have the log window. This is where all the results from your executions will occour. 
  It also where your project folder files are listed
  Below we have Php Console window for running php scripts 
  
  On the top navigation we have:

	- Search Box - Searches the whole app for files and snippets
    - Run - to execute php code on the active window
    - Preview - incase you are building a html user interface you can use preview button to see how youpage looks in realtime
    - Snippets window enables you to edit,add and delete a snippet
    - Loads file - Loads contents of the file in the writable path into the code window
    - Writable file path - the path to the file you want to load, e.g. ./index.html
    - Live - Toggles between live View and code view mode when creating user interface files
    - New Instance - Opens new code window in new tab
    - Reload - Refreshes the current window - Ensure You save your file before reloading, otherwise all your unsaved edits will be lost
    - Save file - commits the code in the active window to the writable file path
 
  At the bottom we have
      
   -notes button for storing notes or your app plan
   -vars for storing variables that you want to call across your app.
     
     Example: 
		Have you ever wished you could start typing and a code in a certain file in your project will just pop up. Thats possible with terminal X.
          Just have all your varibles here and you can access them by typing the `~` followed by the cade you want to appear e.g ~$localhost. 
          
   -DB - type your application database name here if you have any and other configurations
   -Show log - display log window
   - doctype -set the document type
   -theme color -set the theme of the editor
   
 
  Setting up your editor
  -------------------------
  Ensure the terminal folder is in your project folder
  Ensure your snippets are working - to import snippet database type import_snippet_db() on the console window and press alt+E to execute
  
  
  Keyboard Shortcuts
 ---------------------
     
 Ctrl + S - saves code to file - your cursor should be focused on the code window
 alt+Q - Search the directory
 alt+A - Add new snippet
 Alt+down-arrow - scroll down
 Alt+up - scroll up 
 Alt+C - focuses on php console window
 ALt+E - Execute php code on active window
 esc- hides editor popups
 
     
     
To call snippet function start your word / code with `@` symbol e.g @create table
To call environment varible start your word / code with ~ symbol e.g ~host
  

    </form>
</body>
</html>
