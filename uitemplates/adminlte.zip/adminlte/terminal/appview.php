<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="./terminal.css">
<title>Terminal</title>

<div style="text-align: center;">
	<img src="./deskfull.png" class="screen_frame">
	<iframe src="./index" class="desk_iframe"  id="load_desk_iframe" onLoad="change_scroll_bar_desk();"></iframe>
	<img src="./mobiview2.png" class="mobi_screen_frame" id="mobile_screen">
	<div class="close_mobile_view" onclick="close_mobile_view();this.style.display='none'" id="close_mobile_view_btn" title="Close Mobile View">X</div>
	<iframe src="./index" class="mobi_iframe"  id="load_mobi_iFrame" onLoad="change_scroll_bar_mobi();"></iframe>
<div class="preview_desk_iframe" id="preview_desk_iframe" style="display: none;"  onclick="push_to_top('preview_desk_iframe')">
  <div class="min_cast" id="load_preview_iframe_btn">
    <div class="exe_btn"><span onclick="expand_mobi()" id="expand_mobi" style="display: none;"><b>Desktop </b> | </span><span onclick="fold_mobi()" id="fold_mobi"><b>Mobile </b> | </span><span onclick="min_preview()"><b>Min </b></span>|<span onclick="loadwebpage();min_preview()"><b> Cast </b></span> | <span id="preview_desk_iframeheader" style="cursor: pointer;"><b> Drag </b></span></div>

  </div>
  <iframe style="width: 100%; height: 100%;" id="load_preview_iframe0" onLoad="change_scroll_bar_prev0();"></iframe>
  <iframe style="width: 100%; height: 100%;" id="load_preview_iframe1" onLoad="change_scroll_bar_prev1();"></iframe>
    <input type="text" id="prevscroll_px" style="position: absolute; bottom: 30px; right: 10px; width: 100px; background-color: rgba(0,0,0, 0.3); z-index: 9999999; color: #FFF;" placeholder="Scroll to">
</div>
<input type="hidden" id="foundfile" name="" style="position: fixed; bottom: 72px; right: 20px; width: 70%; background-color: rgba(0,0,0, 0.9); z-index: 999; color: #FFF;" >
	<div class="bottom_tray" style="color: #FFF;">
        <div class="exe_btn" id="time" ></div>
		Iframe : <input type="text" id="iframeurl" placeholder="Url to show" style="width: 15%; background-color: #000; color:#FFF; border: none; display: inline-block; ">
        <input type="text" id="txt_code_transparency" onkeyup="code_transparency(this.value)" placeholder="Opacity" style="width: 40px; background-color: #000; color:#FFF; border: none; display: inline-block; ">
		<div class="exe_btn" onclick="loadwebpage()">Go</div>
		<div class="exe_btn" onclick="loadapp_plan('appnotes')">Notes</div>
		<div class="exe_btn" onclick="loadapp_plan('appvars')">Vars</div>
        <div class="exe_btn" onclick="load_mirror()">Mirror</div>
        <div class="exe_btn" onclick="loadapp_plan('appdbconfig')">DB</div>
	</div>
	<div class="minimized_mobi" id="minimized_mobi_div" title="Show Mobile View" onclick="show_mobi(); this.style.display='none'" >
		[Show Mobile View]
	</div>
<!--Start editor-->
<div class="navbar_ribbon">
    <input type="text" id="basepath_txt" style="font-size: 12px; width: 70px; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px;" value=".." required="" placeholder="DirBase" onkeyup='loop_folder(this.value); trigger_log_search(this.value);flag_search(this.value)'>
    <input type="text" id="mainsearch" style="font-size: 12px; width: 15%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px;" value="Search" required="" placeholder=" Search System"   autocomplete="off" onkeyup='loop_folder(this.value); trigger_log_search(this.value);flag_search(this.value)'>
    <div  class="minifolder" id="minifolder" >
    	<div id="qfolder_res" onclick="document.getElementById('minifolder').style.display='none'"></div>
    </div>
	<div class="exe_btn" onclick="execute_terminal('');">Run</div>
	<div class="exe_btn" onclick="max_preview();showeditor()">Preview</div>

	<div class="exe_btn" onclick="pop_snippet();">Snippets</div>
    <input type="hidden" style="font-size: 12px; width: 15%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px;" value="<?php if(isset($_POST['txt_directory'])){ echo $_POST['txt_directory'];}else{ echo "./terminal_exe.php";}?>" name="txt_directory" id="txt_directory" required="" placeholder=" Enter exe file path">

	<div class="exe_btn" onclick="load_file();">Load File</div>
    <input type="text" style="font-size: 12px; width: 15%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px;" value="<?php if(isset($_POST['txt_writeto'])){ echo $_POST['txt_writeto'];}else{ echo "./txt_writeto.php";}?>" id="txt_writeto" name="txt_writeto" required="" placeholder=" Enter writable file path" onkeyup="loop_folder(this.value); trigger_log_search(this.value);push_title()" onchange="push_title()">
	<div class="exe_btn" id="showeditor" onclick="this.style.display='none';showeditor()">Code</div>

	<div class="exe_btn" id="hideeditor" style="display: none;" onclick="this.style.display='none';hideeditor();clearframeurl()">Live</div>
	<a href="./appview" target="_blank" class="exe_btn" >New Instance</a>
	<a href="./appview" class="exe_btn">Reload</a>
	<div class="exe_btn" onclick="save_file()">Save File</div>
</div>

<div class="log_window" id="parent_log_window" style="display: none;" onclick="push_to_top('parent_log_window')">
<div id="parent_log_windowheader" style="border:1px solid #FFF; cursor: move;">
< Drag >
</div>
<div style="padding:10px; font-size: 28px; display: none;" onclick="this.style.display='none'" id="notification_card">Notifications</div>

<input type="text" style="font-size: 12px; width: 100%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px; margin-top: 5px; padding: 5px;" onkeyup="search_log()" required="" id="function_card" placeholder=" Search Window"  autocomplete="off">

<input type="text" id="folderpath" style="font-size: 12px; width: 100%; background-color: #000; color:#FFF; border: none; display: inline-block; padding-left: 2px; margin-top: 5px; padding: 5px;" onkeyup="loop_folder(this.value)" onchange="loop_folder(this.value)"  required="" placeholder="Search Folders"  autocomplete="off">

<div id="log_window" style="max-height: 300px; overflow-y: auto; margin-top: 12px;"></div>
<div style="text-align: right;">
    <a class="" href="#" onclick="execute_terminal('console');">Run</a>
    | <a class="" href="#" onclick="load_notes('appendtextlog');save_notes('appendtextlog');">Append</a>
    | <a class="" href="#" onclick="loadapp_plan('appendtextlog'); document.getElementById('app_notes').style.display='none';document.getElementById('append_to_console').style.display='block'">View Log</a>
</div>
<textarea id="append_text" onclick="switch_terminals('console')" style="
    background-color: rgb(0, 0, 0, 0.2);
    width: 252px;
    color: #4eacff;
    height: 250px;
    margin: 10px 0px 0px;
    border: none;" placeholder="Php Console"></textarea>

</div>

<textarea class="editor_skin" id="txt_new_code"  onclick=" switch_terminals('main')"></textarea>
<div onclick="this.style.display='none'"style="position: fixed;
    bottom: 200px;
    left: 200px;
    width: 400px;
    display: none;
    padding: 20px;
    background-color: #000; color: #FFF; max-height: 200px; overflow-y: auto; text-align: left; z-index: 9999999999">

</div>

<div onclick="this.style.display='none'" id="flag_search_hash" style="position: fixed;
    bottom: 200px;
    left: 600px;
    width: 400px;
    display: none;
    padding: 20px;
    background-color: #000; color: #FFF; max-height: 200px; overflow-y: auto; text-align: left; z-index: 9999999999">
</div>
<input type="hidden" style="position: fixed; bottom: 72px; right: 20px; width: 70%; background-color: rgba(0,0,0, 0.9); z-index: 999; color: #FFF;" id="flag_search" name="">
<input type="hidden" style="position: fixed; bottom: 172px; right: 20px; width: 70%; background-color: rgba(0,0,0, 0.9); z-index: 999; color: #FFF;" id="hash_text_search" name="">
<input type="hidden" style="position: fixed; bottom: 72px; right: 20px; width: 40%; background-color: rgba(0,0,0, 0.9); z-index: 999; color: #FFF;" id="trigger_arrow_keys" name="">
<input type="hidden" id="load_preview_iframe_txt">
<input type="hidden" id="appvars_txt">
<input type="hidden" id="app_notes_append">
<input type="text" id="setcursor">
<input type="text" id="snippkey">
<input type="text" id="alwaysontop" value="99999999">
<input type="hidden" id="active_terminal" style="position: fixed; bottom: 72px; right: 20px; width: 40%; background-color: rgba(0,0,0, 0.9); z-index: 999; color: #FFF;">
<!--End editor-->
<!-- $("#a_input_id", parent.document).val($(this).text());
 -->
</div>
<div id="alert_box"></div>

<script type="text/javascript" src="./jquery.js"></script>
<script type="text/javascript" src="./terminal.js"></script>
<script type="text/javascript" src="./jsfunctions.js"></script>

<script type="text/javascript">
    Window.onload=showeditor();check_autoload();

    function check_autoload()
    {

var url =new URL(window.location.href);
var c = url.searchParams.get("check_autoload");

if(c!=undefined){

document.getElementById('txt_writeto').value=atob(c);

load_file()

}


}
function load_mirror()
{

    window.open('./codemirror?check_autoload='+btoa(document.getElementById('txt_writeto').value));
}

function code_transparency(new_val)
{
document.getElementById('txt_new_code').style.backgroundColor='rgba(0,0,0,0.'+new_val+')';
}
</script>