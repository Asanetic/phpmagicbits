<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
include('./data_control/gwdna.php');
include('./data_control/datahandler.php');
include('./data_control/requesthandler.php');

$default_home_crumb="";
if(isset($home_crumb))
{
$default_home_crumb=$home_crumb;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Account Profiles</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
</head>

<body class="sidebar-mini">
  <div class="wrapper">
	<?php include("./includes/navbar.php");?>
  	<main class="content-wrapper">
      <form method="post" enctype="multipart/form-data">
      <div class="row justify-content-center m-0 p-0 ">
        
      <div class="col-md-12 pb-2 pl-0 text-dark" style="text-align: left;">
      	<span class="bg-light p-2 font-weight-bold" >
        	<?php echo $default_home_crumb; ?>
        	<span class="text-primary">Account Profiles</span> 
        </span>
          <div class="col-md-12 d-lg-none  mb-2"></div>
          <!--{nbuttongh}-->
      </div>
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
          <!--<{ncgh}/>-->
      </div>
      </form>
    </main><!-- /.container -->
 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
   <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>   
<?php include("./includes/footer.php");?>
    </div>
</body>
</html>