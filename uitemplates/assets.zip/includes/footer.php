<div id="alert_box"></div>
<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="./js/jquery_main.js"></script>
    <script src="./js/popper.js"></script>
    <script src="./js/jsfunctions.js"></script>
    <script src="./js/boot.js"></script>
<script type="text/javascript">
	<?php if(isset($_GET['table_alert'])){?>
$('.toast').toast('show');
<?php }?>
</script>