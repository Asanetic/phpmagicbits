function pop_tech_serv_card(techid)
{

  var input_q ='<input type="text" class="form-control" id="txt_service_name" placeholder="Service Name" onkeyup="q_ajax_tech_list(this.value, \''+techid+'\')"/>';
  var gotobtn ='<div class="col-md-12 text-center" style="width:100%;"><div class="btn btn-primary" onclick="add_tech_service(\''+techid+'\')">Add</div></div>';
  var card_tile = '<h6>Manage Services<hr></h6>'+input_q+'<hr>'+gotobtn+'<hr><div style="width:100%; max-height:300px; overflow:auto;" id="result_card">...</div>';

  magic_screen(card_tile , 'alert_box');
  
  document.getElementById('txt_service_name').focus();
  
  q_ajax_tech_list('', techid);
  
}

//=========== Start Ajax 

function add_tech_service(techid)
{
  
  var txt_service_name =document.getElementById('txt_service_name').value;
  
  if(txt_service_name!=''){
$.ajax({ 
      url: './data_control/postajax.php',
      type: "POST",
      data: {
      	'add_tech_service': 'ok',
        'txt_techid':techid,
        'txt_service_name':txt_service_name
        },

      success: function (data) {

			//alert(data)
       // document.getElementById('alert_box').innerHTML='';
         q_ajax_tech_list("", techid);

      }

  });
  }else{
    
    alert("Service Name Required");
    
  }

}
//=========== End Ajax 

//=========== Start Ajax 
function q_ajax_tech_list(qstr, tech_id)
{
  
 document.getElementById('result_card').innerHTML="Fetching...";

$.ajax({ 
      url: './data_control/postajax.php',
      type: "POST",
      data: {
      	'q_ajax_tech_list': 'ok',
         'techid': tech_id,
         'qstr': qstr
      },

      success: function (data) {

        document.getElementById('result_card').innerHTML=data;

      }

  });

}
//=========== End Ajax 


//=========== Start Ajax 


function drop_tech_serv(drop_tech_key, tech_id)
{
$.ajax({ 
      url: './data_control/postajax.php',
      type: "POST",
      data: {
      	'drop_tech_serv': drop_tech_key
      },

      success: function (data) {

		//alert(data)
        
         q_ajax_tech_list("", tech_id);

      }

  });

}


//=========== End Ajax 
function push_star(star_value)
{

	document.getElementById('txt_stars').value=star_value;
  if(star_value==1)
  {
	document.getElementById('star_note').innerHTML=star_value +" star";

  }else{
    	document.getElementById('star_note').innerHTML=star_value +" stars";

  }
  
}