<?php
ob_start();
include('./data_control/conn.php');
include('./data_control/phpmagicbits.php');
//include('./data_control/datafeed.php');
include('./chart_db.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Dashboard</title>

    <!-- Bootstrap core CSS -->
<?php include("./includes/header_css_scripts.php");?>
<style type="text/css">
.chart_tray{
  height:400px;
}
</style>
<?php
$skinclr=$ctn_bg;
$buttonclr=$btn_bg;
$gentxtclr=$ctn_txt;
$buttontxtclr=$btn_txt;
?>
<script type="text/javascript" src="./gstatic/loader.js"></script>
  <script>google.charts.load('current', {'packages':['corechart']});</script>
<!--chartscript-->
</head>

<body>
    <form method="post" enctype="multipart/form-data">
	<?php include("./includes/navbar.php");?>
    <main role="main" class="container-fluid skin_plasma padding_row" style="min-height:100vh;">
      <div class="row mt-5 pt-3 justify-content-center">
          <!-- <{ncgh}/> - new code will replace this tag. Place it where you want the terminal to write new code-->
  		<div class="row justify-content-center m-0 col-md-12 p-0">
    		<div class="col-md-12  pt-3">
                <!-- Start  Title ribbon-->
                <h4 class="col-md-12 row justify-content-center mb-4">
                  <div class="col-md-2 text-left"> App Tasks</div>
                  <div class="col-md-10 border-top border_set mt-3" style="height: 1px"></div>
                </h4>
                <!-- End Title ribbon-->
              
              <!-- Start  pill Navigation Section -->
            <ul class="nav nav-pills mb-3 " id="pills-tab" role="tablist">
			  <!--{next_pill_btn}-->
            </ul>
            <!-- Start  pill Navigation Section -->
             <!-- Start Pill content container-->
            <div class="tab-content pt-3" id="pills-tabContent">
           	<!--{next_pill_tray}-->
            </div>
             <!-- End Pill content container-->
           
              <!-- Start -->
				<div class="p-0 row justify-content-left col-md-12 m-0 pt-3 body_set mt-2 border-top border_set">
                      <!-- Start  Title ribbon-->
                <h4 class="col-md-12 row p-2 justify-content-center">
                  <div class="col-md-1 text-left"> Stats</div>
                  <div class="col-md-11 border-top border_set  mt-3" style="height: 1px"></div>
                </h4>
                <!-- End Title ribbon-->
                  <div class="col-md-12 p-4 mb-3 text-left font-weight-bold ">
  					<!--{next_count_btn}-->
                  </div>
                  <div class="row justify-content-center col-md-12 m-0 p-0">
                	 <!--<{ncgh}/>-->
				  </div>

			</div>
			  <!-- End -->
		</div>
  		</div>
         
      </div>
    </main>
  <!-- /.container -->
 <!-- Bootstrap core JavaScript -->
 <!-- Placed at the end of the document so the pages load faster -->
    
<?php include("./includes/footer.php");?>
    </form>
</body>
</html>