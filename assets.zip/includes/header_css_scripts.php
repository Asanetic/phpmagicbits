    <link rel="stylesheet" href="./css/designer.css">
    <link rel="stylesheet" href="./css/fonts.css">
    <link rel="icon" href="./img/logo.png">
<style>
    
 body
{
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    background-image: url('./img/bg.jpg');
}

.form-control{
  background-color:transparent;
  border:none;
  border-bottom:1px solid green;
  border-radius:0px;
}
.form-group label
{
font-weight:bold;  
}

.cpointer{
    cursor: pointer;
}

.skin_plasma
{
height: auto;
background-color: rgba(255,255,255,0.7)
}

.padding_row
{
margin-top: 70px!important;
}

.padding_row_gen
{
margin-top: 100px!important;
}
.padding_row
{
margin-top: 65px!important;
}
.navbar-brand{
    font-size:27px;
}
.btn-primary{
	margin-bottom: 14px;
}

@media screen and (max-width: 700px)
{
.padding_row
{
margin-top: 65px!important;
}
    
.navbar-brand{
    font-size:1.25rem;
}

.padding_row_gen
{
margin-top: 50px!important;
}

.skin_plasma
{
height: auto;
}

}
    
</style>
